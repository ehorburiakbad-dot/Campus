import { z } from 'zod';

export const api = {
  auth: {
    register: { method: 'POST' as const, path: '/api/auth/register' },
    login: { method: 'POST' as const, path: '/api/auth/login' },
    logout: { method: 'POST' as const, path: '/api/auth/logout' },
    me: { method: 'GET' as const, path: '/api/user' },
  },
  posts: {
    list: { method: 'GET' as const, path: '/api/posts' },
    create: { method: 'POST' as const, path: '/api/posts' },
    vote: { method: 'POST' as const, path: '/api/posts/:id/vote' },
  },
  users: {
    list: { method: 'GET' as const, path: '/api/users' },
  },
  conversations: {
    list: { method: 'GET' as const, path: '/api/conversations' },
  },
  messages: {
    list: { method: 'GET' as const, path: '/api/messages' },
    create: { method: 'POST' as const, path: '/api/messages' },
  },
  newspapers: {
    list: { method: 'GET' as const, path: '/api/newspapers' },
    get: { method: 'GET' as const, path: '/api/newspapers/:id' },
    create: { method: 'POST' as const, path: '/api/newspapers' },
    subscribe: { method: 'POST' as const, path: '/api/newspapers/:id/subscribe' },
    unsubscribe: { method: 'POST' as const, path: '/api/newspapers/:id/unsubscribe' },
    createArticle: { method: 'POST' as const, path: '/api/newspapers/:id/articles' },
  },
  teachers: {
    list: { method: 'GET' as const, path: '/api/teachers' },
    create: { method: 'POST' as const, path: '/api/teachers' },
    rate: { method: 'POST' as const, path: '/api/teachers/:id/rate' },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, String(value));
    });
  }
  return url;
}
