import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
  isOfficial: boolean("is_official").default(false),
  isAnonymous: boolean("is_anonymous").default(false),
  lastPostAt: timestamp("last_post_at"),
  banUntil: timestamp("ban_until"),
  postCount: integer("post_count").default(0),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  lastSeen: timestamp("last_seen"),
  isOnline: boolean("is_online").default(false),
  displayName: text("display_name"),
  headerUrl: text("header_url"),
  statusText: text("status_text"),
  mood: text("mood"),
  profileColor: text("profile_color"),
  location: text("location"),
  website: text("website"),
});

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  photoUrl: text("photo_url").notNull(),
  subject: text("subject"),
  averageRating: integer("average_rating").default(0),
});

export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  teacherId: integer("teacher_id").notNull(),
  userId: integer("user_id").notNull(),
  category1: integer("category_1").notNull(),
  category2: integer("category_2").notNull(),
  category3: integer("category_3").notNull(),
  category4: integer("category_4").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const newspapers = pgTable("newspapers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  creatorId: integer("creator_id"),
  isAnonymous: boolean("is_anonymous").default(false),
  writeCode: text("write_code").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  newspaperId: integer("newspaper_id").notNull(),
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  newspaperId: integer("newspaper_id").notNull(),
  authorId: integer("author_id"),
  title: text("title").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  isAnonymous: boolean("is_anonymous").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const groups = pgTable("groups", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  avatarUrl: text("avatar_url"),
  creatorId: integer("creator_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const groupMembers = pgTable("group_members", {
  id: serial("id").primaryKey(),
  groupId: integer("group_id").notNull(),
  userId: integer("user_id").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  audioUrl: text("audio_url"),
  upvotes: integer("upvotes").default(0),
  isAnonymous: boolean("is_anonymous").default(true),
  anonTag: text("anon_tag"),
  forwardedFromId: integer("forwarded_from_id"),
  groupId: integer("group_id"),
  isPinned: boolean("is_pinned").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id"),
  groupId: integer("group_id"),
  content: text("content").notNull(),
  audioUrl: text("audio_url"),
  replyToId: integer("reply_to_id"),
  isAnonymous: boolean("is_anonymous").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  isAnonymous: boolean("is_anonymous").default(true),
  anonTag: text("anon_tag"),
  parentId: integer("parent_id"),
  imageUrl: text("image_url"),
  likes: integer("likes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const commentLikes = pgTable("comment_likes", {
  id: serial("id").primaryKey(),
  commentId: integer("comment_id").notNull(),
  userId: integer("user_id").notNull(),
});

export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  imageUrl: text("image_url").notNull(),
  mediaType: text("media_type").default("image"),
  caption: text("caption"),
  textOverlays: text("text_overlays"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const polls = pgTable("polls", {
  id: serial("id").primaryKey(),
  newspaperId: integer("newspaper_id").notNull(),
  question: text("question").notNull(),
  creatorId: integer("creator_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const pollOptions = pgTable("poll_options", {
  id: serial("id").primaryKey(),
  pollId: integer("poll_id").notNull(),
  text: text("text").notNull(),
});

export const pollVotes = pgTable("poll_votes", {
  id: serial("id").primaryKey(),
  pollId: integer("poll_id").notNull(),
  optionId: integer("option_id").notNull(),
  userId: integer("user_id").notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  message: text("message").notNull(),
  fromUserId: integer("from_user_id"),
  postId: integer("post_id"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reactions = pgTable("reactions", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  className: text("class_name").notNull(),
  dayOfWeek: integer("day_of_week").notNull(),
  lessonNumber: integer("lesson_number").notNull(),
  subject: text("subject").notNull(),
  teacherName: text("teacher_name"),
  room: text("room"),
  creatorId: integer("creator_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  icon: text("icon"),
  earnedAt: timestamp("earned_at").defaultNow(),
});

export const postShares = pgTable("post_shares", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  sharedAt: timestamp("shared_at").defaultNow(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  reporterId: integer("reporter_id").notNull(),
  targetType: text("target_type").notNull(),
  targetId: integer("target_id").notNull(),
  reason: text("reason").notNull(),
  status: text("status").default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const feedPolls = pgTable("feed_polls", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  question: text("question").notNull(),
});

export const feedPollOptions = pgTable("feed_poll_options", {
  id: serial("id").primaryKey(),
  pollId: integer("poll_id").notNull(),
  text: text("text").notNull(),
});

export const feedPollVotes = pgTable("feed_poll_votes", {
  id: serial("id").primaryKey(),
  pollId: integer("poll_id").notNull(),
  optionId: integer("option_id").notNull(),
  userId: integer("user_id").notNull(),
});

export const wallPosts = pgTable("wall_posts", {
  id: serial("id").primaryKey(),
  profileUserId: integer("profile_user_id").notNull(),
  authorId: integer("author_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS & TYPES ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, lastPostAt: true, banUntil: true, postCount: true });
export const insertTeacherSchema = createInsertSchema(teachers).omit({ id: true, averageRating: true });
export const insertRatingSchema = createInsertSchema(ratings).omit({ id: true, createdAt: true });
export const insertNewspaperSchema = createInsertSchema(newspapers).omit({ id: true, createdAt: true });
export const insertArticleSchema = createInsertSchema(articles).omit({ id: true, createdAt: true });
export const insertGroupSchema = createInsertSchema(groups).omit({ id: true, createdAt: true });
export const insertPostSchema = createInsertSchema(posts).omit({ id: true, createdAt: true, expiresAt: true, upvotes: true, anonTag: true, isPinned: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true, expiresAt: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true, createdAt: true, anonTag: true, likes: true });
export const insertStorySchema = createInsertSchema(stories).omit({ id: true, createdAt: true, expiresAt: true });
export const insertPollSchema = createInsertSchema(polls).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, createdAt: true });
export const insertReactionSchema = createInsertSchema(reactions).omit({ id: true, createdAt: true });
export const insertScheduleSchema = createInsertSchema(schedules).omit({ id: true, createdAt: true });
export const insertAchievementSchema = createInsertSchema(achievements).omit({ id: true, earnedAt: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = z.infer<typeof insertTeacherSchema>;
export type Rating = typeof ratings.$inferSelect;
export type InsertRating = z.infer<typeof insertRatingSchema>;
export type Group = typeof groups.$inferSelect;
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Newspaper = typeof newspapers.$inferSelect;
export type Article = typeof articles.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Story = typeof stories.$inferSelect;
export type Poll = typeof polls.$inferSelect;
export type PollOption = typeof pollOptions.$inferSelect;
export type PollVote = typeof pollVotes.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Reaction = typeof reactions.$inferSelect;
export type InsertReaction = z.infer<typeof insertReactionSchema>;
export type Schedule = typeof schedules.$inferSelect;
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type PostShare = typeof postShares.$inferSelect;

export const insertReportSchema = createInsertSchema(reports).omit({ id: true, createdAt: true, status: true });
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export const insertWallPostSchema = createInsertSchema(wallPosts).omit({ id: true, createdAt: true });
export type WallPost = typeof wallPosts.$inferSelect;
export type InsertWallPost = z.infer<typeof insertWallPostSchema>;
