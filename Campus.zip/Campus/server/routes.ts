import type { Express } from "express";
import type { Server } from "http";
import { storage, db } from "./storage";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import MemoryStore from "memorystore";
import multer from "multer";
import path from "path";
import fs from "fs";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePassword(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${randomBytes(4).toString('hex')}${path.extname(file.originalname)}`),
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
    cb(null, allowed.includes(path.extname(file.originalname).toLowerCase()));
  },
});

const audioUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => cb(null, `voice-${Date.now()}-${randomBytes(4).toString('hex')}.webm`),
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    cb(null, file.mimetype.startsWith('audio/'));
  },
});

const mediaUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${randomBytes(4).toString('hex')}${path.extname(file.originalname)}`),
  }),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    cb(null, file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/'));
  },
});

const anyUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname) || (file.mimetype.startsWith('audio/') ? '.webm' : '.bin');
      cb(null, `${Date.now()}-${randomBytes(4).toString('hex')}${ext}`);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
});

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  const SessionStore = MemoryStore(session);
  app.use(session({
    secret: process.env.SESSION_SECRET || "campus_secret",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 86400000 },
    store: new SessionStore({ checkPeriod: 86400000 }),
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user || !(await comparePassword(password, user.password))) return done(null, false);
      return done(null, user);
    } catch (err) { return done(err); }
  }));

  passport.serializeUser((user: any, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try { done(null, await storage.getUser(id)); }
    catch (err) { done(err); }
  });

  const lastSeenCache = new Map<number, number>();
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const userId = (req.user as any).id;
    const now = Date.now();
    const last = lastSeenCache.get(userId) || 0;
    if (now - last > 30000) {
      lastSeenCache.set(userId, now);
      storage.updateLastSeen(userId).catch(() => {});
    }
    next();
  };

  app.use('/uploads', (req, res, next) => {
    if (req.path.endsWith('.webm')) {
      res.set('Content-Type', 'audio/webm');
    }
    next();
  }, (await import('express')).default.static(uploadsDir));

  // === Auth ===
  app.post('/api/auth/register', async (req, res) => {
    try {
      const { username, password, principalSurname } = req.body;
      if (!["breus", "бреус"].includes((principalSurname || "").toLowerCase().trim())) {
        return res.status(400).json({ message: "Невірне прізвище директора" });
      }
      if (!username || !password) return res.status(400).json({ message: "Заповніть всі поля" });
      if (await storage.getUserByUsername(username)) return res.status(400).json({ message: "Користувач вже існує" });
      const user = await storage.createUser({ username, password: await hashPassword(password), isAdmin: false, isOfficial: false });
      req.login(user, (err) => err ? res.status(500).json({ message: "Error" }) : res.status(201).json(user));
    } catch { res.status(400).json({ message: "Помилка реєстрації" }); }
  });

  app.post('/api/auth/login', (req, res, next) => {
    passport.authenticate("local", (err: any, user: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: "Невірний логін або пароль" });
      req.login(user, (e) => e ? next(e) : res.json(user));
    })(req, res, next);
  });

  app.post('/api/auth/anonymous', async (req, res) => {
    try {
      const num = Math.floor(1000 + Math.random() * 9000);
      const username = `Анонім${num}`;
      const existing = await storage.getUserByUsername(username);
      if (existing) {
        const num2 = Math.floor(10000 + Math.random() * 90000);
        const username2 = `Анонім${num2}`;
        const user = await storage.createUser({ username: username2, password: await hashPassword(randomBytes(16).toString('hex')), isAdmin: false, isOfficial: false, isAnonymous: true });
        return req.login(user, (err) => err ? res.status(500).json({ message: "Error" }) : res.status(201).json(user));
      }
      const user = await storage.createUser({ username, password: await hashPassword(randomBytes(16).toString('hex')), isAdmin: false, isOfficial: false, isAnonymous: true });
      req.login(user, (err) => err ? res.status(500).json({ message: "Error" }) : res.status(201).json(user));
    } catch { res.status(400).json({ message: "Помилка" }); }
  });

  app.post('/api/auth/upgrade', requireAuth, async (req: any, res) => {
    try {
      const { username, password, principalSurname } = req.body;
      if (!["breus", "бреус"].includes((principalSurname || "").toLowerCase().trim())) {
        return res.status(400).json({ message: "Невірне прізвище директора" });
      }
      if (!username || !password) return res.status(400).json({ message: "Заповніть всі поля" });
      const existing = await storage.getUserByUsername(username);
      if (existing && existing.id !== (req.user as any).id) return res.status(400).json({ message: "Це ім'я зайняте" });
      await db.update(users).set({ username, password: await hashPassword(password), isAnonymous: false }).where(eq(users.id, (req.user as any).id));
      const updated = await storage.getUser((req.user as any).id);
      res.json(updated);
    } catch { res.status(400).json({ message: "Помилка" }); }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout(() => res.json({ message: "ok" }));
  });

  app.get('/api/user', (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not logged in" });
    res.json(req.user);
  });

  // === Image Upload ===
  app.post('/api/upload', requireAuth, upload.single('image'), (req: any, res) => {
    if (!req.file) return res.status(400).json({ message: "Файл не завантажено" });
    res.json({ url: `/uploads/${req.file.filename}` });
  });

  // === Audio Upload ===
  app.post('/api/upload/audio', requireAuth, audioUpload.single('audio'), (req: any, res) => {
    if (!req.file) return res.status(400).json({ message: "Файл не завантажено" });
    res.json({ url: `/uploads/${req.file.filename}` });
  });

  // === Profile ===
  app.get('/api/profile/:id', requireAuth, async (req, res) => {
    const profile = await storage.getUserProfile(Number(req.params.id));
    if (!profile) return res.status(404).json({ message: "Не знайдено" });
    const { password, ...safeUser } = profile.user;
    const achs = await storage.getUserAchievements(profile.user.id);
    res.json({ ...profile, user: safeUser, achievements: achs });
  });

  app.patch('/api/profile', requireAuth, upload.fields([
    { name: 'avatar', maxCount: 1 },
    { name: 'header', maxCount: 1 },
  ]), async (req: any, res) => {
    const userId = (req.user as any).id;
    const updates: Record<string, any> = {};
    if (req.files?.avatar?.[0]) updates.avatarUrl = `/uploads/${req.files.avatar[0].filename}`;
    if (req.files?.header?.[0]) updates.headerUrl = `/uploads/${req.files.header[0].filename}`;
    const maxLengths: Record<string, number> = { bio: 300, displayName: 30, statusText: 100, mood: 20, profileColor: 20, location: 50, website: 100 };
    const textFields = ['bio', 'displayName', 'statusText', 'mood', 'profileColor', 'location', 'website'];
    for (const field of textFields) {
      if (req.body[field] !== undefined) {
        const val = String(req.body[field]).slice(0, maxLengths[field] || 100);
        updates[field] = val || null;
      }
    }
    const updated = await storage.updateProfile(userId, updates);
    const { password, ...safe } = updated;
    res.json(safe);
  });

  // === Posts (anonymous feed) - publicly readable ===
  app.get('/api/posts', async (req, res) => {
    const allPosts = await storage.getPosts();
    const userId = req.isAuthenticated() ? (req.user as any).id : null;
    const withMeta = [];
    for (const p of allPosts) {
      const commentCount = await storage.getCommentCount(p.id);
      const reactionCounts = await storage.getReactionCounts(p.id);
      const userReaction = userId ? await storage.getUserReaction(p.id, userId) : null;
      const shareCount = await storage.getShareCount(p.id);
      let forwardedFrom = null;
      if (p.forwardedFromId) {
        const orig = await storage.getPost(p.forwardedFromId);
        if (orig) forwardedFrom = { id: orig.id, authorName: orig.authorName };
      }
      const poll = await storage.getFeedPoll(p.id);
      const userPollVote = userId && poll ? await storage.getUserFeedPollVote(userId, p.id) : null;
      withMeta.push({ ...p, commentCount, reactionCounts, userReaction, shareCount, forwardedFrom, poll, userPollVote });
    }
    res.json(withMeta);
  });

  app.post('/api/posts', requireAuth, anyUpload.fields([{ name: 'image', maxCount: 1 }, { name: 'audio', maxCount: 1 }]), async (req: any, res) => {
    const userId = (req.user as any).id;
    const check = await storage.canUserPost(userId);
    if (!check.allowed) return res.status(429).json({ message: check.reason });

    const { content, isAnonymous } = req.body;
    if (!content?.trim() && !req.files?.image?.length && !req.files?.audio?.length) return res.status(400).json({ message: "Порожній допис" });

    const imageUrl = req.files?.image?.[0] ? `/uploads/${req.files.image[0].filename}` : undefined;
    const audioUrl = req.files?.audio?.[0] ? `/uploads/${req.files.audio[0].filename}` : undefined;
    const post = await storage.createPost({ userId, content: content || "", isAnonymous: isAnonymous !== "false", imageUrl, audioUrl });
    await storage.recordPost(userId);

    // Check achievements
    await storage.checkAndGrantAchievements(userId);

    // Handle mentions
    const mentions = content?.match(/@(\w+)/g) || [];
    for (const mention of mentions) {
      const username = mention.slice(1);
      const mentioned = await storage.getUserByUsername(username);
      if (mentioned && mentioned.id !== userId) {
        await storage.createNotification({
          userId: mentioned.id,
          type: 'mention',
          message: `${(req.user as any).username} згадав вас у дописі`,
          fromUserId: userId,
          postId: post.id,
        });
      }
    }

    res.status(201).json(post);
  });

  app.post('/api/posts/:id/vote', requireAuth, async (req, res) => {
    const post = await storage.upvotePost(Number(req.params.id));
    res.json({ upvotes: post.upvotes });
  });

  // === Reactions ===
  app.post('/api/posts/:id/react', requireAuth, async (req, res) => {
    const postId = Number(req.params.id);
    const userId = (req.user as any).id;
    const { type } = req.body;
    if (!type) return res.status(400).json({ message: "Тип реакції обов'язковий" });
    await storage.toggleReaction(postId, userId, type);
    const counts = await storage.getReactionCounts(postId);
    const userReaction = await storage.getUserReaction(postId, userId);

    // Notify post owner
    const post = await storage.getPost(postId);
    if (post && userReaction) {
      await storage.createNotification({
        userId: post.userId,
        type: 'reaction',
        message: `${(req.user as any).username} відреагував на ваш допис`,
        fromUserId: userId,
        postId,
      });
    }

    res.json({ reactionCounts: counts, userReaction });
  });

  // === Post Shares ===
  app.post('/api/posts/:id/share', requireAuth, async (req, res) => {
    const postId = Number(req.params.id);
    const userId = (req.user as any).id;
    const shared = await storage.sharePost(postId, userId);
    if (!shared) return res.status(404).json({ message: "Допис не знайдено" });

    const original = await storage.getPost(postId);
    if (original) {
      await storage.createNotification({
        userId: original.userId,
        type: 'share',
        message: `${(req.user as any).username} поширив ваш допис`,
        fromUserId: userId,
        postId,
      });
    }

    res.status(201).json(shared);
  });

  // === Delete Post ===
  app.delete('/api/posts/:id', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const isAdmin = (req.user as any).isAdmin;
    const post = await storage.getPost(Number(req.params.id));
    if (!post) return res.status(404).json({ message: "Допис не знайдено" });
    if (post.userId !== userId && !isAdmin) return res.status(403).json({ message: "Ви не можете видалити цей допис" });
    await storage.deletePost(post.id);
    res.json({ message: "ok" });
  });

  // === Feed Polls ===
  app.post('/api/posts/:id/poll', requireAuth, async (req, res) => {
    const { question, options } = req.body;
    if (!question?.trim() || !options?.length || options.length < 2) {
      return res.status(400).json({ message: "Потрібне питання та мінімум 2 варіанти" });
    }
    await storage.createFeedPoll(Number(req.params.id), question, options);
    res.json({ message: "ok" });
  });

  app.post('/api/feed-polls/:postId/vote', requireAuth, async (req, res) => {
    const { optionId } = req.body;
    if (!optionId) return res.status(400).json({ message: "Оберіть варіант" });
    await storage.voteFeedPollByPost((req.user as any).id, Number(req.params.postId), optionId);
    res.json({ message: "ok" });
  });

  // === Comments ===
  app.get('/api/posts/:id/comments', async (req, res) => {
    const userId = req.isAuthenticated() ? (req.user as any).id : 0;
    res.json(await storage.getComments(Number(req.params.id), userId));
  });

  app.post('/api/posts/:id/comments', requireAuth, upload.single('image'), async (req: any, res) => {
    const { content, isAnonymous, parentId } = req.body;
    if (!content?.trim() && !req.file) return res.status(400).json({ message: "Порожній коментар" });
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    const userId = (req.user as any).id;
    const postId = Number(req.params.id);
    const comment = await storage.createComment({
      postId,
      userId,
      content: content || "",
      isAnonymous: isAnonymous !== "false" && isAnonymous !== false,
      parentId: parentId ? Number(parentId) : undefined,
      imageUrl,
    });

    // Check achievements
    await storage.checkAndGrantAchievements(userId);

    // Notify post owner
    const post = await storage.getPost(postId);
    if (post && post.userId !== userId) {
      await storage.createNotification({
        userId: post.userId,
        type: 'comment',
        message: `${(req.user as any).username} прокоментував ваш допис`,
        fromUserId: userId,
        postId,
      });
    }

    // Handle mentions in comments
    const mentions = content?.match(/@(\w+)/g) || [];
    for (const mention of mentions) {
      const username = mention.slice(1);
      const mentioned = await storage.getUserByUsername(username);
      if (mentioned && mentioned.id !== userId) {
        await storage.createNotification({
          userId: mentioned.id,
          type: 'mention',
          message: `${(req.user as any).username} згадав вас у коментарі`,
          fromUserId: userId,
          postId,
        });
      }
    }

    res.status(201).json(comment);
  });

  app.post('/api/comments/:id/like', requireAuth, async (req, res) => {
    const result = await storage.toggleCommentLike(Number(req.params.id), (req.user as any).id);
    res.json(result);
  });

  // === Stories ===
  app.get('/api/stories', async (_req, res) => {
    res.json(await storage.getStories());
  });

  app.post('/api/stories', requireAuth, mediaUpload.single('image'), async (req: any, res) => {
    if (!req.file) return res.status(400).json({ message: "Потрібне фото або відео" });
    const imageUrl = `/uploads/${req.file.filename}`;
    const mediaType = req.file.mimetype.startsWith('video/') ? 'video' : 'image';
    const story = await storage.createStory({ userId: (req.user as any).id, imageUrl, caption: req.body.caption, mediaType, textOverlays: req.body.textOverlays });
    res.status(201).json(story);
  });

  // === Recommendations ===
  app.get('/api/recommendations', async (_req, res) => {
    const trending = await storage.getTrendingPosts();
    const popularNewspapers = await storage.getPopularNewspapers();
    res.json({ trending, popularNewspapers });
  });

  // === Notifications ===
  app.get('/api/notifications', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const notifs = await storage.getNotifications(userId);
    const unreadCount = await storage.getUnreadCount(userId);
    res.json({ notifications: notifs, unreadCount });
  });

  app.post('/api/notifications/read', requireAuth, async (req, res) => {
    await storage.markNotificationsRead((req.user as any).id);
    res.json({ message: "ok" });
  });

  // === Groups ===
  app.get('/api/groups', requireAuth, async (_req, res) => {
    const allGroups = await storage.getGroups();
    res.json(allGroups);
  });

  app.get('/api/groups/:id', requireAuth, async (req, res) => {
    const group = await storage.getGroup(Number(req.params.id));
    if (!group) return res.status(404).json({ message: "Групу не знайдено" });
    const members = await storage.getGroupMembers(group.id);
    res.json({ ...group, members });
  });

  app.get('/api/groups/:id/posts', requireAuth, async (req, res) => {
    const groupPosts = await storage.getGroupPosts(Number(req.params.id));
    res.json(groupPosts);
  });

  app.post('/api/groups', requireAuth, upload.single('avatar'), async (req: any, res) => {
    const { name, description } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ message: "Назва обов'язкова" });
    const userId = (req.user as any).id;
    const avatarUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    const group = await storage.createGroup({ name: name.trim(), description: description?.trim() || null, creatorId: userId, avatarUrl });
    await storage.joinGroup(userId, group.id);
    res.json(group);
  });

  app.post('/api/groups/:id/join', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    await storage.joinGroup(userId, Number(req.params.id));
    res.json({ message: "ok" });
  });

  app.post('/api/groups/:id/leave', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    await storage.leaveGroup(userId, Number(req.params.id));
    res.json({ message: "ok" });
  });

  app.post('/api/groups/:id/posts', requireAuth, upload.single('image'), async (req, res) => {
    const userId = (req.user as any).id;
    const groupId = Number(req.params.id);
    const members = await storage.getGroupMembers(groupId);
    if (!members.includes(userId)) return res.status(403).json({ message: "Спочатку приєднайтесь до групи" });
    const { content, isAnonymous } = req.body;
    if (!content || !content.trim()) return res.status(400).json({ message: "Вміст обов'язковий" });
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    const anon = isAnonymous === "true" || isAnonymous === true;
    const post = await storage.createPost({
      userId, content: content.trim(), isAnonymous: anon,
      groupId, imageUrl: imageUrl || null, audioUrl: null,
      forwardedFromId: null,
    });

    for (const memberId of members) {
      if (memberId !== userId) {
        await storage.createNotification({
          userId: memberId,
          type: 'group_post',
          message: `Новий допис у групі`,
          fromUserId: userId,
          postId: post.id,
        });
      }
    }

    res.json(post);
  });

  // === Search ===
  app.get('/api/search', requireAuth, async (req, res) => {
    const q = (req.query.q as string || "").trim();
    if (!q) return res.json({ posts: [], users: [], groups: [], newspapers: [] });
    const [searchPosts, searchUsers, searchGroups, searchNewspapers] = await Promise.all([
      storage.searchPosts(q),
      storage.searchUsers(q),
      storage.searchGroups(q),
      storage.searchNewspapers(q),
    ]);
    res.json({ posts: searchPosts, users: searchUsers, groups: searchGroups, newspapers: searchNewspapers });
  });

  // === Schedules ===
  app.get('/api/schedules', requireAuth, async (req, res) => {
    const className = req.query.class as string | undefined;
    res.json(await storage.getSchedules(className));
  });

  app.get('/api/schedules/classes', requireAuth, async (_req, res) => {
    res.json(await storage.getClassNames());
  });

  app.post('/api/schedules', requireAuth, async (req, res) => {
    const { className, dayOfWeek, lessonNumber, subject, teacherName, room } = req.body;
    if (!className || dayOfWeek === undefined || !lessonNumber || !subject) {
      return res.status(400).json({ message: "Заповніть обов'язкові поля" });
    }
    const entry = await storage.createScheduleEntry({
      className, dayOfWeek: Number(dayOfWeek), lessonNumber: Number(lessonNumber),
      subject, teacherName, room, creatorId: (req.user as any).id,
    });
    res.status(201).json(entry);
  });

  app.delete('/api/schedules/:id', requireAuth, async (req, res) => {
    await storage.deleteScheduleEntry(Number(req.params.id));
    res.json({ message: "ok" });
  });

  // === Achievements ===
  app.get('/api/achievements', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const achs = await storage.getUserAchievements(userId);
    res.json(achs);
  });

  app.get('/api/achievements/:userId', requireAuth, async (req, res) => {
    res.json(await storage.getUserAchievements(Number(req.params.userId)));
  });

  // === Messages (private chat) ===
  app.get('/api/users', requireAuth, async (req, res) => {
    const all = await storage.getAllUsers();
    res.json(all.filter(u => u.id !== (req.user as any).id));
  });

  app.get('/api/conversations', requireAuth, async (req, res) => {
    res.json(await storage.getConversations((req.user as any).id));
  });

  app.get('/api/messages/search', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const otherUserId = Number(req.query.userId);
    const query = (req.query.q as string || "").trim();
    if (!otherUserId || !query) return res.json([]);
    res.json(await storage.searchMessages(userId, otherUserId, query));
  });

  app.get('/api/messages', requireAuth, async (req, res) => {
    const userId = (req.user as any).id;
    const otherUserId = req.query.userId ? Number(req.query.userId) : undefined;
    res.json(await storage.getMessages(userId, otherUserId));
  });

  app.post('/api/messages', requireAuth, audioUpload.single('audio'), async (req: any, res) => {
    const { content, receiverId, replyToId } = req.body;
    const audioUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    if (!content?.trim() && !audioUrl) return res.status(400).json({ message: "Bad request" });
    if (!receiverId) return res.status(400).json({ message: "Bad request" });
    const userId = (req.user as any).id;
    const msg = await storage.createMessage({ senderId: userId, receiverId: Number(receiverId), content: content || "", isAnonymous: false, groupId: null, audioUrl, replyToId: replyToId ? Number(replyToId) : undefined });

    // Notify receiver
    await storage.createNotification({
      userId: Number(receiverId),
      type: 'message',
      message: `${(req.user as any).username} надіслав вам повідомлення`,
      fromUserId: userId,
    });

    // Check achievements
    await storage.checkAndGrantAchievements(userId);

    res.status(201).json(msg);
  });

  // === Newspapers ===
  app.get('/api/newspapers', requireAuth, async (_req, res) => {
    res.json(await storage.getNewspapers());
  });

  app.get('/api/newspapers/:id', requireAuth, async (req, res) => {
    const paper = await storage.getNewspaper(Number(req.params.id));
    if (!paper) return res.status(404).json({ message: "Not found" });
    const userId = (req.user as any).id;
    const subscribed = await storage.isSubscribed(userId, paper.id);
    const isCreator = paper.creatorId === userId;
    const { writeCode, ...paperWithoutCode } = paper;
    res.json({ ...paperWithoutCode, isSubscribed: subscribed, isCreator, writeCode: isCreator ? writeCode : undefined });
  });

  app.post('/api/newspapers', requireAuth, async (req, res) => {
    const user = req.user as any;
    const { name, description, type, isAnonymous } = req.body;
    if (type === 'official' && !user.isOfficial) return res.status(403).json({ message: "Тільки офіційні користувачі" });
    const paper = await storage.createNewspaper({ name, description, type: type || 'user', creatorId: user.id, isAnonymous });
    res.status(201).json(paper);
  });

  app.post('/api/newspapers/:id/subscribe', requireAuth, async (req, res) => {
    await storage.subscribe((req.user as any).id, Number(req.params.id));
    res.json({ message: "Subscribed" });
  });

  app.post('/api/newspapers/:id/unsubscribe', requireAuth, async (req, res) => {
    await storage.unsubscribe((req.user as any).id, Number(req.params.id));
    res.json({ message: "Unsubscribed" });
  });

  app.post('/api/newspapers/:id/articles', requireAuth, upload.single('image'), async (req: any, res) => {
    const { title, content, isAnonymous, writeCode } = req.body;
    if (!title?.trim() || !content?.trim()) return res.status(400).json({ message: "Bad request" });
    
    const newspaperId = Number(req.params.id);
    const actualCode = await storage.getNewspaperWriteCode(newspaperId);
    if (!actualCode || actualCode !== writeCode) {
      return res.status(403).json({ message: "Невірний код доступу" });
    }

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    const article = await storage.createArticle({ newspaperId, authorId: (req.user as any).id, title, content, isAnonymous: isAnonymous === 'true' || isAnonymous === true, imageUrl });
    res.status(201).json(article);
  });

  // === Polls ===
  app.get('/api/newspapers/:id/polls', requireAuth, async (req, res) => {
    const polls = await storage.getPolls(Number(req.params.id));
    const userId = (req.user as any).id;
    const withVotes = [];
    for (const p of polls) {
      const userVote = await storage.getUserPollVote(userId, p.id);
      withVotes.push({ ...p, userVote });
    }
    res.json(withVotes);
  });

  app.post('/api/newspapers/:id/polls', requireAuth, async (req, res) => {
    const { question, options, writeCode } = req.body;
    if (!question?.trim() || !options?.length || options.length < 2) return res.status(400).json({ message: "Потрібне питання та мінімум 2 варіанти" });
    const newspaperId = Number(req.params.id);
    const actualCode = await storage.getNewspaperWriteCode(newspaperId);
    if (!actualCode || actualCode !== writeCode) return res.status(403).json({ message: "Невірний код доступу" });
    const poll = await storage.createPoll({ newspaperId, creatorId: (req.user as any).id, question, options });
    res.status(201).json(poll);
  });

  app.post('/api/polls/:id/vote', requireAuth, async (req, res) => {
    const { optionId } = req.body;
    if (!optionId) return res.status(400).json({ message: "Оберіть варіант" });
    await storage.votePoll((req.user as any).id, Number(req.params.id), optionId);
    res.json({ message: "ok" });
  });

  // === Wall Posts ===
  app.get('/api/wall/:userId', requireAuth, async (req, res) => {
    res.json(await storage.getWallPosts(Number(req.params.userId)));
  });

  app.post('/api/wall/:userId', requireAuth, async (req, res) => {
    const authorId = (req.user as any).id;
    const profileUserId = Number(req.params.userId);
    const profileUser = await storage.getUser(profileUserId);
    if (!profileUser) return res.status(404).json({ message: "Користувача не знайдено" });
    const { content } = req.body;
    if (!content?.trim()) return res.status(400).json({ message: "Порожнє повідомлення" });
    if (content.length > 500) return res.status(400).json({ message: "Занадто довге повідомлення" });
    const wp = await storage.createWallPost({ profileUserId, authorId, content: content.trim() });

    if (authorId !== profileUserId) {
      await storage.createNotification({
        userId: profileUserId,
        type: 'wall',
        message: `${(req.user as any).username} написав на вашій стіні`,
        fromUserId: authorId,
      });
    }

    res.status(201).json(wp);
  });

  app.delete('/api/wall/:id', requireAuth, async (req, res) => {
    const wp = await storage.getWallPost(Number(req.params.id));
    if (!wp) return res.status(404).json({ message: "Не знайдено" });
    const userId = (req.user as any).id;
    const isAdmin = (req.user as any).isAdmin;
    if (wp.authorId !== userId && wp.profileUserId !== userId && !isAdmin) {
      return res.status(403).json({ message: "Недостатньо прав" });
    }
    await storage.deleteWallPost(wp.id);
    res.json({ message: "ok" });
  });

  // === Teachers ===
  app.get('/api/teachers', async (_req, res) => { res.json(await storage.getTeachers()); });
  app.post('/api/teachers', requireAuth, async (req, res) => {
    const { name, photoUrl, subject, secret } = req.body;
    if (secret !== "add222") return res.status(401).json({ message: "Wrong secret" });
    res.status(201).json(await storage.createTeacher({ name, photoUrl: photoUrl || "", subject }));
  });
  app.post('/api/teachers/:id/rate', requireAuth, async (req, res) => {
    await storage.rateTeacher({ ...req.body, userId: (req.user as any).id, teacherId: Number(req.params.id) });
    const t = await storage.getTeacher(Number(req.params.id));
    res.json({ averageRating: t?.averageRating || 0 });
  });

  app.get('/api/teachers/weekly', requireAuth, async (_req, res) => {
    res.json(await storage.getTeacherOfTheWeek());
  });

  // === Admin ===
  const requireAdmin = async (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    const user = req.user as any;
    if (!user.isAdmin) return res.status(403).json({ message: "Тільки для адміністраторів" });
    next();
  };

  // === Pin/Unpin Posts ===
  app.post('/api/posts/:id/pin', requireAdmin, async (req, res) => {
    await storage.pinPost(Number(req.params.id));
    res.json({ message: "ok" });
  });

  app.post('/api/posts/:id/unpin', requireAdmin, async (req, res) => {
    await storage.unpinPost(Number(req.params.id));
    res.json({ message: "ok" });
  });

  // === Reports ===
  app.post('/api/reports', requireAuth, async (req, res) => {
    const { targetType, targetId, reason } = req.body;
    if (!targetType || !targetId || !reason?.trim()) return res.status(400).json({ message: "Заповніть всі поля" });
    const report = await storage.createReport({ reporterId: (req.user as any).id, targetType, targetId: Number(targetId), reason });
    res.status(201).json(report);
  });

  app.get('/api/admin/reports', requireAdmin, async (_req, res) => {
    res.json(await storage.getReports());
  });

  app.patch('/api/admin/reports/:id', requireAdmin, async (req, res) => {
    const { status } = req.body;
    await storage.updateReportStatus(Number(req.params.id), status);
    res.json({ message: "ok" });
  });

  app.get('/api/admin/stats', requireAdmin, async (_req, res) => {
    res.json(await storage.getAdminStats());
  });

  app.get('/api/admin/users', requireAdmin, async (_req, res) => {
    const all = await storage.getAllUsersAdmin();
    res.json(all.map(u => ({ id: u.id, username: u.username, isAdmin: u.isAdmin, isOfficial: u.isOfficial, postCount: u.postCount, banUntil: u.banUntil })));
  });

  app.patch('/api/admin/users/:id', requireAdmin, async (req, res) => {
    const { field, value } = req.body;
    if (!['isAdmin', 'isOfficial'].includes(field)) return res.status(400).json({ message: "Invalid field" });
    await storage.updateUserField(Number(req.params.id), field, !!value);
    res.json({ message: "ok" });
  });

  app.delete('/api/admin/users/:id', requireAdmin, async (req, res) => {
    const targetId = Number(req.params.id);
    if (targetId === (req.user as any).id) return res.status(400).json({ message: "Не можна видалити себе" });
    await storage.deleteUser(targetId);
    res.json({ message: "ok" });
  });

  app.get('/api/admin/newspapers', requireAdmin, async (_req, res) => {
    const all = await storage.getNewspapers();
    res.json(all);
  });

  app.patch('/api/admin/newspapers/:id', requireAdmin, async (req, res) => {
    const { type } = req.body;
    if (!['official', 'user', 'free'].includes(type)) return res.status(400).json({ message: "Invalid type" });
    await storage.updateNewspaperType(Number(req.params.id), type);
    res.json({ message: "ok" });
  });

  app.delete('/api/admin/newspapers/:id', requireAdmin, async (req, res) => {
    await storage.deleteNewspaper(Number(req.params.id));
    res.json({ message: "ok" });
  });

  app.get('/api/admin/posts', requireAdmin, async (_req, res) => {
    res.json(await storage.getPosts());
  });

  app.delete('/api/admin/posts/:id', requireAdmin, async (req, res) => {
    await storage.deletePost(Number(req.params.id));
    res.json({ message: "ok" });
  });

  app.post('/api/admin/unban/:id', requireAdmin, async (req, res) => {
    await storage.unbanUser(Number(req.params.id));
    res.json({ message: "ok" });
  });

  // Maintenance
  setInterval(() => storage.cleanupOldContent(), 3600000);

  // Seed admin user "Пр" + initial data
  try {
    const adminUser = await storage.getUserByUsername("Пр");
    if (!adminUser) {
      const hashed = await hashPassword("Пр");
      await storage.createUser({ username: "Пр", password: hashed, isAdmin: true, isOfficial: true });
      console.log('Admin user "Пр" created');
    } else if (!adminUser.isAdmin) {
      await storage.updateUserField(adminUser.id, 'isAdmin', true);
      await storage.updateUserField(adminUser.id, 'isOfficial', true);
    }
  } catch (e) { console.log("Admin seed skipped"); }

  try { await storage.seedInitialData(); } catch (e) { console.log("Seed skipped"); }

  return httpServer;
}
