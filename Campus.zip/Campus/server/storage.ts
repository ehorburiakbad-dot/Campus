import { db } from "./db";
export { db };
import {
  users, teachers, ratings, groups, groupMembers, posts, messages,
  newspapers, articles, subscriptions, comments, commentLikes, stories, polls, pollOptions, pollVotes,
  notifications, reactions, schedules, achievements, postShares,
  reports, feedPolls, feedPollOptions, feedPollVotes, wallPosts,
  type User, type InsertUser, type Teacher, type InsertTeacher,
  type InsertRating, type Group, type InsertGroup,
  type Post, type InsertPost, type Message, type InsertMessage,
  type Comment, type Story, type Poll, type PollOption, type PollVote,
  type Notification, type Reaction, type Schedule, type Achievement, type PostShare,
  type Report, type WallPost
} from "@shared/schema";
import { eq, desc, sql, and, lt, or, ne, gt, ilike } from "drizzle-orm";
import crypto from "crypto";

export class DatabaseStorage {
  // === Users ===
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async updateLastSeen(userId: number): Promise<void> {
    await db.update(users).set({ lastSeen: new Date() }).where(eq(users.id, userId));
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getAllUsers(): Promise<(Pick<User, 'id' | 'username' | 'avatarUrl' | 'lastSeen'> & { isOnline: boolean })[]> {
    const all = await db.select({ id: users.id, username: users.username, avatarUrl: users.avatarUrl, lastSeen: users.lastSeen }).from(users);
    const twoMinAgo = new Date(Date.now() - 2 * 60 * 1000);
    return all.map(u => ({ ...u, isOnline: !!(u.lastSeen && u.lastSeen > twoMinAgo) }));
  }

  async getAllUsersAdmin(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.id));
  }

  async getAdminStats(): Promise<{ totalUsers: number; onlineUsers: number; totalPosts: number; totalNewspapers: number; totalMessages: number }> {
    const [{ count: totalUsers }] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const fiveMinAgo = new Date(Date.now() - 5 * 60000);
    const [{ count: onlineUsers }] = await db.select({ count: sql<number>`count(*)` }).from(users).where(sql`${users.lastPostAt} > ${fiveMinAgo} OR ${users.id} IN (SELECT DISTINCT sender_id FROM messages WHERE created_at > ${fiveMinAgo})`);
    const [{ count: totalPosts }] = await db.select({ count: sql<number>`count(*)` }).from(posts);
    const [{ count: totalNewspapers }] = await db.select({ count: sql<number>`count(*)` }).from(newspapers);
    const [{ count: totalMessages }] = await db.select({ count: sql<number>`count(*)` }).from(messages);
    return { totalUsers: Number(totalUsers), onlineUsers: Number(onlineUsers), totalPosts: Number(totalPosts), totalNewspapers: Number(totalNewspapers), totalMessages: Number(totalMessages) };
  }

  async updateUserField(userId: number, field: 'isAdmin' | 'isOfficial', value: boolean): Promise<void> {
    if (field === 'isAdmin') {
      await db.update(users).set({ isAdmin: value }).where(eq(users.id, userId));
    } else {
      await db.update(users).set({ isOfficial: value }).where(eq(users.id, userId));
    }
  }

  async deleteUser(userId: number): Promise<void> {
    await db.delete(posts).where(eq(posts.userId, userId));
    await db.delete(messages).where(or(eq(messages.senderId, userId), eq(messages.receiverId, userId)));
    await db.delete(subscriptions).where(eq(subscriptions.userId, userId));
    await db.delete(groupMembers).where(eq(groupMembers.userId, userId));
    await db.delete(notifications).where(eq(notifications.userId, userId));
    await db.delete(reactions).where(eq(reactions.userId, userId));
    await db.delete(achievements).where(eq(achievements.userId, userId));
    await db.delete(users).where(eq(users.id, userId));
  }

  async updateNewspaperType(newspaperId: number, type: string): Promise<void> {
    await db.update(newspapers).set({ type }).where(eq(newspapers.id, newspaperId));
  }

  async deleteNewspaper(newspaperId: number): Promise<void> {
    await db.delete(articles).where(eq(articles.newspaperId, newspaperId));
    await db.delete(subscriptions).where(eq(subscriptions.newspaperId, newspaperId));
    await db.delete(newspapers).where(eq(newspapers.id, newspaperId));
  }

  async deletePost(postId: number): Promise<void> {
    const postComments = await db.select({ id: comments.id }).from(comments).where(eq(comments.postId, postId));
    for (const c of postComments) {
      await db.delete(commentLikes).where(eq(commentLikes.commentId, c.id));
    }
    await db.delete(comments).where(eq(comments.postId, postId));
    await db.delete(reactions).where(eq(reactions.postId, postId));
    await db.delete(postShares).where(eq(postShares.postId, postId));
    const [poll] = await db.select().from(feedPolls).where(eq(feedPolls.postId, postId));
    if (poll) {
      await db.delete(feedPollVotes).where(eq(feedPollVotes.pollId, poll.id));
      await db.delete(feedPollOptions).where(eq(feedPollOptions.pollId, poll.id));
      await db.delete(feedPolls).where(eq(feedPolls.id, poll.id));
    }
    await db.delete(posts).where(eq(posts.id, postId));
  }

  async updateUserPassword(userId: number, hashedPassword: string): Promise<void> {
    await db.update(users).set({ password: hashedPassword }).where(eq(users.id, userId));
  }

  async unbanUser(userId: number): Promise<void> {
    await db.update(users).set({ banUntil: null, postCount: 0 }).where(eq(users.id, userId));
  }

  async touchUserActivity(userId: number): Promise<void> {
    await db.update(users).set({ lastPostAt: new Date() }).where(eq(users.id, userId));
  }

  // === User Profile ===
  async updateProfile(userId: number, data: Record<string, any>): Promise<User> {
    const [updated] = await db.update(users).set(data).where(eq(users.id, userId)).returning();
    return updated;
  }

  async getUserProfile(userId: number): Promise<{ user: User; postCount: number; achievementCount: number } | null> {
    const user = await this.getUser(userId);
    if (!user) return null;
    const [{ count: pc }] = await db.select({ count: sql<number>`count(*)` }).from(posts).where(eq(posts.userId, userId));
    const [{ count: ac }] = await db.select({ count: sql<number>`count(*)` }).from(achievements).where(eq(achievements.userId, userId));
    return { user, postCount: Number(pc), achievementCount: Number(ac) };
  }

  // === Spam Protection ===
  async canUserPost(userId: number): Promise<{ allowed: boolean; reason?: string }> {
    return { allowed: true };
  }

  async recordPost(userId: number): Promise<void> {
    await db.update(users).set({
      lastPostAt: new Date(),
    }).where(eq(users.id, userId));
  }

  // === Teachers ===
  async getTeachers(): Promise<Teacher[]> {
    return db.select().from(teachers).orderBy(desc(teachers.averageRating));
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher;
  }

  async createTeacher(teacher: InsertTeacher): Promise<Teacher> {
    const [t] = await db.insert(teachers).values(teacher).returning();
    return t;
  }

  async rateTeacher(rating: InsertRating): Promise<void> {
    await db.insert(ratings).values(rating);
    const all = await db.select().from(ratings).where(eq(ratings.teacherId, rating.teacherId));
    if (all.length > 0) {
      const total = all.reduce((a, r) => a + (r.category1 + r.category2 + r.category3 + r.category4) / 4, 0);
      await db.update(teachers).set({ averageRating: Math.round(total / all.length) }).where(eq(teachers.id, rating.teacherId));
    }
  }

  // === Groups ===
  async getGroups(): Promise<(Group & { memberCount: number })[]> {
    const all = await db.select().from(groups);
    const result = [];
    for (const g of all) {
      const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(groupMembers).where(eq(groupMembers.groupId, g.id));
      result.push({ ...g, memberCount: Number(count) });
    }
    return result;
  }

  async createGroup(group: InsertGroup): Promise<Group> {
    const [g] = await db.insert(groups).values(group).returning();
    return g;
  }

  async joinGroup(userId: number, groupId: number): Promise<void> {
    const [existing] = await db.select().from(groupMembers).where(and(eq(groupMembers.userId, userId), eq(groupMembers.groupId, groupId)));
    if (!existing) await db.insert(groupMembers).values({ userId, groupId });
  }

  async leaveGroup(userId: number, groupId: number): Promise<void> {
    await db.delete(groupMembers).where(and(eq(groupMembers.userId, userId), eq(groupMembers.groupId, groupId)));
  }

  async getGroupMembers(groupId: number): Promise<number[]> {
    const members = await db.select({ userId: groupMembers.userId }).from(groupMembers).where(eq(groupMembers.groupId, groupId));
    return members.map(m => m.userId);
  }

  async getGroup(groupId: number): Promise<Group | undefined> {
    const [g] = await db.select().from(groups).where(eq(groups.id, groupId));
    return g;
  }

  async getGroupPosts(groupId: number): Promise<(Post & { authorName: string; authorAvatar: string | null; authorIsAdmin: boolean; authorIsOfficial: boolean })[]> {
    const results = await db.select({ post: posts, authorName: users.username, authorAvatar: users.avatarUrl, authorIsAdmin: users.isAdmin, authorIsOfficial: users.isOfficial })
      .from(posts).innerJoin(users, eq(users.id, posts.userId))
      .where(eq(posts.groupId, groupId))
      .orderBy(desc(posts.createdAt));
    return results.map(r => ({
      ...r.post,
      authorName: r.authorName,
      authorAvatar: r.authorAvatar,
      authorIsAdmin: r.post.isAnonymous ? false : (r.authorIsAdmin ?? false),
      authorIsOfficial: r.post.isAnonymous ? false : (r.authorIsOfficial ?? false),
    }));
  }

  // === Posts ===
  async getPosts(): Promise<(Post & { authorName: string; authorAvatar: string | null; authorIsAdmin: boolean; authorIsOfficial: boolean })[]> {
    const results = await db.select({ post: posts, authorName: users.username, authorAvatar: users.avatarUrl, authorIsAdmin: users.isAdmin, authorIsOfficial: users.isOfficial })
      .from(posts).innerJoin(users, eq(users.id, posts.userId))
      .where(sql`${posts.groupId} IS NULL`)
      .orderBy(desc(posts.isPinned), desc(posts.createdAt));
    return results.map(r => ({
      ...r.post,
      authorName: r.post.isAnonymous ? (r.post.anonTag || "Анонім") : r.authorName,
      authorAvatar: r.post.isAnonymous ? null : r.authorAvatar,
      authorIsAdmin: r.post.isAnonymous ? false : (r.authorIsAdmin ?? false),
      authorIsOfficial: r.post.isAnonymous ? false : (r.authorIsOfficial ?? false),
    }));
  }

  async getPost(id: number): Promise<(Post & { authorName: string }) | null> {
    const [result] = await db.select({ post: posts, authorName: users.username })
      .from(posts).innerJoin(users, eq(users.id, posts.userId))
      .where(eq(posts.id, id));
    if (!result) return null;
    return {
      ...result.post,
      authorName: result.post.isAnonymous ? (result.post.anonTag || "Анонім") : result.authorName,
    };
  }

  async createPost(data: InsertPost & { userId: number }): Promise<Post> {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);
    const anonTag = data.isAnonymous ? `Анонім-${crypto.randomBytes(3).toString('hex')}` : null;

    const [p] = await db.insert(posts).values({ ...data, expiresAt, upvotes: 0, anonTag }).returning();
    return p;
  }

  async upvotePost(id: number): Promise<Post> {
    const [p] = await db.update(posts).set({ upvotes: sql`${posts.upvotes} + 1` }).where(eq(posts.id, id)).returning();
    return p;
  }

  // === Reactions ===
  async getPostReactions(postId: number): Promise<{ type: string; count: number; users: number[] }[]> {
    const all = await db.select().from(reactions).where(eq(reactions.postId, postId));
    const grouped = new Map<string, number[]>();
    for (const r of all) {
      if (!grouped.has(r.type)) grouped.set(r.type, []);
      grouped.get(r.type)!.push(r.userId);
    }
    return Array.from(grouped.entries()).map(([type, userIds]) => ({ type, count: userIds.length, users: userIds }));
  }

  async toggleReaction(postId: number, userId: number, type: string): Promise<void> {
    const [existing] = await db.select().from(reactions).where(and(eq(reactions.postId, postId), eq(reactions.userId, userId), eq(reactions.type, type)));
    if (existing) {
      await db.delete(reactions).where(eq(reactions.id, existing.id));
    } else {
      await db.delete(reactions).where(and(eq(reactions.postId, postId), eq(reactions.userId, userId)));
      await db.insert(reactions).values({ postId, userId, type });
    }
  }

  async getReactionCounts(postId: number): Promise<Record<string, number>> {
    const all = await db.select().from(reactions).where(eq(reactions.postId, postId));
    const counts: Record<string, number> = {};
    for (const r of all) {
      counts[r.type] = (counts[r.type] || 0) + 1;
    }
    return counts;
  }

  async getUserReaction(postId: number, userId: number): Promise<string | null> {
    const [r] = await db.select().from(reactions).where(and(eq(reactions.postId, postId), eq(reactions.userId, userId)));
    return r?.type || null;
  }

  // === Messages (Private Chat) ===
  async getMessages(userId: number, otherUserId?: number): Promise<(Message & { senderName: string })[]> {
    let condition;
    if (otherUserId) {
      condition = or(
        and(eq(messages.senderId, userId), eq(messages.receiverId, otherUserId)),
        and(eq(messages.senderId, otherUserId), eq(messages.receiverId, userId))
      );
    } else {
      condition = or(eq(messages.senderId, userId), eq(messages.receiverId, userId));
    }

    const results = await db.select({ message: messages, senderName: users.username })
      .from(messages).innerJoin(users, eq(users.id, messages.senderId))
      .where(condition!)
      .orderBy(messages.createdAt);
    return results.map(r => ({ ...r.message, senderName: r.senderName }));
  }

  async getConversations(userId: number): Promise<{ userId: number; username: string; lastMessage: string; lastAt: Date; isOnline: boolean | null }[]> {
    const sent = await db.select({
      otherId: messages.receiverId,
      content: messages.content,
      createdAt: messages.createdAt,
    }).from(messages).where(eq(messages.senderId, userId));

    const received = await db.select({
      otherId: messages.senderId,
      content: messages.content,
      createdAt: messages.createdAt,
    }).from(messages).where(eq(messages.receiverId, userId));

    const all = [...sent, ...received].filter(m => m.otherId != null);
    const map = new Map<number, { content: string; createdAt: Date | null }>();
    for (const m of all) {
      const existing = map.get(m.otherId!);
      if (!existing || (m.createdAt && existing.createdAt && m.createdAt > existing.createdAt)) {
        map.set(m.otherId!, { content: m.content, createdAt: m.createdAt });
      }
    }

    const result = [];
    for (const [id, data] of map) {
      const u = await this.getUser(id);
      if (u) {
        const twoMinAgo = new Date(Date.now() - 2 * 60 * 1000);
        const online = !!(u.lastSeen && u.lastSeen > twoMinAgo);
        result.push({ userId: id, username: u.username, lastMessage: data.content, lastAt: data.createdAt || new Date(), isOnline: online });
      }
    }
    return result.sort((a, b) => b.lastAt.getTime() - a.lastAt.getTime());
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);
    const [m] = await db.insert(messages).values({ ...message, expiresAt }).returning();
    return m;
  }

  // === Newspapers ===
  async getNewspapers(): Promise<any[]> {
    return db.select().from(newspapers).orderBy(desc(newspapers.createdAt));
  }

  async getNewspaper(id: number) {
    const [paper] = await db.select().from(newspapers).where(eq(newspapers.id, id));
    if (!paper) return null;
    const paperArticles = await db.select().from(articles).where(eq(articles.newspaperId, id)).orderBy(desc(articles.createdAt));
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(subscriptions).where(eq(subscriptions.newspaperId, id));
    return { ...paper, articles: paperArticles, subscriberCount: Number(count) };
  }

  async subscribe(userId: number, newspaperId: number): Promise<void> {
    const [existing] = await db.select().from(subscriptions).where(and(eq(subscriptions.userId, userId), eq(subscriptions.newspaperId, newspaperId)));
    if (!existing) await db.insert(subscriptions).values({ userId, newspaperId });
  }

  async unsubscribe(userId: number, newspaperId: number): Promise<void> {
    await db.delete(subscriptions).where(and(eq(subscriptions.userId, userId), eq(subscriptions.newspaperId, newspaperId)));
  }

  async isSubscribed(userId: number, newspaperId: number): Promise<boolean> {
    const [s] = await db.select().from(subscriptions).where(and(eq(subscriptions.userId, userId), eq(subscriptions.newspaperId, newspaperId)));
    return !!s;
  }

  async createNewspaper(data: { name: string; type: string; description?: string; creatorId: number; isAnonymous?: boolean }) {
    const writeCode = crypto.randomBytes(3).toString('hex');
    const [n] = await db.insert(newspapers).values({ ...data, writeCode }).returning();
    return n;
  }

  async getNewspaperWriteCode(newspaperId: number): Promise<string | null> {
    const [paper] = await db.select({ writeCode: newspapers.writeCode }).from(newspapers).where(eq(newspapers.id, newspaperId));
    return paper?.writeCode || null;
  }

  async createArticle(data: { newspaperId: number; authorId: number; title: string; content: string; isAnonymous?: boolean; imageUrl?: string }) {
    const [a] = await db.insert(articles).values(data).returning();
    return a;
  }

  // === Comments ===
  async getComments(postId: number, userId?: number): Promise<(Comment & { authorName: string; userLiked: boolean; replyCount: number })[]> {
    const results = await db.select({ comment: comments, authorName: users.username })
      .from(comments).innerJoin(users, eq(users.id, comments.userId))
      .where(eq(comments.postId, postId))
      .orderBy(comments.createdAt);

    const enriched = [];
    for (const r of results) {
      let userLiked = false;
      if (userId) {
        const [liked] = await db.select().from(commentLikes).where(and(eq(commentLikes.commentId, r.comment.id), eq(commentLikes.userId, userId)));
        userLiked = !!liked;
      }
      const [{ count: replyCount }] = await db.select({ count: sql<number>`count(*)` }).from(comments).where(eq(comments.parentId, r.comment.id));
      enriched.push({
        ...r.comment,
        authorName: r.comment.isAnonymous ? (r.comment.anonTag || "Анонім") : r.authorName,
        userLiked,
        replyCount: Number(replyCount),
      });
    }
    return enriched;
  }

  async createComment(data: { postId: number; userId: number; content: string; isAnonymous: boolean; parentId?: number; imageUrl?: string }): Promise<Comment> {
    const anonTag = data.isAnonymous ? `Анонім-${crypto.randomBytes(3).toString('hex')}` : null;
    const [c] = await db.insert(comments).values({ ...data, anonTag }).returning();
    return c;
  }

  async toggleCommentLike(commentId: number, userId: number): Promise<{ liked: boolean; likes: number }> {
    const [existing] = await db.select().from(commentLikes).where(and(eq(commentLikes.commentId, commentId), eq(commentLikes.userId, userId)));
    if (existing) {
      await db.delete(commentLikes).where(eq(commentLikes.id, existing.id));
    } else {
      try {
        await db.insert(commentLikes).values({ commentId, userId });
      } catch (e: any) {
        if (e.code === '23505') {
          return this.toggleCommentLike(commentId, userId);
        }
        throw e;
      }
    }
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(commentLikes).where(eq(commentLikes.commentId, commentId));
    const likeCount = Number(count);
    await db.update(comments).set({ likes: likeCount }).where(eq(comments.id, commentId));
    return { liked: !existing, likes: likeCount };
  }

  async getCommentCount(postId: number): Promise<number> {
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(comments).where(eq(comments.postId, postId));
    return Number(count);
  }

  // === Stories ===
  async getStories(): Promise<(Story & { authorName: string })[]> {
    const now = new Date();
    const results = await db.select({ story: stories, authorName: users.username })
      .from(stories).innerJoin(users, eq(users.id, stories.userId))
      .where(gt(stories.expiresAt, now))
      .orderBy(desc(stories.createdAt));
    return results.map(r => ({ ...r.story, authorName: r.authorName }));
  }

  async createStory(data: { userId: number; imageUrl: string; caption?: string; mediaType?: string; textOverlays?: string }): Promise<Story> {
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);
    const [s] = await db.insert(stories).values({ ...data, expiresAt }).returning();
    return s;
  }

  // === Polls ===
  async getPolls(newspaperId: number): Promise<(Poll & { options: (PollOption & { voteCount: number })[]; totalVotes: number })[]> {
    const allPolls = await db.select().from(polls).where(eq(polls.newspaperId, newspaperId)).orderBy(desc(polls.createdAt));
    const result = [];
    for (const p of allPolls) {
      const opts = await db.select().from(pollOptions).where(eq(pollOptions.pollId, p.id));
      const optsWithCounts = [];
      let totalVotes = 0;
      for (const o of opts) {
        const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(pollVotes).where(eq(pollVotes.optionId, o.id));
        const vc = Number(count);
        totalVotes += vc;
        optsWithCounts.push({ ...o, voteCount: vc });
      }
      result.push({ ...p, options: optsWithCounts, totalVotes });
    }
    return result;
  }

  async createPoll(data: { newspaperId: number; creatorId: number; question: string; options: string[] }): Promise<Poll> {
    const [p] = await db.insert(polls).values({ newspaperId: data.newspaperId, creatorId: data.creatorId, question: data.question }).returning();
    for (const text of data.options) {
      await db.insert(pollOptions).values({ pollId: p.id, text });
    }
    return p;
  }

  async votePoll(userId: number, pollId: number, optionId: number): Promise<void> {
    const existing = await db.select().from(pollVotes).where(and(eq(pollVotes.pollId, pollId), eq(pollVotes.userId, userId)));
    if (existing.length > 0) {
      await db.update(pollVotes).set({ optionId }).where(and(eq(pollVotes.pollId, pollId), eq(pollVotes.userId, userId)));
    } else {
      await db.insert(pollVotes).values({ pollId, optionId, userId });
    }
  }

  async getUserPollVote(userId: number, pollId: number): Promise<number | null> {
    const [vote] = await db.select().from(pollVotes).where(and(eq(pollVotes.pollId, pollId), eq(pollVotes.userId, userId)));
    return vote?.optionId || null;
  }

  // === Notifications ===
  async getNotifications(userId: number): Promise<Notification[]> {
    return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(50);
  }

  async getUnreadCount(userId: number): Promise<number> {
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(notifications).where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    return Number(count);
  }

  async createNotification(data: { userId: number; type: string; message: string; fromUserId?: number; postId?: number }): Promise<Notification> {
    if (data.fromUserId === data.userId) return {} as Notification;
    const [n] = await db.insert(notifications).values(data).returning();
    return n;
  }

  async markNotificationsRead(userId: number): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
  }

  // === Search ===
  async searchPosts(query: string): Promise<(Post & { authorName: string })[]> {
    const results = await db.select({ post: posts, authorName: users.username })
      .from(posts).innerJoin(users, eq(users.id, posts.userId))
      .where(ilike(posts.content, `%${query}%`))
      .orderBy(desc(posts.createdAt))
      .limit(20);
    return results.map(r => ({
      ...r.post,
      authorName: r.post.isAnonymous ? (r.post.anonTag || "Анонім") : r.authorName,
    }));
  }

  async searchUsers(query: string): Promise<Pick<User, 'id' | 'username' | 'avatarUrl'>[]> {
    return db.select({ id: users.id, username: users.username, avatarUrl: users.avatarUrl })
      .from(users)
      .where(ilike(users.username, `%${query}%`))
      .limit(20);
  }

  async searchGroups(query: string): Promise<Group[]> {
    return db.select().from(groups).where(ilike(groups.name, `%${query}%`)).limit(20);
  }

  async searchNewspapers(query: string): Promise<any[]> {
    return db.select().from(newspapers).where(ilike(newspapers.name, `%${query}%`)).limit(20);
  }

  // === Schedules ===
  async getSchedules(className?: string): Promise<Schedule[]> {
    if (className) {
      return db.select().from(schedules).where(eq(schedules.className, className)).orderBy(schedules.dayOfWeek, schedules.lessonNumber);
    }
    return db.select().from(schedules).orderBy(schedules.className, schedules.dayOfWeek, schedules.lessonNumber);
  }

  async getClassNames(): Promise<string[]> {
    const results = await db.select({ className: schedules.className }).from(schedules).groupBy(schedules.className).orderBy(schedules.className);
    return results.map(r => r.className);
  }

  async createScheduleEntry(data: { className: string; dayOfWeek: number; lessonNumber: number; subject: string; teacherName?: string; room?: string; creatorId: number }): Promise<Schedule> {
    const [s] = await db.insert(schedules).values(data).returning();
    return s;
  }

  async deleteScheduleEntry(id: number): Promise<void> {
    await db.delete(schedules).where(eq(schedules.id, id));
  }

  // === Achievements ===
  async getUserAchievements(userId: number): Promise<Achievement[]> {
    return db.select().from(achievements).where(eq(achievements.userId, userId)).orderBy(desc(achievements.earnedAt));
  }

  async grantAchievement(data: { userId: number; type: string; title: string; description?: string; icon?: string }): Promise<Achievement | null> {
    const [existing] = await db.select().from(achievements).where(and(eq(achievements.userId, data.userId), eq(achievements.type, data.type)));
    if (existing) return null;
    const [a] = await db.insert(achievements).values(data).returning();
    return a;
  }

  async checkAndGrantAchievements(userId: number): Promise<Achievement[]> {
    const earned: Achievement[] = [];
    const [{ count: postCount }] = await db.select({ count: sql<number>`count(*)` }).from(posts).where(eq(posts.userId, userId));
    const [{ count: commentCount }] = await db.select({ count: sql<number>`count(*)` }).from(comments).where(eq(comments.userId, userId));
    const [{ count: msgCount }] = await db.select({ count: sql<number>`count(*)` }).from(messages).where(eq(messages.senderId, userId));

    const checks = [
      { type: 'first_post', title: 'Перший допис', description: 'Створив перший допис', icon: 'FileText', threshold: 1, count: Number(postCount) },
      { type: 'active_poster', title: 'Активний автор', description: '10 дописів', icon: 'PenTool', threshold: 10, count: Number(postCount) },
      { type: 'prolific_writer', title: 'Плідний письменник', description: '50 дописів', icon: 'Award', threshold: 50, count: Number(postCount) },
      { type: 'first_comment', title: 'Перший коментар', description: 'Написав перший коментар', icon: 'MessageCircle', threshold: 1, count: Number(commentCount) },
      { type: 'commentator', title: 'Коментатор', description: '20 коментарів', icon: 'MessageSquare', threshold: 20, count: Number(commentCount) },
      { type: 'social_butterfly', title: 'Душа компанії', description: '50 повідомлень у чаті', icon: 'Users', threshold: 50, count: Number(msgCount) },
      { type: 'chatterbox', title: 'Балакун', description: '100 повідомлень', icon: 'Zap', threshold: 100, count: Number(msgCount) },
    ];

    for (const c of checks) {
      if (c.count >= c.threshold) {
        const a = await this.grantAchievement({ userId, type: c.type, title: c.title, description: c.description, icon: c.icon });
        if (a) earned.push(a);
      }
    }
    return earned;
  }

  // === Pin/Unpin Posts ===
  async pinPost(postId: number): Promise<void> {
    await db.update(posts).set({ isPinned: false }).where(eq(posts.isPinned, true));
    await db.update(posts).set({ isPinned: true }).where(eq(posts.id, postId));
  }

  async unpinPost(postId: number): Promise<void> {
    await db.update(posts).set({ isPinned: false }).where(eq(posts.id, postId));
  }

  // === Reports ===
  async createReport(data: { reporterId: number; targetType: string; targetId: number; reason: string }): Promise<Report> {
    const [r] = await db.insert(reports).values(data).returning();
    return r;
  }

  async getReports(): Promise<Report[]> {
    return db.select().from(reports).orderBy(desc(reports.createdAt));
  }

  async updateReportStatus(reportId: number, status: string): Promise<void> {
    await db.update(reports).set({ status }).where(eq(reports.id, reportId));
  }

  // === Chat Message Search ===
  async searchMessages(userId: number, otherUserId: number, query: string): Promise<(Message & { senderName: string })[]> {
    const results = await db.select({ message: messages, senderName: users.username })
      .from(messages).innerJoin(users, eq(users.id, messages.senderId))
      .where(and(
        or(
          and(eq(messages.senderId, userId), eq(messages.receiverId, otherUserId)),
          and(eq(messages.senderId, otherUserId), eq(messages.receiverId, userId))
        ),
        ilike(messages.content, `%${query}%`)
      ))
      .orderBy(messages.createdAt);
    return results.map(r => ({ ...r.message, senderName: r.senderName }));
  }

  // === Update Group ===
  async updateGroup(groupId: number, data: { avatarUrl?: string; name?: string; description?: string }): Promise<Group> {
    const [g] = await db.update(groups).set(data).where(eq(groups.id, groupId)).returning();
    return g;
  }

  // === Feed Polls ===
  async createFeedPoll(postId: number, question: string, options: string[]): Promise<void> {
    const [p] = await db.insert(feedPolls).values({ postId, question }).returning();
    for (const text of options) {
      await db.insert(feedPollOptions).values({ pollId: p.id, text });
    }
  }

  async getFeedPoll(postId: number): Promise<{ question: string; options: { id: number; text: string; voteCount: number }[]; totalVotes: number } | null> {
    const [poll] = await db.select().from(feedPolls).where(eq(feedPolls.postId, postId));
    if (!poll) return null;
    const opts = await db.select().from(feedPollOptions).where(eq(feedPollOptions.pollId, poll.id));
    let totalVotes = 0;
    const optsWithCounts = [];
    for (const o of opts) {
      const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(feedPollVotes).where(eq(feedPollVotes.optionId, o.id));
      const vc = Number(count);
      totalVotes += vc;
      optsWithCounts.push({ id: o.id, text: o.text, voteCount: vc });
    }
    return { question: poll.question, options: optsWithCounts, totalVotes };
  }

  async voteFeedPoll(userId: number, pollId: number, optionId: number): Promise<void> {
    const existing = await db.select().from(feedPollVotes).where(and(eq(feedPollVotes.pollId, pollId), eq(feedPollVotes.userId, userId)));
    if (existing.length > 0) {
      await db.update(feedPollVotes).set({ optionId }).where(and(eq(feedPollVotes.pollId, pollId), eq(feedPollVotes.userId, userId)));
    } else {
      await db.insert(feedPollVotes).values({ pollId, optionId, userId });
    }
  }

  async getUserFeedPollVote(userId: number, postId: number): Promise<number | null> {
    const [poll] = await db.select().from(feedPolls).where(eq(feedPolls.postId, postId));
    if (!poll) return null;
    const [vote] = await db.select().from(feedPollVotes).where(and(eq(feedPollVotes.pollId, poll.id), eq(feedPollVotes.userId, userId)));
    return vote?.optionId || null;
  }

  async voteFeedPollByPost(userId: number, postId: number, optionId: number): Promise<void> {
    const [poll] = await db.select().from(feedPolls).where(eq(feedPolls.postId, postId));
    if (!poll) return;
    await this.voteFeedPoll(userId, poll.id, optionId);
  }

  // === Post Shares ===
  async sharePost(postId: number, userId: number): Promise<Post | null> {
    const original = await this.getPost(postId);
    if (!original) return null;

    await db.insert(postShares).values({ postId, userId });

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);
    const [shared] = await db.insert(posts).values({
      userId,
      content: original.content,
      imageUrl: original.imageUrl,
      audioUrl: original.audioUrl,
      isAnonymous: false,
      forwardedFromId: postId,
      expiresAt,
      upvotes: 0,
    }).returning();
    return shared;
  }

  async getShareCount(postId: number): Promise<number> {
    const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(postShares).where(eq(postShares.postId, postId));
    return Number(count);
  }

  // === Recommendations ===
  async getTrendingPosts(): Promise<(Post & { authorName: string; commentCount: number })[]> {
    const results = await db.select({ post: posts, authorName: users.username })
      .from(posts).innerJoin(users, eq(users.id, posts.userId))
      .orderBy(desc(posts.upvotes))
      .limit(5);
    const trending = [];
    for (const r of results) {
      const commentCount = await this.getCommentCount(r.post.id);
      trending.push({
        ...r.post,
        authorName: r.post.isAnonymous ? (r.post.anonTag || "Анонім") : r.authorName,
        commentCount,
      });
    }
    return trending;
  }

  async getPopularNewspapers(): Promise<any[]> {
    const allPapers = await db.select().from(newspapers).orderBy(desc(newspapers.createdAt));
    const result = [];
    for (const p of allPapers) {
      const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(subscriptions).where(eq(subscriptions.newspaperId, p.id));
      result.push({ ...p, subscriberCount: Number(count) });
    }
    return result.sort((a, b) => b.subscriberCount - a.subscriberCount).slice(0, 5);
  }

  // === Wall Posts ===
  async getWallPosts(profileUserId: number): Promise<(WallPost & { authorUsername: string; authorAvatarUrl: string | null })[]> {
    const rows = await db.select({
      id: wallPosts.id,
      profileUserId: wallPosts.profileUserId,
      authorId: wallPosts.authorId,
      content: wallPosts.content,
      createdAt: wallPosts.createdAt,
      authorUsername: users.username,
      authorAvatarUrl: users.avatarUrl,
    })
    .from(wallPosts)
    .innerJoin(users, eq(wallPosts.authorId, users.id))
    .where(eq(wallPosts.profileUserId, profileUserId))
    .orderBy(desc(wallPosts.createdAt));
    return rows;
  }

  async createWallPost(data: { profileUserId: number; authorId: number; content: string }): Promise<WallPost> {
    const [wp] = await db.insert(wallPosts).values(data).returning();
    return wp;
  }

  async deleteWallPost(id: number): Promise<void> {
    await db.delete(wallPosts).where(eq(wallPosts.id, id));
  }

  async getWallPost(id: number): Promise<WallPost | undefined> {
    const [wp] = await db.select().from(wallPosts).where(eq(wallPosts.id, id));
    return wp;
  }

  // === Teacher of the Week ===
  async getTeacherOfTheWeek(): Promise<{ best: (Teacher & { weeklyAvg: number; ratingCount: number }) | null; worst: (Teacher & { weeklyAvg: number; ratingCount: number }) | null }> {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const weeklyRatings = await db.select({
      teacherId: ratings.teacherId,
      avg: sql<number>`AVG((${ratings.category1} + ${ratings.category2} + ${ratings.category3} + ${ratings.category4}) / 4.0)`,
      count: sql<number>`COUNT(*)`,
    })
    .from(ratings)
    .where(gt(ratings.createdAt, oneWeekAgo))
    .groupBy(ratings.teacherId);

    if (weeklyRatings.length === 0) return { best: null, worst: null };

    const withMinVotes = weeklyRatings.filter(r => Number(r.count) >= 1);
    if (withMinVotes.length === 0) return { best: null, worst: null };

    let bestEntry = withMinVotes[0];
    let worstEntry = withMinVotes[0];
    for (const r of withMinVotes) {
      if (Number(r.avg) > Number(bestEntry.avg)) bestEntry = r;
      if (Number(r.avg) < Number(worstEntry.avg)) worstEntry = r;
    }

    const bestTeacher = await this.getTeacher(bestEntry.teacherId);
    const worstTeacher = bestEntry.teacherId !== worstEntry.teacherId ? await this.getTeacher(worstEntry.teacherId) : null;

    return {
      best: bestTeacher ? { ...bestTeacher, weeklyAvg: Math.round(Number(bestEntry.avg) * 10) / 10, ratingCount: Number(bestEntry.count) } : null,
      worst: worstTeacher ? { ...worstTeacher, weeklyAvg: Math.round(Number(worstEntry.avg) * 10) / 10, ratingCount: Number(worstEntry.count) } : null,
    };
  }

  // === Maintenance ===
  async cleanupOldContent(): Promise<void> {
    const now = new Date();
    await db.delete(posts).where(lt(posts.expiresAt, now));
    await db.delete(messages).where(lt(messages.expiresAt, now));
  }

  // === Seed ===
  async seedInitialData(): Promise<void> {
    const existingPosts = await db.select({ id: posts.id }).from(posts).limit(1);
    if (existingPosts.length > 0) return;

    let [seedUser] = await db.select().from(users).where(eq(users.username, "campus_bot"));
    if (!seedUser) {
      [seedUser] = await db.insert(users).values({ username: "campus_bot", password: "no_login", isAdmin: true, isOfficial: true }).returning();
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const seedPosts = [
      { content: "Campus запущено! Вітаємо всіх у шкільній мережі. Пишіть, спілкуйтесь, оцінюйте вчителів!", isAnonymous: false },
      { content: "Хто знає, коли наступна контрольна з математики?", isAnonymous: true },
      { content: "Наша школа найкраща! Хто згоден - лайк!", isAnonymous: true },
      { content: "Порада дня: не забувайте пити воду між уроками", isAnonymous: true },
      { content: "Шукаю людей для підготовки до олімпіади з фізики. Хто зі мною?", isAnonymous: false },
      { content: "Сьогодні в їдальні були неймовірні булочки. Хто пробував?", isAnonymous: true },
      { content: "Хто загубив синю ручку біля 302 кабінету? Лежить на підвіконні.", isAnonymous: true },
      { content: "Завтра День вчителя! Не забудьте привітати своїх улюблених педагогів.", isAnonymous: false },
    ];

    for (const p of seedPosts) {
      const anonTag = p.isAnonymous ? `Анонім-${crypto.randomBytes(3).toString('hex')}` : null;
      await db.insert(posts).values({
        userId: seedUser.id,
        content: p.content,
        isAnonymous: p.isAnonymous,
        anonTag,
        upvotes: Math.floor(Math.random() * 15),
        expiresAt,
      });
    }

    const existingPapers = await db.select().from(newspapers).limit(1);
    if (existingPapers.length === 0) {
      await db.insert(newspapers).values([
        { name: "Campus Official", type: "official", description: "Офіційні новини та оновлення Campus", creatorId: seedUser.id, isAnonymous: false, writeCode: crypto.randomBytes(3).toString('hex') },
        { name: "Вільна газета", type: "free", description: "Без фільтрів, у рамках закону", creatorId: seedUser.id, isAnonymous: true, writeCode: crypto.randomBytes(3).toString('hex') },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
