import { useEffect } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useNotifications, useMarkNotificationsRead } from "@/hooks/use-data";
import { Bell, Heart, MessageCircle, AtSign, Share2, MessageSquare, Award, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";
import { Link } from "wouter";

const typeIcons: Record<string, any> = {
  reaction: Heart,
  comment: MessageCircle,
  mention: AtSign,
  share: Share2,
  message: MessageSquare,
  achievement: Award,
};

const typeColors: Record<string, string> = {
  reaction: "text-red-500 bg-red-50",
  comment: "text-blue-500 bg-blue-50",
  mention: "text-purple-500 bg-purple-50",
  share: "text-green-500 bg-green-50",
  message: "text-primary bg-primary/10",
  achievement: "text-yellow-500 bg-yellow-50",
};

export default function NotificationsPage() {
  const { data, isLoading } = useNotifications();
  const { mutate: markRead } = useMarkNotificationsRead();

  useEffect(() => {
    if (data?.unreadCount > 0) markRead();
  }, [data?.unreadCount]);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        <div className="max-w-xl mx-auto pt-6 px-4">
          <h1 className="text-xl font-bold mb-4 flex items-center gap-2" data-testid="text-notifications-title">
            <Bell className="w-5 h-5 text-primary" />
            Сповіщення
          </h1>

          {isLoading && (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          )}

          {!isLoading && (!data?.notifications || data.notifications.length === 0) && (
            <Card className="text-center py-12">
              <Bell className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm text-muted-foreground">Немає сповіщень</p>
            </Card>
          )}

          <div className="space-y-2">
            {data?.notifications?.map((n: any) => {
              const IconComp = typeIcons[n.type] || Bell;
              const colors = typeColors[n.type] || "text-gray-500 bg-muted";
              const [textColor, bgColor] = colors.split(" ");

              return (
                <NotificationCard key={n.id} n={n} IconComp={IconComp} textColor={textColor} bgColor={bgColor} />
              );
            })}
          </div>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}

function NotificationCard({ n, IconComp, textColor, bgColor }: { n: any; IconComp: any; textColor: string; bgColor: string }) {
  const getLink = () => {
    if (n.type === 'message' && n.fromUserId) return `/chat`;
    if (n.fromUserId && (n.type === 'reaction' || n.type === 'comment' || n.type === 'mention' || n.type === 'share')) return `/`;
    if (n.fromUserId) return `/profile/${n.fromUserId}`;
    return null;
  };

  const link = getLink();
  const content = (
    <Card
      className={`p-3 flex items-start gap-3 ${!n.isRead ? "border-l-2 border-l-primary bg-primary/[0.02]" : ""} ${link ? "cursor-pointer hover:bg-muted transition-colors" : ""}`}
      data-testid={`notification-${n.id}`}
    >
      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${bgColor}`}>
        <IconComp className={`w-4 h-4 ${textColor}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-foreground">{n.message}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {n.createdAt && formatDistanceToNow(new Date(n.createdAt), { addSuffix: true, locale: uk })}
        </p>
      </div>
    </Card>
  );

  if (link) {
    return <Link href={link}>{content}</Link>;
  }
  return content;
}
