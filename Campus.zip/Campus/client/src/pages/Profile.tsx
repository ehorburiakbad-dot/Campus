import { useState, useRef } from "react";
import { useRoute, Link } from "wouter";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useProfile, useUpdateProfile } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Camera, Edit2, Save, X, FileText, PenTool, Award,
  MessageCircle, MessageSquare, Users, Zap, Loader2,
  MapPin, Globe, Palette, Smile, ImagePlus, Check, Sparkles,
  Send, Trash2, PenLine, Shield
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { VerifiedBadge } from "@/components/VerifiedBadge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";

const achievementIcons: Record<string, any> = {
  FileText, PenTool, Award, MessageCircle, MessageSquare, Users, Zap,
};

const MOODS = [
  { value: "happy", label: "Щасливий", icon: "sun" },
  { value: "chill", label: "Розслаблений", icon: "coffee" },
  { value: "studying", label: "Навчаюсь", icon: "book" },
  { value: "creative", label: "Креативний", icon: "palette" },
  { value: "gaming", label: "Граю", icon: "gamepad" },
  { value: "sleepy", label: "Сонний", icon: "moon" },
  { value: "excited", label: "Захоплений", icon: "star" },
  { value: "thinking", label: "Думаю", icon: "brain" },
];

const PROFILE_COLORS = [
  { value: "blue", label: "Синій", bg: "bg-blue-500", ring: "ring-blue-500" },
  { value: "purple", label: "Фіолетовий", bg: "bg-purple-500", ring: "ring-purple-500" },
  { value: "pink", label: "Рожевий", bg: "bg-pink-500", ring: "ring-pink-500" },
  { value: "red", label: "Червоний", bg: "bg-red-500", ring: "ring-red-500" },
  { value: "orange", label: "Помаранчевий", bg: "bg-orange-500", ring: "ring-orange-500" },
  { value: "green", label: "Зелений", bg: "bg-green-500", ring: "ring-green-500" },
  { value: "teal", label: "Бірюзовий", bg: "bg-teal-500", ring: "ring-teal-500" },
  { value: "cyan", label: "Блакитний", bg: "bg-cyan-500", ring: "ring-cyan-500" },
  { value: "yellow", label: "Жовтий", bg: "bg-yellow-500", ring: "ring-yellow-500" },
  { value: "slate", label: "Сірий", bg: "bg-slate-500", ring: "ring-slate-500" },
];

function getColorClasses(color: string | null | undefined) {
  const found = PROFILE_COLORS.find(c => c.value === color);
  return found || PROFILE_COLORS[0];
}

function getHeaderGradient(color: string | null | undefined) {
  const gradients: Record<string, string> = {
    blue: "from-blue-400 to-blue-600",
    purple: "from-purple-400 to-purple-600",
    pink: "from-pink-400 to-pink-600",
    red: "from-red-400 to-red-600",
    orange: "from-orange-400 to-orange-600",
    green: "from-green-400 to-green-600",
    teal: "from-teal-400 to-teal-600",
    cyan: "from-cyan-400 to-cyan-600",
    yellow: "from-yellow-400 to-yellow-600",
    slate: "from-slate-400 to-slate-600",
  };
  return gradients[color || "blue"] || gradients.blue;
}

function getMoodLabel(mood: string | null | undefined) {
  if (!mood) return null;
  return MOODS.find(m => m.value === mood);
}

export default function Profile() {
  const [, params] = useRoute("/profile/:id");
  const profileId = params?.id ? Number(params.id) : null;
  const { user: me } = useAuth();
  const { data: profile, isLoading } = useProfile(profileId);
  const { mutate: updateProfile, isPending } = useUpdateProfile();
  const [editOpen, setEditOpen] = useState(false);

  const isOwn = me?.id === profileId;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background pb-20 md:pb-0">
        <Sidebar />
        <main className="md:ml-60 pb-20 md:pb-6 flex items-center justify-center min-h-screen">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </main>
        <BottomNav />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background pb-20 md:pb-0">
        <Sidebar />
        <main className="md:ml-60 pb-20 md:pb-6 flex items-center justify-center min-h-screen">
          <p className="text-muted-foreground">Профіль не знайдено</p>
        </main>
        <BottomNav />
      </div>
    );
  }

  const user = profile.user;
  const colorClasses = getColorClasses(user.profileColor);
  const headerGradient = getHeaderGradient(user.profileColor);
  const moodInfo = getMoodLabel(user.mood);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        <div className="max-w-xl mx-auto">
          <div className="relative" data-testid="profile-header-section">
            <div
              className={`h-40 sm:h-48 w-full bg-gradient-to-r ${headerGradient} relative overflow-hidden`}
              data-testid="profile-header-cover"
            >
              {user.headerUrl && (
                <img src={user.headerUrl} alt="" className="w-full h-full object-cover absolute inset-0" />
              )}
              <div className="absolute inset-0 bg-black/10" />
            </div>

            <div className="px-4 relative">
              <div className="flex items-end justify-between -mt-12 sm:-mt-14">
                <ProfileAvatar user={user} isOwn={isOwn} onAvatarChange={(file) => updateProfile({ avatar: file })} colorClasses={colorClasses} />
                {isOwn && (
                  <div className="flex items-center gap-2 mb-0 mt-14">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditOpen(true)}
                      data-testid="button-edit-profile"
                    >
                      <Edit2 className="w-3.5 h-3.5 mr-1.5" />
                      Редагувати
                    </Button>
                    {me?.isAdmin && (
                      <Link href="/admin">
                        <Button
                          size="sm"
                          variant="destructive"
                          data-testid="button-admin-panel"
                        >
                          <Shield className="w-3.5 h-3.5 mr-1.5" />
                          Адмін
                        </Button>
                      </Link>
                    )}
                  </div>
                )}
              </div>

              <div className="mt-3 pb-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-bold" data-testid="text-profile-displayname">
                    {user.displayName || user.username}
                  </h1>
                  <VerifiedBadge isAdmin={user.isAdmin} isOfficial={user.isOfficial} />
                </div>

                {user.displayName && (
                  <p className="text-sm text-muted-foreground" data-testid="text-profile-username">@{user.username}</p>
                )}

                {user.statusText && (
                  <p className="text-sm mt-1 italic text-muted-foreground" data-testid="text-profile-status">
                    &ldquo;{user.statusText}&rdquo;
                  </p>
                )}

                {moodInfo && (
                  <div className="flex items-center gap-1.5 mt-2" data-testid="text-profile-mood">
                    <Smile className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{moodInfo.label}</span>
                  </div>
                )}

                {user.bio && (
                  <p className="text-sm mt-2 leading-relaxed" data-testid="text-bio">{user.bio}</p>
                )}

                <div className="flex items-center gap-4 mt-3 flex-wrap">
                  {user.location && (
                    <span className="flex items-center gap-1 text-xs text-muted-foreground" data-testid="text-profile-location">
                      <MapPin className="w-3.5 h-3.5" />
                      {user.location}
                    </span>
                  )}
                  {user.website && (
                    <a
                      href={user.website.startsWith('http') ? user.website : `https://${user.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs text-primary hover:underline"
                      data-testid="link-profile-website"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      {user.website.replace(/^https?:\/\//, '')}
                    </a>
                  )}
                </div>

                <div className="flex gap-4 mt-3 text-sm text-muted-foreground">
                  <span data-testid="text-post-count"><strong className="text-foreground">{profile.postCount}</strong> дописів</span>
                  <span data-testid="text-achievement-count"><strong className="text-foreground">{profile.achievementCount}</strong> досягнень</span>
                </div>
              </div>
            </div>
          </div>

          {profile.achievements?.length > 0 && (
            <div className="px-4 mt-2">
              <Card className="p-4" data-testid="card-achievements">
                <h2 className="font-bold text-sm mb-3 flex items-center gap-2">
                  <Award className="w-4 h-4 text-primary" />
                  Досягнення
                </h2>
                <div className="grid grid-cols-2 gap-2">
                  {profile.achievements.map((a: any) => {
                    const IconComp = achievementIcons[a.icon] || Award;
                    return (
                      <div key={a.id} className="flex items-center gap-2 p-2 rounded-lg bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-100 dark:from-yellow-950/30 dark:to-orange-950/30 dark:border-yellow-900/30" data-testid={`achievement-${a.type}`}>
                        <div className="w-8 h-8 rounded-full bg-yellow-100 dark:bg-yellow-900/40 flex items-center justify-center flex-shrink-0">
                          <IconComp className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-semibold truncate">{a.title}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{a.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            </div>
          )}

          <WallSection profileUserId={profileId!} isOwn={isOwn} />
        </div>
      </main>
      <BottomNav />

      {editOpen && (
        <ProfileEditDialog
          user={user}
          open={editOpen}
          onOpenChange={setEditOpen}
          onSave={updateProfile}
          isPending={isPending}
        />
      )}
    </div>
  );
}

function ProfileAvatar({ user, isOwn, onAvatarChange, colorClasses }: {
  user: any; isOwn: boolean; onAvatarChange: (file: File) => void; colorClasses: any;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="relative">
      <div className={`w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-background bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/40 dark:to-blue-800/40 flex items-center justify-center text-primary font-bold text-3xl overflow-hidden flex-shrink-0 ring-2 ${colorClasses.ring}`} data-testid="img-profile-avatar">
        {user.avatarUrl ? (
          <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" />
        ) : (
          user.username.charAt(0).toUpperCase()
        )}
      </div>
      {isOwn && (
        <>
          <button
            onClick={() => fileRef.current?.click()}
            className="absolute bottom-0 right-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center border-2 border-background"
            data-testid="button-change-avatar"
          >
            <Camera className="w-4 h-4" />
          </button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => {
            const f = e.target.files?.[0];
            if (f) onAvatarChange(f);
            e.target.value = '';
          }} data-testid="input-avatar" />
        </>
      )}
    </div>
  );
}

function WallSection({ profileUserId, isOwn }: { profileUserId: number; isOwn: boolean }) {
  const [wallText, setWallText] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: me } = useAuth();

  const { data: wallPosts, isLoading } = useQuery<any[]>({
    queryKey: ['/api/wall', profileUserId],
    queryFn: async () => {
      const res = await fetch(`/api/wall/${profileUserId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { mutate: postOnWall, isPending } = useMutation({
    mutationFn: async (content: string) => {
      const res = await fetch(`/api/wall/${profileUserId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/wall', profileUserId] });
      setWallText("");
    },
    onError: () => toast({ variant: "destructive", title: "Помилка" }),
  });

  const { mutate: deleteWallPost } = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/wall/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/wall', profileUserId] }),
  });

  return (
    <div className="px-4 mt-4">
      <Card className="p-4" data-testid="card-wall">
        <h2 className="font-bold text-sm mb-3 flex items-center gap-2">
          <PenLine className="w-4 h-4 text-primary" />
          Стіна
        </h2>

        <div className="flex gap-2 mb-4">
          <textarea
            value={wallText}
            onChange={e => setWallText(e.target.value)}
            placeholder={isOwn ? "Напишіть на своїй стіні..." : "Напишіть на стіні..."}
            maxLength={500}
            rows={2}
            className="flex-1 p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
            data-testid="input-wall-post"
          />
          <Button
            size="icon"
            onClick={() => wallText.trim() && postOnWall(wallText)}
            disabled={isPending || !wallText.trim()}
            data-testid="button-post-wall"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        {isLoading && <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>}

        {wallPosts && wallPosts.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-4">Стіна порожня. Будьте першим!</p>
        )}

        <div className="space-y-3">
          {wallPosts?.map((wp: any) => (
            <div key={wp.id} className="flex gap-3 group" data-testid={`wall-post-${wp.id}`}>
              <Link href={`/profile/${wp.authorId}`}>
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs overflow-hidden flex-shrink-0">
                  {wp.authorAvatarUrl ? (
                    <img src={wp.authorAvatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    wp.authorUsername.charAt(0).toUpperCase()
                  )}
                </div>
              </Link>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Link href={`/profile/${wp.authorId}`}>
                    <span className="text-sm font-semibold hover:underline" data-testid={`text-wall-author-${wp.id}`}>{wp.authorUsername}</span>
                  </Link>
                  <span className="text-[10px] text-muted-foreground">
                    {wp.createdAt && formatDistanceToNow(new Date(wp.createdAt), { addSuffix: true, locale: uk })}
                  </span>
                </div>
                <p className="text-sm mt-0.5 break-words" data-testid={`text-wall-content-${wp.id}`}>{wp.content}</p>
              </div>
              {(wp.authorId === me?.id || isOwn || me?.isAdmin) && (
                <button
                  onClick={() => deleteWallPost(wp.id)}
                  className="invisible group-hover:visible flex-shrink-0 text-muted-foreground hover:text-destructive transition-colors p-1"
                  data-testid={`button-delete-wall-${wp.id}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function ProfileEditDialog({ user, open, onOpenChange, onSave, isPending }: {
  user: any; open: boolean; onOpenChange: (v: boolean) => void; onSave: any; isPending: boolean;
}) {
  const [displayName, setDisplayName] = useState(user.displayName || "");
  const [bio, setBio] = useState(user.bio || "");
  const [statusText, setStatusText] = useState(user.statusText || "");
  const [mood, setMood] = useState(user.mood || "");
  const [profileColor, setProfileColor] = useState(user.profileColor || "blue");
  const [location, setLocation] = useState(user.location || "");
  const [website, setWebsite] = useState(user.website || "");
  const [headerFile, setHeaderFile] = useState<File | null>(null);
  const [headerPreview, setHeaderPreview] = useState<string | null>(user.headerUrl || null);
  const headerRef = useRef<HTMLInputElement>(null);

  const handleHeaderSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setHeaderFile(file);
      const reader = new FileReader();
      reader.onload = () => setHeaderPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
    e.target.value = '';
  };

  const handleSave = () => {
    const data: any = { displayName, bio, statusText, mood, profileColor, location, website };
    if (headerFile) data.header = headerFile;
    onSave(data, {
      onSuccess: () => onOpenChange(false),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Налаштування профілю
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 mt-2">
          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Обкладинка</label>
            <div
              className={`h-24 rounded-lg bg-gradient-to-r ${getHeaderGradient(profileColor)} relative overflow-hidden cursor-pointer group`}
              onClick={() => headerRef.current?.click()}
              data-testid="button-change-header"
            >
              {headerPreview && <img src={headerPreview} alt="" className="w-full h-full object-cover absolute inset-0" />}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                <ImagePlus className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
            <input ref={headerRef} type="file" accept="image/*" className="hidden" onChange={handleHeaderSelect} data-testid="input-header" />
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">Відображуване ім'я</label>
            <input
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder={user.username}
              maxLength={30}
              className="w-full p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
              data-testid="input-display-name"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">Статус</label>
            <input
              value={statusText}
              onChange={e => setStatusText(e.target.value)}
              placeholder="Що у вас на думці?"
              maxLength={100}
              className="w-full p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
              data-testid="input-status"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">Про себе</label>
            <textarea
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Розкажіть про себе..."
              maxLength={300}
              rows={3}
              className="w-full p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 resize-none"
              data-testid="input-bio"
            />
            <p className="text-[10px] text-muted-foreground text-right mt-0.5">{bio.length}/300</p>
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">Настрій</label>
            <div className="flex flex-wrap gap-1.5">
              {MOODS.map(m => (
                <button
                  key={m.value}
                  onClick={() => setMood(mood === m.value ? "" : m.value)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors border ${
                    mood === m.value
                      ? "bg-primary text-white border-primary"
                      : "bg-muted text-muted-foreground border-border hover:border-primary/30"
                  }`}
                  data-testid={`button-mood-${m.value}`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 block">
              <Palette className="w-3.5 h-3.5 inline mr-1" />
              Колір профілю
            </label>
            <div className="flex flex-wrap gap-2">
              {PROFILE_COLORS.map(c => (
                <button
                  key={c.value}
                  onClick={() => setProfileColor(c.value)}
                  className={`w-8 h-8 rounded-full ${c.bg} transition-all flex items-center justify-center ${
                    profileColor === c.value ? "ring-2 ring-offset-2 ring-offset-background " + c.ring + " scale-110" : "hover:scale-105"
                  }`}
                  title={c.label}
                  data-testid={`button-color-${c.value}`}
                >
                  {profileColor === c.value && <Check className="w-4 h-4 text-white" />}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                Локація
              </label>
              <input
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="Місто, країна"
                maxLength={50}
                className="w-full p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                data-testid="input-location"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Globe className="w-3 h-3" />
                Вебсайт
              </label>
              <input
                value={website}
                onChange={e => setWebsite(e.target.value)}
                placeholder="example.com"
                maxLength={100}
                className="w-full p-2.5 bg-muted rounded-lg text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                data-testid="input-website"
              />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button onClick={handleSave} disabled={isPending} className="flex-1" data-testid="button-save-profile">
              {isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              Зберегти
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel-edit">
              Скасувати
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
