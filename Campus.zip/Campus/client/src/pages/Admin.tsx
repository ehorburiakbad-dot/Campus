import { useState } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAdminReports, useUpdateReportStatus } from "@/hooks/use-data";
import {
  Shield, Users, Newspaper, MessageSquare, FileText,
  Trash2, Crown, ShieldCheck, Ban, ArrowLeft, Activity,
  UserCheck, Eye, Flag, Check, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Redirect } from "wouter";

type Tab = 'stats' | 'users' | 'newspapers' | 'posts' | 'reports';

export default function Admin() {
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>('stats');

  if (!user?.isAdmin) return <Redirect to="/" />;

  const tabs: { id: Tab; label: string; icon: any }[] = [
    { id: 'stats', label: "Статистика", icon: Activity },
    { id: 'users', label: "Користувачі", icon: Users },
    { id: 'newspapers', label: "Газети", icon: Newspaper },
    { id: 'posts', label: "Пости", icon: FileText },
    { id: 'reports', label: "Скарги", icon: Flag },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <div className="md:ml-60 pb-20 md:pb-4">
        <div className="bg-card border-b border-border sticky top-0 z-30">
          <div className="max-w-3xl mx-auto px-4 py-3 flex items-center gap-3">
            <Shield className="w-6 h-6 text-red-500" />
            <h1 className="text-xl font-bold" data-testid="text-admin-title">Адмін-панель</h1>
          </div>
          <div className="max-w-3xl mx-auto px-4 flex gap-1 overflow-x-auto pb-1">
            {tabs.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg whitespace-nowrap transition-colors",
                  tab === t.id ? "bg-red-50 text-red-600" : "text-gray-500 hover:bg-gray-100"
                )}
                data-testid={`tab-${t.id}`}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="max-w-3xl mx-auto p-4">
          {tab === 'stats' && <StatsPanel />}
          {tab === 'users' && <UsersPanel />}
          {tab === 'newspapers' && <NewspapersPanel />}
          {tab === 'posts' && <PostsPanel />}
          {tab === 'reports' && <ReportsPanel />}
        </div>
      </div>
      <BottomNav />
    </div>
  );
}

function StatsPanel() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
    queryFn: async () => {
      const res = await fetch('/api/admin/stats', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    refetchInterval: 10000,
  });

  if (isLoading) return <div className="text-center py-8 text-gray-500">Завантаження...</div>;

  const cards = [
    { label: "Зареєстровано", value: stats?.totalUsers || 0, icon: Users, color: "bg-blue-50 text-blue-600" },
    { label: "Онлайн зараз", value: stats?.onlineUsers || 0, icon: Eye, color: "bg-green-50 text-green-600" },
    { label: "Постів", value: stats?.totalPosts || 0, icon: FileText, color: "bg-purple-50 text-purple-600" },
    { label: "Газет", value: stats?.totalNewspapers || 0, icon: Newspaper, color: "bg-amber-50 text-amber-600" },
    { label: "Повідомлень", value: stats?.totalMessages || 0, icon: MessageSquare, color: "bg-pink-50 text-pink-600" },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {cards.map(c => (
        <div key={c.label} className="bg-card rounded-xl p-4 border border-border" data-testid={`stat-${c.label.toLowerCase()}`}>
          <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center mb-3", c.color)}>
            <c.icon className="w-5 h-5" />
          </div>
          <p className="text-2xl font-bold">{c.value}</p>
          <p className="text-sm text-muted-foreground">{c.label}</p>
        </div>
      ))}
    </div>
  );
}

function UsersPanel() {
  const { data: usersList, isLoading } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const res = await fetch('/api/admin/users', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const qc = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();

  const toggleField = useMutation({
    mutationFn: async ({ id, field, value }: { id: number; field: string; value: boolean }) => {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ field, value }), credentials: "include",
      });
      if (!res.ok) throw new Error("Error");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({ title: "Оновлено!" });
    },
  });

  const deleteUser = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message); }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/users'] });
      qc.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({ title: "Користувача видалено" });
    },
    onError: (e: any) => toast({ variant: "destructive", title: "Помилка", description: e.message }),
  });

  const unban = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/unban/${id}`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Error");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({ title: "Розбанено!" });
    },
  });

  if (isLoading) return <div className="text-center py-8 text-gray-500">Завантаження...</div>;

  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground mb-3">{usersList?.length || 0} користувачів</p>
      {usersList?.map((u: any) => {
        const isBanned = u.banUntil && new Date(u.banUntil) > new Date();
        const isSelf = u.id === currentUser?.id;
        return (
          <div key={u.id} className="bg-card rounded-xl p-4 border border-border flex items-center gap-3 flex-wrap" data-testid={`user-row-${u.id}`}>
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
              {u.username.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-[120px]">
              <p className="font-medium text-sm flex items-center gap-1.5 flex-wrap">
                {u.username}
                {u.isAdmin && <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full font-medium">Адмін</span>}
                {u.isOfficial && <span className="text-[10px] bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded-full font-medium">Офіціал</span>}
                {isBanned && <span className="text-[10px] bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded-full font-medium">Бан</span>}
              </p>
              <p className="text-xs text-muted-foreground">Постів: {u.postCount || 0}</p>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {!isSelf && (
                <>
                  <button
                    onClick={() => toggleField.mutate({ id: u.id, field: 'isAdmin', value: !u.isAdmin })}
                    className={cn("p-2 rounded-lg text-xs transition-colors", u.isAdmin ? "bg-red-100 text-red-600" : "bg-gray-100 text-gray-500 hover:bg-gray-200")}
                    title={u.isAdmin ? "Забрати адміна" : "Дати адміна"}
                    data-testid={`button-toggle-admin-${u.id}`}
                  >
                    <ShieldCheck className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => toggleField.mutate({ id: u.id, field: 'isOfficial', value: !u.isOfficial })}
                    className={cn("p-2 rounded-lg text-xs transition-colors", u.isOfficial ? "bg-yellow-100 text-yellow-700" : "bg-gray-100 text-gray-500 hover:bg-gray-200")}
                    title={u.isOfficial ? "Забрати офіціала" : "Дати офіціала"}
                    data-testid={`button-toggle-official-${u.id}`}
                  >
                    <Crown className="w-4 h-4" />
                  </button>
                  {isBanned && (
                    <button
                      onClick={() => unban.mutate(u.id)}
                      className="p-2 rounded-lg bg-green-100 text-green-600 text-xs hover:bg-green-200 transition-colors"
                      title="Розбанити"
                      data-testid={`button-unban-${u.id}`}
                    >
                      <UserCheck className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    onClick={() => { if (confirm(`Видалити ${u.username}?`)) deleteUser.mutate(u.id); }}
                    className="p-2 rounded-lg bg-gray-100 text-gray-400 hover:bg-red-100 hover:text-red-500 text-xs transition-colors"
                    title="Видалити"
                    data-testid={`button-delete-user-${u.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </>
              )}
              {isSelf && <span className="text-xs text-muted-foreground">Це ви</span>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function NewspapersPanel() {
  const { data: papers, isLoading } = useQuery({
    queryKey: ['/api/admin/newspapers'],
    queryFn: async () => {
      const res = await fetch('/api/admin/newspapers', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const qc = useQueryClient();
  const { toast } = useToast();

  const changeType = useMutation({
    mutationFn: async ({ id, type }: { id: number; type: string }) => {
      const res = await fetch(`/api/admin/newspapers/${id}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type }), credentials: "include",
      });
      if (!res.ok) throw new Error("Error");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/newspapers'] });
      toast({ title: "Тип змінено!" });
    },
  });

  const deleteNewspaper = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/newspapers/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Error");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/newspapers'] });
      qc.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({ title: "Газету видалено" });
    },
  });

  const typeLabels: Record<string, string> = { official: "Офіційна", user: "Користувацька", free: "Вільна" };
  const typeColors: Record<string, string> = { official: "text-yellow-700 bg-yellow-50", user: "text-blue-600 bg-blue-50", free: "text-green-600 bg-green-50" };

  if (isLoading) return <div className="text-center py-8 text-gray-500">Завантаження...</div>;

  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground mb-3">{papers?.length || 0} газет</p>
      {papers?.map((p: any) => (
        <div key={p.id} className="bg-card rounded-xl p-4 border border-border" data-testid={`newspaper-row-${p.id}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Newspaper className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-sm">{p.name}</p>
              <span className={cn("text-[10px] px-2 py-0.5 rounded-full font-medium", typeColors[p.type] || "bg-gray-100 text-gray-600")}>
                {typeLabels[p.type] || p.type}
              </span>
            </div>
            <button
              onClick={() => { if (confirm(`Видалити "${p.name}"?`)) deleteNewspaper.mutate(p.id); }}
              className="p-2 rounded-lg bg-gray-100 text-gray-400 hover:bg-red-100 hover:text-red-500 transition-colors"
              data-testid={`button-delete-newspaper-${p.id}`}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
          <div className="flex gap-1.5">
            {['official', 'user', 'free'].map(t => (
              <button
                key={t}
                onClick={() => changeType.mutate({ id: p.id, type: t })}
                disabled={p.type === t}
                className={cn(
                  "text-xs px-3 py-1.5 rounded-full font-medium transition-colors",
                  p.type === t ? "ring-2 ring-primary/30 opacity-100" : "opacity-60 hover:opacity-100",
                  typeColors[t]
                )}
                data-testid={`button-type-${t}-${p.id}`}
              >
                {typeLabels[t]}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function PostsPanel() {
  const { data: postsList, isLoading } = useQuery({
    queryKey: ['/api/admin/posts'],
    queryFn: async () => {
      const res = await fetch('/api/admin/posts', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const qc = useQueryClient();
  const { toast } = useToast();

  const deletePost = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/posts/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Error");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['/api/admin/posts'] });
      qc.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      toast({ title: "Пост видалено" });
    },
  });

  if (isLoading) return <div className="text-center py-8 text-gray-500">Завантаження...</div>;

  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground mb-3">{postsList?.length || 0} постів</p>
      {postsList?.map((p: any) => (
        <div key={p.id} className="bg-card rounded-xl p-4 border border-border" data-testid={`post-row-${p.id}`}>
          <div className="flex items-start gap-3">
            <div className="flex-1">
              <p className="text-xs text-muted-foreground mb-1">{p.authorName}</p>
              <p className="text-sm">{p.content.length > 150 ? p.content.slice(0, 150) + "..." : p.content}</p>
              <p className="text-[11px] text-muted-foreground mt-1">Лайків: {p.upvotes || 0}</p>
            </div>
            <button
              onClick={() => deletePost.mutate(p.id)}
              className="p-2 rounded-lg bg-gray-100 text-gray-400 hover:bg-red-100 hover:text-red-500 transition-colors flex-shrink-0"
              data-testid={`button-delete-post-${p.id}`}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      ))}
      {postsList?.length === 0 && <p className="text-center text-gray-400 py-8">Немає постів</p>}
    </div>
  );
}

function ReportsPanel() {
  const { data: reportsList, isLoading } = useAdminReports();
  const { mutate: updateStatus } = useUpdateReportStatus();

  const statusLabels: Record<string, string> = { pending: "Очікує", reviewed: "Переглянуто", dismissed: "Відхилено" };
  const statusColors: Record<string, string> = { 
    pending: "bg-amber-100 text-amber-700",
    reviewed: "bg-green-100 text-green-700",
    dismissed: "bg-gray-100 text-gray-500"
  };

  if (isLoading) return <div className="text-center py-8 text-gray-500">Завантаження...</div>;

  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground mb-3">{reportsList?.length || 0} скарг</p>
      {(!reportsList || reportsList.length === 0) && (
        <div className="text-center py-12 text-muted-foreground">
          <Flag className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p className="text-sm">Немає скарг</p>
        </div>
      )}
      {reportsList?.map((r: any) => (
        <div key={r.id} className="bg-card rounded-xl p-4 border border-border" data-testid={`report-row-${r.id}`}>
          <div className="flex items-start gap-3">
            <Flag className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="text-xs font-medium">
                  {r.targetType === 'post' ? 'Пост' : 'Повідомлення'} #{r.targetId}
                </span>
                <span className={cn(
                  "text-[10px] px-2 py-0.5 rounded-full font-medium",
                  statusColors[r.status] || statusColors.pending
                )}>
                  {statusLabels[r.status] || r.status}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{r.reason}</p>
              <p className="text-[11px] text-muted-foreground">Від користувача #{r.reporterId}</p>
            </div>
            {r.status === 'pending' && (
              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={() => updateStatus({ reportId: r.id, status: 'reviewed' })}
                  className="p-2 rounded-lg bg-green-100 text-green-600 hover:bg-green-200 transition-colors"
                  title="Переглянуто"
                  data-testid={`button-review-report-${r.id}`}
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => updateStatus({ reportId: r.id, status: 'dismissed' })}
                  className="p-2 rounded-lg bg-gray-100 text-gray-400 hover:bg-gray-200 transition-colors"
                  title="Відхилити"
                  data-testid={`button-dismiss-report-${r.id}`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
