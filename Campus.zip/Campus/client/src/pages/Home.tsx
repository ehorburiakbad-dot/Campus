import { useState, useRef, useCallback, useEffect } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { usePosts, useCreatePost, useVotePost, useReactPost, useSharePost, useComments, useCreateComment, useLikeComment, useStories, useCreateStory, useRecommendations, useUsers, useDeletePost, usePinPost, useCreateReport, useVoteFeedPoll } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { ThumbsUp, Send, Loader2, Eye, EyeOff, ImagePlus, MessageCircle, X, Plus, TrendingUp, Newspaper, Heart, Reply, Image, Share2, Mic, Square, MoreVertical, Pin, Trash2, Flag, BarChart3, AlertTriangle, Search } from "lucide-react";
import { VerifiedBadge } from "@/components/VerifiedBadge";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";

const REACTION_TYPES = [
  { type: 'like', label: 'Like', icon: ThumbsUp },
  { type: 'heart', label: 'Heart', icon: Heart },
];

function MobileSearchBar() {
  const [, navigate] = useLocation();
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="md:hidden mb-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Пошук..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-9 pr-3 py-2 rounded-lg border border-border bg-card text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
          data-testid="input-mobile-search"
        />
      </div>
    </form>
  );
}

function GuestBanner() {
  const { loginAnonymous, isLoggingInAnonymous } = useAuth();
  const [, navigate] = useLocation();

  return (
    <Card className="mb-4 overflow-visible">
      <div className="p-5 text-center space-y-3">
        <h2 className="text-xl font-bold text-foreground">Анонімна шкільна мережа</h2>
        <p className="text-sm text-muted-foreground">Без реєстрації &bull; Без імен &bull; Без стеження</p>
        <p className="text-xs text-muted-foreground">Напиши — і піди, якщо хочеш</p>
        <div className="flex flex-col sm:flex-row gap-2 justify-center pt-1">
          <Button
            onClick={() => loginAnonymous()}
            disabled={isLoggingInAnonymous}
            className="gap-2"
            data-testid="button-anonymous-login"
          >
            {isLoggingInAnonymous ? <Loader2 className="w-4 h-4 animate-spin" /> : <EyeOff className="w-4 h-4" />}
            Увійти анонімно
          </Button>
          <Button variant="outline" onClick={() => navigate("/auth")} data-testid="button-goto-login">
            Вже є акаунт? Увійти
          </Button>
        </div>
      </div>
    </Card>
  );
}

function UpgradePrompt({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { upgradeAccount, isUpgrading } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [principalSurname, setPrincipalSurname] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    upgradeAccount({ username, password, principalSurname }, { onSuccess: () => onClose() } as any);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Зберегти акаунт</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground mb-2">Збережи свій нік та історію повідомлень</p>
        <form onSubmit={handleSubmit} className="space-y-3">
          <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Обери нік" className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground" required data-testid="input-upgrade-username" />
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Пароль" className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground" required data-testid="input-upgrade-password" />
          <input value={principalSurname} onChange={e => setPrincipalSurname(e.target.value)} placeholder="Прізвище директора школи" className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground" required data-testid="input-upgrade-surname" />
          <Button type="submit" className="w-full" disabled={isUpgrading} data-testid="button-upgrade-submit">
            {isUpgrading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Зберегти"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      {user && <Sidebar />}
      <main className={user ? "md:ml-60 pb-20 md:pb-6" : "pb-20 md:pb-6"}>
        <div className="max-w-xl mx-auto pt-6 px-4">
          {!user && <GuestBanner />}
          <MobileSearchBar />
          {user && <StoriesBar />}
          <CreatePostBox />
          <div className="flex gap-4">
            <div className="flex-1 min-w-0">
              <Feed />
            </div>
          </div>
        </div>
        <div className="max-w-xl mx-auto px-4 mt-4">
          <Recommendations />
        </div>
      </main>
      {user && <BottomNav />}
    </div>
  );
}

type TextOverlay = { id: string; text: string; x: number; y: number; fontSize: number; color: string; fontWeight: string };

const OVERLAY_COLORS = ["#ffffff", "#000000", "#ff3b30", "#ff9500", "#ffcc00", "#34c759", "#007aff", "#af52de", "#ff2d55"];

function StoryEditor({ file, onClose, onPublish, isPending }: { file: File; onClose: () => void; onPublish: (data: { image: File; caption?: string; textOverlays?: string }) => void; isPending: boolean }) {
  const [caption, setCaption] = useState("");
  const [overlays, setOverlays] = useState<TextOverlay[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newText, setNewText] = useState("");
  const [selectedColor, setSelectedColor] = useState("#ffffff");
  const [selectedWeight, setSelectedWeight] = useState("bold");
  const [selectedSize, setSelectedSize] = useState(24);
  const [mediaUrl, setMediaUrl] = useState("");
  const isVideo = file.type.startsWith("video/");
  const containerRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState<string | null>(null);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setMediaUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const addOverlay = () => {
    if (!newText.trim()) return;
    const overlay: TextOverlay = {
      id: Date.now().toString(),
      text: newText.trim(),
      x: 50,
      y: 50,
      fontSize: selectedSize,
      color: selectedColor,
      fontWeight: selectedWeight,
    };
    setOverlays(prev => [...prev, overlay]);
    setNewText("");
  };

  const removeOverlay = (id: string) => {
    setOverlays(prev => prev.filter(o => o.id !== id));
    if (editingId === id) setEditingId(null);
  };

  const handlePointerDown = (id: string) => {
    setDragging(id);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setOverlays(prev => prev.map(o => o.id === dragging ? { ...o, x: Math.max(5, Math.min(95, x)), y: Math.max(5, Math.min(95, y)) } : o));
  };

  const handlePointerUp = () => setDragging(null);

  const handlePublish = () => {
    onPublish({
      image: file,
      caption: caption || undefined,
      textOverlays: overlays.length > 0 ? JSON.stringify(overlays) : undefined,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col" data-testid="dialog-story-editor">
      <div className="flex items-center justify-between p-3 shrink-0">
        <button onClick={onClose} className="text-white" data-testid="button-editor-close">
          <X className="w-6 h-6" />
        </button>
        <span className="text-white font-semibold text-sm">Редагування</span>
        <button
          onClick={handlePublish}
          disabled={isPending}
          className="bg-primary text-white px-4 py-1.5 rounded-lg text-sm font-medium disabled:opacity-50"
          data-testid="button-editor-publish"
        >
          {isPending ? "..." : "Опублікувати"}
        </button>
      </div>

      <div
        ref={containerRef}
        className="flex-1 relative overflow-hidden mx-auto w-full max-w-md"
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        {isVideo ? (
          <video src={mediaUrl} className="w-full h-full object-contain" autoPlay loop muted playsInline />
        ) : (
          <img src={mediaUrl} alt="" className="w-full h-full object-contain" />
        )}

        {overlays.map(overlay => (
          <div
            key={overlay.id}
            className="absolute cursor-move select-none"
            style={{
              left: `${overlay.x}%`,
              top: `${overlay.y}%`,
              transform: "translate(-50%, -50%)",
              fontSize: `${overlay.fontSize}px`,
              color: overlay.color,
              fontWeight: overlay.fontWeight,
              textShadow: "0 1px 4px rgba(0,0,0,0.7)",
              maxWidth: "80%",
              wordBreak: "break-word",
              textAlign: "center",
            }}
            onPointerDown={() => handlePointerDown(overlay.id)}
            data-testid={`overlay-${overlay.id}`}
          >
            {overlay.text}
            <button
              onClick={(e) => { e.stopPropagation(); removeOverlay(overlay.id); }}
              className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
              style={{ visibility: "visible" }}
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>

      <div className="shrink-0 p-3 space-y-2">
        <input
          value={caption}
          onChange={e => setCaption(e.target.value)}
          placeholder="Підпис до історії..."
          className="w-full bg-white/10 text-white rounded-lg px-3 py-2 text-sm placeholder:text-white/50 focus:outline-none focus:ring-1 focus:ring-primary"
          data-testid="input-story-caption"
        />

        <div className="flex gap-2 items-end">
          <input
            value={newText}
            onChange={e => setNewText(e.target.value)}
            placeholder="Додати текст..."
            className="flex-1 bg-white/10 text-white rounded-lg px-3 py-2 text-sm placeholder:text-white/50 focus:outline-none focus:ring-1 focus:ring-primary"
            onKeyDown={e => { if (e.key === "Enter") addOverlay(); }}
            data-testid="input-overlay-text"
          />
          <button onClick={addOverlay} disabled={!newText.trim()} className="bg-primary text-white rounded-lg px-3 py-2 text-sm font-medium disabled:opacity-50" data-testid="button-add-overlay">
            <Plus className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex gap-1.5">
            {OVERLAY_COLORS.map(c => (
              <button
                key={c}
                onClick={() => setSelectedColor(c)}
                className={`w-6 h-6 rounded-full border-2 ${selectedColor === c ? "border-primary scale-110" : "border-white/30"}`}
                style={{ backgroundColor: c }}
                data-testid={`button-color-${c}`}
              />
            ))}
          </div>
          <select
            value={selectedSize}
            onChange={e => setSelectedSize(Number(e.target.value))}
            className="bg-white/10 text-white text-xs rounded px-2 py-1"
            data-testid="select-font-size"
          >
            {[16, 20, 24, 32, 40, 48].map(s => <option key={s} value={s}>{s}px</option>)}
          </select>
          <button
            onClick={() => setSelectedWeight(w => w === "bold" ? "normal" : "bold")}
            className={`text-white text-sm px-2 py-1 rounded ${selectedWeight === "bold" ? "bg-white/30" : "bg-white/10"}`}
            data-testid="button-toggle-bold"
          >
            B
          </button>
        </div>
      </div>
    </div>
  );
}

function StoriesBar() {
  const { data: storiesList, isLoading } = useStories();
  const { mutate: createStory, isPending } = useCreateStory();
  const fileRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();
  const [viewStory, setViewStory] = useState<any>(null);
  const [editorFile, setEditorFile] = useState<File | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setEditorFile(file);
    e.target.value = "";
  };

  const handlePublish = (data: { image: File; caption?: string; textOverlays?: string }) => {
    createStory(data, { onSuccess: () => setEditorFile(null) });
  };

  if (isLoading) return null;

  return (
    <>
      <div className="mb-4 relative">
        <div ref={scrollRef} className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide" style={{ scrollbarWidth: "none" }}>
          <button
            onClick={() => fileRef.current?.click()}
            className="flex-shrink-0 w-[72px] flex flex-col items-center gap-1"
            data-testid="button-add-story"
          >
            <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-dashed border-primary/40 flex items-center justify-center">
              {isPending ? <Loader2 className="w-5 h-5 animate-spin text-primary" /> : <Plus className="w-5 h-5 text-primary" />}
            </div>
            <span className="text-[10px] text-gray-500 truncate w-full text-center">Додати</span>
          </button>
          <input ref={fileRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleFile} data-testid="input-story-file" />

          {storiesList?.map((story: any) => (
            <button
              key={story.id}
              onClick={() => setViewStory(story)}
              className="flex-shrink-0 w-[72px] flex flex-col items-center gap-1"
              data-testid={`button-story-${story.id}`}
            >
              <div className="w-16 h-16 rounded-full border-2 border-primary p-0.5">
                {story.mediaType === "video" ? (
                  <video src={story.imageUrl} className="w-full h-full rounded-full object-cover" muted />
                ) : (
                  <img src={story.imageUrl} alt="" className="w-full h-full rounded-full object-cover" />
                )}
              </div>
              <span className="text-[10px] text-muted-foreground truncate w-full text-center">{story.authorName}</span>
            </button>
          ))}
        </div>
      </div>

      {editorFile && (
        <StoryEditor file={editorFile} onClose={() => setEditorFile(null)} onPublish={handlePublish} isPending={isPending} />
      )}

      {viewStory && (
        <StoryViewer story={viewStory} onClose={() => setViewStory(null)} />
      )}
    </>
  );
}

function StoryViewer({ story, onClose }: { story: any; onClose: () => void }) {
  let overlays: TextOverlay[] = [];
  try { if (story.textOverlays) overlays = JSON.parse(story.textOverlays); } catch {};

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center" onClick={onClose} data-testid="dialog-story-view">
      <button onClick={onClose} className="absolute top-4 right-4 text-white z-10" data-testid="button-close-story">
        <X className="w-6 h-6" />
      </button>
      <div className="absolute top-4 left-4 text-white z-10">
        <p className="font-semibold text-sm">{story.authorName}</p>
        {story.caption && <p className="text-xs text-white/70 mt-1">{story.caption}</p>}
      </div>
      <div className="relative max-w-full max-h-full w-full h-full flex items-center justify-center">
        {story.mediaType === "video" ? (
          <video src={story.imageUrl} className="max-w-full max-h-full object-contain" autoPlay loop muted playsInline controls onClick={e => e.stopPropagation()} />
        ) : (
          <img src={story.imageUrl} alt="" className="max-w-full max-h-full object-contain" />
        )}
        {overlays.map(overlay => (
          <div
            key={overlay.id}
            className="absolute pointer-events-none"
            style={{
              left: `${overlay.x}%`,
              top: `${overlay.y}%`,
              transform: "translate(-50%, -50%)",
              fontSize: `${overlay.fontSize}px`,
              color: overlay.color,
              fontWeight: overlay.fontWeight,
              textShadow: "0 1px 4px rgba(0,0,0,0.7)",
              maxWidth: "80%",
              wordBreak: "break-word",
              textAlign: "center",
            }}
          >
            {overlay.text}
          </div>
        ))}
      </div>
    </div>
  );
}

function MentionInput({ value, onChange, placeholder, users, className, testId }: { value: string; onChange: (v: string) => void; placeholder: string; users: any[]; className?: string; testId?: string }) {
  const [showMentions, setShowMentions] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const inputRef = useRef<HTMLTextAreaElement | HTMLInputElement>(null);

  const handleChange = (val: string) => {
    onChange(val);
    const atMatch = val.match(/@(\w*)$/);
    if (atMatch) {
      setMentionSearch(atMatch[1]);
      setShowMentions(true);
    } else {
      setShowMentions(false);
    }
  };

  const insertMention = (username: string) => {
    const newVal = value.replace(/@\w*$/, `@${username} `);
    onChange(newVal);
    setShowMentions(false);
  };

  const filteredUsers = (users || []).filter((u: any) => u.username.toLowerCase().includes(mentionSearch.toLowerCase())).slice(0, 5);

  return (
    <div className="relative w-full">
      <textarea
        value={value}
        onChange={(e) => handleChange(e.target.value)}
        placeholder={placeholder}
        className={className}
        data-testid={testId}
      />
      {showMentions && filteredUsers.length > 0 && (
        <div className="absolute left-0 right-0 bottom-full mb-1 bg-card border border-border rounded-lg shadow-lg z-50 max-h-40 overflow-y-auto" data-testid="dropdown-mentions">
          {filteredUsers.map((u: any) => (
            <button
              key={u.id}
              onClick={() => insertMention(u.username)}
              className="w-full flex items-center gap-2 px-3 py-2 hover:bg-muted text-left text-sm"
              data-testid={`mention-user-${u.id}`}
            >
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs flex-shrink-0">
                {u.username.charAt(0).toUpperCase()}
              </div>
              <span>{u.username}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function VoiceRecorder({ onRecord }: { onRecord: (blob: Blob) => void }) {
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const isSupported = typeof navigator !== 'undefined' && navigator.mediaDevices && typeof MediaRecorder !== 'undefined';

  const start = async () => {
    if (!isSupported) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      });
      const recorder = new MediaRecorder(stream, { audioBitsPerSecond: 128000 });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        onRecord(blob);
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);
      setDuration(0);
      timerRef.current = window.setInterval(() => setDuration(d => d + 1), 1000);
    } catch (err) {
      console.warn('Voice recording not available:', err);
    }
  };

  const stop = () => {
    mediaRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  if (!isSupported) return null;

  return (
    <button
      type="button"
      onClick={recording ? stop : start}
      className={`flex items-center gap-1 text-sm transition-colors ${recording ? "text-red-500" : "text-gray-500 hover:text-primary"}`}
      data-testid="button-voice-record"
    >
      {recording ? (
        <>
          <Square className="w-4 h-4 fill-current" />
          <span className="text-xs">{duration}с</span>
        </>
      ) : (
        <Mic className="w-4 h-4" />
      )}
    </button>
  );
}

function AudioPlayer({ src }: { src: string }) {
  return (
    <div className="my-1" data-testid="audio-player">
      <audio controls preload="metadata" className="w-full h-10" style={{ maxWidth: '100%' }}>
        <source src={src} type="audio/webm" />
        <source src={src} type="audio/ogg" />
        <a href={src} download>Завантажити аудіо</a>
      </audio>
    </div>
  );
}

function CreatePostBox() {
  const [content, setContent] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [showPoll, setShowPoll] = useState(false);
  const [pollQuestion, setPollQuestion] = useState("");
  const [pollOptions, setPollOptions] = useState(["", ""]);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const { mutate: createPost, isPending } = useCreatePost();
  const { user, loginAnonymous, isLoggingInAnonymous } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const { data: allUsers } = useUsers();
  const queryClient = useQueryClient();

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const resetForm = () => {
    setContent(""); setImage(null); setPreview(null); setAudioBlob(null);
    setShowPoll(false); setPollQuestion(""); setPollOptions(["", ""]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !image && !audioBlob && !showPoll) return;
    if (!user) {
      loginAnonymous();
      return;
    }
    const validPollOptions = pollOptions.filter(o => o.trim());
    const hasPoll = showPoll && pollQuestion.trim() && validPollOptions.length >= 2;
    createPost({ content: content || (hasPoll ? pollQuestion : ""), isAnonymous, image: image || undefined, audio: audioBlob || undefined }, {
      onSuccess: async (post: any) => {
        if (hasPoll && post?.id) {
          try {
            const pollRes = await fetch(`/api/posts/${post.id}/poll`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ question: pollQuestion, options: validPollOptions }),
              credentials: "include",
            });
            if (!pollRes.ok) console.error("Poll creation failed");
          } catch (err) {
            console.error("Poll creation error:", err);
          }
          queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
        }
        resetForm();
        if (user?.isAnonymous) {
          setShowUpgrade(true);
        }
      }
    });
  };

  return (
    <Card className="p-4 mb-4">
      <form onSubmit={handleSubmit}>
        <div className="flex gap-3">
          <Link href={user ? `/profile/${user.id}` : "/"}>
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0 cursor-pointer overflow-hidden">
              {user?.avatarUrl ? <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" /> : (isAnonymous ? "?" : user?.username?.charAt(0).toUpperCase())}
            </div>
          </Link>
          <MentionInput
            value={content}
            onChange={setContent}
            placeholder="Що у вас нового? Використовуйте @username для згадки..."
            users={allUsers || []}
            className="w-full bg-muted rounded-lg p-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[80px] resize-none border-none"
            testId="input-post-content"
          />
        </div>

        {preview && (
          <div className="relative mt-3 ml-13">
            <img src={preview} alt="" className="rounded-lg max-h-48 object-cover" />
            <button
              type="button"
              onClick={() => { setImage(null); setPreview(null); }}
              className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1"
              data-testid="button-remove-image"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {audioBlob && (
          <div className="mt-3 ml-13 flex items-center gap-2">
            <AudioPlayer src={URL.createObjectURL(audioBlob)} />
            <button type="button" onClick={() => setAudioBlob(null)} className="text-gray-400 hover:text-red-500" data-testid="button-remove-audio">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {showPoll && (
          <div className="mt-3 p-3 bg-muted rounded-lg" data-testid="create-poll-section">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-sm font-medium">
                <BarChart3 className="w-4 h-4 text-primary" />
                Опитування
              </div>
              <button type="button" onClick={() => setShowPoll(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <input
              value={pollQuestion}
              onChange={e => setPollQuestion(e.target.value)}
              placeholder="Питання опитування"
              className="w-full p-2 bg-card rounded-md border border-border text-sm mb-2 focus:outline-none focus:ring-2 focus:ring-primary/20"
              data-testid="input-feed-poll-question"
            />
            {pollOptions.map((opt, i) => (
              <div key={i} className="flex gap-2 mb-1.5">
                <input
                  value={opt}
                  onChange={e => { const o = [...pollOptions]; o[i] = e.target.value; setPollOptions(o); }}
                  placeholder={`Варіант ${i + 1}`}
                  className="flex-1 p-2 bg-card rounded-md border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  data-testid={`input-feed-poll-option-${i}`}
                />
                {pollOptions.length > 2 && (
                  <button type="button" onClick={() => setPollOptions(pollOptions.filter((_, j) => j !== i))} className="text-muted-foreground hover:text-red-500">
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
            {pollOptions.length < 6 && (
              <button type="button" onClick={() => setPollOptions([...pollOptions, ""])} className="text-xs text-primary hover:underline mt-1" data-testid="button-add-feed-poll-option">
                + Додати варіант
              </button>
            )}
          </div>
        )}

        <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100 gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAnonymous(!isAnonymous)}
              className="flex items-center gap-2 text-sm text-gray-500 hover:text-primary transition-colors"
              data-testid="button-toggle-anonymous"
            >
              {isAnonymous ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {isAnonymous ? "Анонімно" : "Від свого імені"}
            </button>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="flex items-center gap-1 text-sm text-gray-500 hover:text-primary transition-colors"
              data-testid="button-attach-image"
            >
              <ImagePlus className="w-4 h-4" />
            </button>
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleImage} data-testid="input-post-image" />
            <VoiceRecorder onRecord={setAudioBlob} />
            <button
              type="button"
              onClick={() => setShowPoll(!showPoll)}
              className={`flex items-center gap-1 text-sm transition-colors ${showPoll ? "text-primary" : "text-gray-500 hover:text-primary"}`}
              data-testid="button-toggle-poll"
            >
              <BarChart3 className="w-4 h-4" />
            </button>
          </div>
          <button
            type="submit"
            disabled={(!content.trim() && !image && !audioBlob && !(showPoll && pollQuestion.trim())) || isPending}
            className="bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary/90 disabled:opacity-50 flex items-center gap-2 transition-all"
            data-testid="button-create-post"
          >
            {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            Опублікувати
          </button>
        </div>
      </form>
    </Card>
  );
}

function ReactionBar({ post }: { post: any }) {
  const { mutate: react } = useReactPost();
  const { mutate: share } = useSharePost();
  const [showReactions, setShowReactions] = useState(false);

  const totalReactions = Object.values(post.reactionCounts || {}).reduce((a: number, b: any) => a + Number(b), 0) as number;

  return (
    <div className="flex items-center gap-3 flex-wrap">
      <div className="relative">
        <button
          onClick={() => setShowReactions(!showReactions)}
          className={`flex items-center gap-1.5 text-sm transition-colors ${post.userReaction ? "text-primary" : "text-muted-foreground hover:text-primary"}`}
          data-testid={`button-reactions-${post.id}`}
        >
          {post.userReaction === 'heart' ? <Heart className="w-4 h-4 fill-current text-red-500" /> : <ThumbsUp className={`w-4 h-4 ${post.userReaction === 'like' ? 'fill-current text-primary' : ''}`} />}
          <span>{totalReactions || 0}</span>
        </button>

        {showReactions && (
          <div className="absolute bottom-full left-0 mb-1 flex gap-1 bg-card border border-border rounded-full shadow-lg px-2 py-1 z-10" data-testid={`reaction-picker-${post.id}`}>
            {REACTION_TYPES.map(r => (
              <button
                key={r.type}
                onClick={() => { react({ postId: post.id, type: r.type }); setShowReactions(false); }}
                className={`p-1 rounded-full hover:bg-secondary transition-colors ${post.userReaction === r.type ? 'bg-primary/10' : ''}`}
                data-testid={`button-react-${r.type}-${post.id}`}
              >
                <r.icon className={`w-5 h-5 ${r.type === 'heart' ? 'text-red-500' : 'text-primary'} ${post.userReaction === r.type ? 'fill-current' : ''}`} />
              </button>
            ))}
          </div>
        )}
      </div>

      <button
        onClick={() => share(post.id)}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
        data-testid={`button-share-${post.id}`}
      >
        <Share2 className="w-4 h-4" />
        <span>{post.shareCount || 0}</span>
      </button>
    </div>
  );
}

function Feed() {
  const { data: posts, isLoading } = usePosts();
  const [openComments, setOpenComments] = useState<number | null>(null);
  const { user } = useAuth();

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-card rounded-xl shadow-sm border border-border p-4 h-32 animate-pulse" />
        ))}
      </div>
    );
  }

  if (!posts?.length) {
    return <Card className="text-center py-12"><p className="text-muted-foreground">Немає дописів</p></Card>;
  }

  return (
    <div className="space-y-4">
      {posts.map((post: any) => (
        <PostCard key={post.id} post={post} user={user} openComments={openComments} setOpenComments={setOpenComments} />
      ))}
    </div>
  );
}

function PostCard({ post, user, openComments, setOpenComments }: { post: any; user: any; openComments: number | null; setOpenComments: (id: number | null) => void }) {
  const [showMenu, setShowMenu] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);

  return (
    <Card className={`p-4 ${post.isPinned ? 'border-primary/30 bg-primary/[0.02]' : ''}`} data-testid={`card-post-${post.id}`}>
      {post.isPinned && (
        <div className="flex items-center gap-1.5 text-xs text-primary mb-2" data-testid={`pinned-badge-${post.id}`}>
          <Pin className="w-3 h-3" />
          <span className="font-medium">Закріплений допис</span>
        </div>
      )}

      {post.forwardedFrom && (
        <div className="text-xs text-muted-foreground mb-2 flex items-center gap-1 bg-muted rounded-md px-2 py-1" data-testid={`forwarded-${post.id}`}>
          <Share2 className="w-3 h-3" />
          Переслано від {post.forwardedFrom.authorName}
        </div>
      )}

      <div className="flex items-center gap-3 mb-3">
        <Link href={post.isAnonymous ? "/" : `/profile/${post.userId}`}>
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-primary font-bold text-sm cursor-pointer overflow-hidden">
            {post.authorAvatar ? <img src={post.authorAvatar} alt="" className="w-full h-full object-cover" /> : post.authorName.charAt(0).toUpperCase()}
          </div>
        </Link>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <h3 className="font-semibold text-sm">{post.authorName}</h3>
            <VerifiedBadge isAdmin={post.authorIsAdmin} isOfficial={post.authorIsOfficial} />
          </div>
          <p className="text-xs text-muted-foreground">
            {post.createdAt && formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: uk })}
          </p>
        </div>
        <PostMenu post={post} user={user} onReport={() => setShowReportDialog(true)} />
      </div>

      {post.content && <p className="text-sm leading-relaxed whitespace-pre-wrap mb-3">{renderMentions(post.content)}</p>}

      {post.imageUrl && (
        <div className="mb-3 rounded-lg overflow-hidden">
          <img src={post.imageUrl} alt="" className="w-full max-h-96 object-cover" data-testid={`img-post-${post.id}`} />
        </div>
      )}

      {post.audioUrl && (
        <div className="mb-3">
          <AudioPlayer src={post.audioUrl} />
        </div>
      )}

      {post.poll && <FeedPollDisplay post={post} />}

      <div className="pt-3 border-t border-gray-100 flex items-center gap-4">
        <ReactionBar post={post} />
        <button
          onClick={() => setOpenComments(openComments === post.id ? null : post.id)}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
          data-testid={`button-comments-${post.id}`}
        >
          <MessageCircle className="w-4 h-4" />
          <span>{post.commentCount || 0}</span>
        </button>
      </div>

      {openComments === post.id && <CommentsSection postId={post.id} />}

      {showReportDialog && (
        <ReportDialog targetType="post" targetId={post.id} open={showReportDialog} onOpenChange={setShowReportDialog} />
      )}
    </Card>
  );
}

function PostMenu({ post, user, onReport }: { post: any; user: any; onReport: () => void }) {
  const [open, setOpen] = useState(false);
  const { mutate: deletePost, isPending: deleting } = useDeletePost();
  const { mutate: pinPost } = usePinPost();

  const canDelete = user?.id === post.userId || user?.isAdmin;
  const canPin = user?.isAdmin;

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="p-1 text-muted-foreground hover:text-foreground transition-colors rounded-full"
        data-testid={`button-post-menu-${post.id}`}
      >
        <MoreVertical className="w-4 h-4" />
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-8 z-50 bg-card border border-border rounded-lg shadow-lg min-w-[180px] py-1" data-testid={`post-menu-${post.id}`}>
            {canPin && (
              <button
                onClick={() => { pinPost({ postId: post.id, action: post.isPinned ? 'unpin' : 'pin' }); setOpen(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted text-left"
                data-testid={`button-pin-post-${post.id}`}
              >
                <Pin className="w-4 h-4" />
                {post.isPinned ? "Відкріпити" : "Закріпити"}
              </button>
            )}
            {canDelete && (
              <button
                onClick={() => { if (confirm("Видалити цей допис?")) { deletePost(post.id); } setOpen(false); }}
                disabled={deleting}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted text-left text-red-600"
                data-testid={`button-delete-post-${post.id}`}
              >
                <Trash2 className="w-4 h-4" />
                Видалити
              </button>
            )}
            <button
              onClick={() => { onReport(); setOpen(false); }}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted text-left"
              data-testid={`button-report-post-${post.id}`}
            >
              <Flag className="w-4 h-4" />
              Поскаржитися
            </button>
          </div>
        </>
      )}
    </div>
  );
}

function FeedPollDisplay({ post }: { post: any }) {
  const { mutate: vote } = useVoteFeedPoll();
  const poll = post.poll;
  if (!poll) return null;

  return (
    <div className="mb-3 p-3 bg-muted rounded-lg" data-testid={`feed-poll-${post.id}`}>
      <div className="flex items-center gap-2 mb-2">
        <BarChart3 className="w-4 h-4 text-primary" />
        <h4 className="text-sm font-semibold">{poll.question}</h4>
      </div>
      <div className="space-y-1.5">
        {poll.options.map((opt: any) => {
          const pct = poll.totalVotes > 0 ? Math.round((opt.voteCount / poll.totalVotes) * 100) : 0;
          const isVoted = post.userPollVote === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => vote({ postId: post.id, optionId: opt.id })}
              className={`w-full text-left p-2 rounded-md text-sm relative overflow-hidden transition-all border ${isVoted ? "border-primary bg-primary/5" : "border-transparent hover:border-border"}`}
              data-testid={`button-feed-poll-option-${opt.id}`}
            >
              <div className="absolute inset-0 bg-primary/10 transition-all" style={{ width: `${pct}%` }} />
              <div className="relative flex items-center justify-between gap-2">
                <span className={isVoted ? "font-semibold" : ""}>{opt.text}</span>
                <span className="text-xs text-muted-foreground flex-shrink-0">{pct}%</span>
              </div>
            </button>
          );
        })}
      </div>
      <p className="text-xs text-muted-foreground mt-1.5">{poll.totalVotes} голосів</p>
    </div>
  );
}

function ReportDialog({ targetType, targetId, open, onOpenChange }: { targetType: string; targetId: number; open: boolean; onOpenChange: (v: boolean) => void }) {
  const [reason, setReason] = useState("");
  const { mutate: report, isPending } = useCreateReport();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;
    report({ targetType, targetId, reason }, { onSuccess: () => { onOpenChange(false); setReason(""); } });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Поскаржитися
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <textarea
            placeholder="Опишіть причину скарги..."
            value={reason}
            onChange={e => setReason(e.target.value)}
            className="w-full p-3 bg-muted rounded-lg text-sm min-h-[100px] resize-none border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
            data-testid="input-report-reason"
            required
          />
          <Button type="submit" className="w-full" disabled={isPending || !reason.trim()} data-testid="button-submit-report">
            {isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Надіслати скаргу
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function renderMentions(text: string) {
  if (!text) return text;
  const parts = text.split(/(@\w+)/g);
  return parts.map((part, i) => {
    if (part.startsWith('@')) {
      return <Link key={i} href={`/search`}><span className="text-primary font-medium cursor-pointer hover:underline">{part}</span></Link>;
    }
    return part;
  });
}

function CommentsSection({ postId }: { postId: number }) {
  const { data: commentsList, isLoading } = useComments(postId);
  const { mutate: createComment, isPending } = useCreateComment();
  const { mutate: likeComment } = useLikeComment();
  const [likingIds, setLikingIds] = useState<Set<number>>(new Set());
  const [text, setText] = useState("");
  const [isAnon, setIsAnon] = useState(true);
  const [replyTo, setReplyTo] = useState<{ id: number; name: string } | null>(null);
  const [commentImage, setCommentImage] = useState<File | null>(null);
  const commentImageRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() && !commentImage) return;
    createComment(
      { postId, content: text, isAnonymous: isAnon, parentId: replyTo?.id, image: commentImage || undefined },
      { onSuccess: () => { setText(""); setReplyTo(null); setCommentImage(null); } }
    );
  };

  const handleLike = (data: { commentId: number; postId: number }) => {
    if (likingIds.has(data.commentId)) return;
    setLikingIds(prev => new Set(prev).add(data.commentId));
    likeComment(data, {
      onSettled: () => setLikingIds(prev => { const n = new Set(prev); n.delete(data.commentId); return n; }),
    });
  };

  const topLevel = commentsList?.filter((c: any) => !c.parentId) || [];
  const replies = commentsList?.filter((c: any) => c.parentId) || [];
  const getReplies = (parentId: number) => replies.filter((r: any) => r.parentId === parentId);

  return (
    <div className="mt-3 pt-3 border-t border-gray-100" data-testid={`comments-section-${postId}`}>
      {isLoading && <Loader2 className="w-4 h-4 animate-spin text-primary mx-auto my-2" />}

      {topLevel.map((c: any) => (
        <div key={c.id}>
          <CommentItem c={c} postId={postId} onLike={handleLike} likingIds={likingIds} onReply={() => setReplyTo({ id: c.id, name: c.authorName })} />
          {getReplies(c.id).length > 0 && (
            <div className="ml-4 pl-4 border-l-2 border-primary/20">
              {getReplies(c.id).map((r: any) => (
                <CommentItem key={r.id} c={r} postId={postId} onLike={handleLike} likingIds={likingIds} onReply={() => setReplyTo({ id: c.id, name: r.authorName })} isReply replyToName={c.authorName} />
              ))}
            </div>
          )}
        </div>
      ))}

      {replyTo && (
        <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground bg-muted rounded-md px-2 py-1">
          <Reply className="w-3 h-3" />
          <span>Відповідь для {replyTo.name}</span>
          <button onClick={() => setReplyTo(null)} className="ml-auto text-gray-400 hover:text-muted-foreground"><X className="w-3 h-3" /></button>
        </div>
      )}

      {commentImage && (
        <div className="mt-2 relative inline-block">
          <img src={URL.createObjectURL(commentImage)} alt="preview" className="h-16 rounded-md object-cover" />
          <button onClick={() => setCommentImage(null)} className="absolute -top-1 -right-1 bg-gray-800 text-white rounded-full w-4 h-4 flex items-center justify-center">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex gap-2 mt-2 items-center">
        <button type="button" onClick={() => setIsAnon(!isAnon)} className="text-gray-400 hover:text-primary flex-shrink-0" data-testid={`button-comment-anon-${postId}`}>
          {isAnon ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
        <input
          ref={commentImageRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => { if (e.target.files?.[0]) setCommentImage(e.target.files[0]); }}
          data-testid={`input-comment-image-${postId}`}
        />
        <button type="button" onClick={() => commentImageRef.current?.click()} className="text-gray-400 hover:text-primary flex-shrink-0" data-testid={`button-comment-attach-${postId}`}>
          <Image className="w-4 h-4" />
        </button>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={replyTo ? `Відповідь для ${replyTo.name}...` : "Написати коментар..."}
          className="flex-1 bg-muted rounded-full px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
          data-testid={`input-comment-${postId}`}
        />
        <button type="submit" disabled={(!text.trim() && !commentImage) || isPending} className="text-primary disabled:opacity-50 flex-shrink-0" data-testid={`button-submit-comment-${postId}`}>
          {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
        </button>
      </form>
    </div>
  );
}

function CommentItem({ c, postId, onLike, likingIds, onReply, isReply, replyToName }: { c: any; postId: number; onLike: any; likingIds: Set<number>; onReply: () => void; isReply?: boolean; replyToName?: string }) {
  return (
    <div className={`flex gap-2 mb-2 ${isReply ? "mt-1" : ""}`} data-testid={`comment-${c.id}`}>
      <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-500 flex-shrink-0 mt-0.5">
        {c.authorName.charAt(0).toUpperCase()}
      </div>
      <div className="flex-1 min-w-0">
        <div className="bg-muted rounded-lg px-3 py-1.5">
          <div className="flex items-center gap-1 flex-wrap">
            <p className="text-xs font-semibold text-foreground/90">{c.authorName}</p>
            {isReply && replyToName && (
              <span className="text-xs text-muted-foreground flex items-center gap-0.5">
                <Reply className="w-3 h-3" /> {replyToName}
              </span>
            )}
          </div>
          {c.content && <p className="text-sm text-muted-foreground">{renderMentions(c.content)}</p>}
          {c.imageUrl && (
            <img src={c.imageUrl} alt="comment" className="mt-1.5 rounded-md max-h-48 object-cover" data-testid={`comment-image-${c.id}`} />
          )}
        </div>
        <div className="flex items-center gap-3 mt-0.5 px-1">
          <button
            onClick={() => onLike({ commentId: c.id, postId })}
            disabled={likingIds.has(c.id)}
            className={`flex items-center gap-1 text-xs transition-colors disabled:opacity-50 ${c.userLiked ? "text-red-500" : "text-gray-400 hover:text-red-500"}`}
            data-testid={`button-like-comment-${c.id}`}
          >
            <Heart className={`w-3 h-3 ${c.userLiked ? "fill-current" : ""}`} />
            {(c.likes || 0) > 0 && <span>{c.likes}</span>}
          </button>
          <button onClick={onReply} className="text-xs text-gray-400 hover:text-primary flex items-center gap-1" data-testid={`button-reply-comment-${c.id}`}>
            <Reply className="w-3 h-3" /> Відповісти
          </button>
          {c.createdAt && (
            <span className="text-xs text-gray-300">
              {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true, locale: uk })}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

function Recommendations() {
  const { data, isLoading } = useRecommendations();

  if (isLoading || !data) return null;
  const { trending, popularNewspapers } = data;

  if (!trending?.length && !popularNewspapers?.length) return null;

  return (
    <Card className="p-4" data-testid="card-recommendations">
      <h2 className="font-bold text-sm text-foreground mb-3 flex items-center gap-2">
        <TrendingUp className="w-4 h-4 text-primary" />
        Рекомендації
      </h2>

      {trending?.length > 0 && (
        <div className="mb-4">
          <h3 className="text-xs font-semibold text-gray-500 uppercase mb-2">Популярні дописи</h3>
          <div className="space-y-2">
            {trending.slice(0, 3).map((post: any) => (
              <div key={post.id} className="flex items-center gap-2 p-2 rounded-lg bg-muted" data-testid={`trending-post-${post.id}`}>
                <ThumbsUp className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                <p className="text-sm text-foreground/90 truncate flex-1">{post.content}</p>
                <span className="text-xs text-gray-400 flex-shrink-0">{post.upvotes} likes</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {popularNewspapers?.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase mb-2">Популярні газети</h3>
          <div className="space-y-2">
            {popularNewspapers.map((paper: any) => (
              <Link key={paper.id} href="/newspapers">
                <div className="flex items-center gap-2 p-2 rounded-lg bg-muted cursor-pointer hover:bg-secondary transition-colors" data-testid={`popular-newspaper-${paper.id}`}>
                  <Newspaper className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                  <span className="text-sm text-foreground/90 truncate flex-1">{paper.name}</span>
                  <span className="text-xs text-gray-400 flex-shrink-0">{paper.subscriberCount} читачів</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}
