import { useState, useRef, useEffect } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useUsers, useConversations, useMessages, useSendMessage, useSearchMessages } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { Send, Search, ArrowLeft, MessageSquare, Mic, Square, Reply, X } from "lucide-react";
import { cn } from "@/lib/utils";

function AudioPlayer({ src }: { src: string }) {
  return (
    <div data-testid="audio-player-chat">
      <audio controls preload="metadata" className="w-full h-8" style={{ maxWidth: '200px' }}>
        <source src={src} type="audio/webm" />
        <source src={src} type="audio/ogg" />
        <a href={src} download>Завантажити</a>
      </audio>
    </div>
  );
}

export default function Chat() {
  const [selectedUser, setSelectedUser] = useState<{ id: number; username: string } | null>(null);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 h-screen flex flex-col">
        {selectedUser ? (
          <Conversation user={selectedUser} onBack={() => setSelectedUser(null)} />
        ) : (
          <ContactList onSelect={setSelectedUser} />
        )}
      </main>
      {!selectedUser && <BottomNav />}
    </div>
  );
}

function ContactList({ onSelect }: { onSelect: (u: { id: number; username: string }) => void }) {
  const { data: conversations } = useConversations();
  const { data: allUsers } = useUsers();
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);

  const filtered = showAll
    ? (allUsers || []).filter((u: any) => u.username.toLowerCase().includes(search.toLowerCase()))
    : (conversations || []);

  return (
    <div className="flex flex-col h-full bg-card">
      <div className="p-4 border-b border-border">
        <h1 className="text-xl font-bold mb-3" data-testid="text-chat-title">Чат</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => { setSearch(e.target.value); setShowAll(true); }}
            placeholder="Пошук людей..."
            className="w-full pl-9 pr-4 py-2 rounded-full bg-secondary text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
            data-testid="input-chat-search"
          />
        </div>
        <div className="flex gap-2 mt-3">
          <button
            onClick={() => setShowAll(false)}
            className={cn("text-xs font-medium px-3 py-1.5 rounded-full transition-colors", !showAll ? "bg-primary text-white" : "bg-secondary text-muted-foreground")}
            data-testid="button-tab-conversations"
          >
            Бесіди
          </button>
          <button
            onClick={() => setShowAll(true)}
            className={cn("text-xs font-medium px-3 py-1.5 rounded-full transition-colors", showAll ? "bg-primary text-white" : "bg-secondary text-muted-foreground")}
            data-testid="button-tab-all-users"
          >
            Всі учасники
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <MessageSquare className="w-12 h-12 mb-3 text-gray-300" />
            <p className="text-sm">{showAll ? "Нікого не знайдено" : "Немає бесід"}</p>
            {!showAll && <button onClick={() => setShowAll(true)} className="text-primary text-sm mt-2 hover:underline" data-testid="button-start-new-chat">Почати нову бесіду</button>}
          </div>
        ) : (
          filtered.map((item: any) => {
            const userId = showAll ? item.id : item.userId;
            const username = showAll ? item.username : item.username;
            return (
              <button
                key={userId}
                onClick={() => onSelect({ id: userId, username })}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted transition-colors text-left border-b border-border/30"
                data-testid={`button-contact-${userId}`}
              >
                <div className="relative flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                    {username.charAt(0).toUpperCase()}
                  </div>
                  {item.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-card rounded-full" data-testid={`status-online-${userId}`} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{username}</p>
                  {!showAll && item.lastMessage && (
                    <p className="text-xs text-muted-foreground truncate">{item.lastMessage}</p>
                  )}
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}

function Conversation({ user: otherUser, onBack }: { user: { id: number; username: string }; onBack: () => void }) {
  const { user: me } = useAuth();
  const { data: messages } = useMessages(otherUser.id);
  const { mutate: sendMessage } = useSendMessage();
  const [input, setInput] = useState("");
  const [recording, setRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [replyTo, setReplyTo] = useState<any>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { data: searchResults } = useSearchMessages(otherUser.id, searchQuery);
  const scrollRef = useRef<HTMLDivElement>(null);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    sendMessage({ content: input, receiverId: otherUser.id, replyToId: replyTo?.id });
    setInput("");
    setReplyTo(null);
  };

  const isVoiceSupported = typeof navigator !== 'undefined' && navigator.mediaDevices && typeof MediaRecorder !== 'undefined';

  const startRecording = async () => {
    if (!isVoiceSupported) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      });
      const recorder = new MediaRecorder(stream, { audioBitsPerSecond: 128000 });
      chunksRef.current = [];
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        sendMessage({ content: "", receiverId: otherUser.id, audio: blob });
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      mediaRef.current = recorder;
      setRecording(true);
      setDuration(0);
      timerRef.current = window.setInterval(() => setDuration(d => d + 1), 1000);
    } catch (err) {
      console.warn('Voice recording not available:', err);
    }
  };

  const stopRecording = () => {
    mediaRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const getReplyMessage = (replyToId: number) => {
    return messages?.find((m: any) => m.id === replyToId);
  };

  return (
    <div className="flex flex-col h-full bg-card">
      <div className="p-4 border-b border-border flex items-center gap-3">
        <button onClick={onBack} className="md:hidden text-gray-500 hover:text-foreground/90" data-testid="button-back-chat">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
          {otherUser.username.charAt(0).toUpperCase()}
        </div>
        <span className="font-semibold flex-1" data-testid="text-chat-partner">{otherUser.username}</span>
        <button
          onClick={() => { setSearchOpen(!searchOpen); setSearchQuery(""); }}
          className={cn("p-1.5 rounded-full transition-colors", searchOpen ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground")}
          data-testid="button-chat-search"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      {searchOpen && (
        <div className="p-3 border-b border-border bg-muted/50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Пошук у повідомленнях..."
              className="w-full pl-9 pr-8 py-2 rounded-full bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
              autoFocus
              data-testid="input-message-search"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          {searchQuery && searchResults && (
            <div className="mt-2 max-h-40 overflow-y-auto space-y-1">
              {searchResults.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-2">Нічого не знайдено</p>
              ) : (
                searchResults.map((msg: any) => (
                  <div key={msg.id} className="text-xs p-2 rounded-md bg-card border border-border">
                    <span className="font-medium">{msg.senderName}: </span>
                    <span className="text-muted-foreground">{msg.content}</span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-background" ref={scrollRef}>
        {(!messages || messages.length === 0) && (
          <div className="text-center py-12 text-muted-foreground text-sm">
            Почніть розмову з {otherUser.username}
          </div>
        )}
        {messages?.map((msg: any) => {
          const isMe = msg.senderId === me?.id;
          const repliedMsg = msg.replyToId ? getReplyMessage(msg.replyToId) : null;
          return (
            <div key={msg.id} className={cn("flex group", isMe ? "justify-end" : "justify-start")}>
              <div className="max-w-[75%]">
                {repliedMsg && (
                  <div className={cn(
                    "text-xs px-3 py-1 rounded-t-lg border-l-2 border-primary/40 mb-0.5",
                    isMe ? "bg-primary/20 text-primary-foreground/70 ml-auto" : "bg-muted text-muted-foreground"
                  )}>
                    <span className="font-medium">{repliedMsg.senderId === me?.id ? "Ви" : otherUser.username}</span>
                    <p className="truncate">{repliedMsg.content || "Голосове повідомлення"}</p>
                  </div>
                )}
                <div className={cn(
                  "rounded-2xl px-4 py-2 shadow-sm relative",
                  isMe ? "bg-primary text-white rounded-br-sm" : "bg-card text-foreground rounded-bl-sm border border-border"
                )}>
                  {msg.audioUrl ? (
                    <AudioPlayer src={msg.audioUrl} />
                  ) : (
                    <p className="text-sm">{msg.content}</p>
                  )}
                </div>
                <button
                  onClick={() => setReplyTo(msg)}
                  className="invisible group-hover:visible text-xs text-muted-foreground hover:text-primary mt-0.5 flex items-center gap-1"
                  data-testid={`button-reply-message-${msg.id}`}
                >
                  <Reply className="w-3 h-3" /> Відповісти
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {replyTo && (
        <div className="px-3 pt-2 bg-card border-t border-border flex items-center gap-2">
          <Reply className="w-4 h-4 text-primary flex-shrink-0" />
          <div className="flex-1 min-w-0 text-xs">
            <span className="font-medium text-primary">{replyTo.senderId === me?.id ? "Ви" : otherUser.username}</span>
            <p className="text-muted-foreground truncate">{replyTo.content || "Голосове повідомлення"}</p>
          </div>
          <button onClick={() => setReplyTo(null)} className="text-muted-foreground hover:text-foreground flex-shrink-0" data-testid="button-cancel-reply">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <form onSubmit={handleSend} className="p-3 bg-card border-t border-border flex gap-2">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={replyTo ? "Відповідь..." : "Напишіть повідомлення..."}
          className="flex-1 bg-secondary rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
          data-testid="input-chat-message"
        />
        {isVoiceSupported && (
          <button
            type="button"
            onClick={recording ? stopRecording : startRecording}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition",
              recording ? "bg-red-500 text-white" : "bg-secondary text-gray-500 hover:bg-gray-200"
            )}
            data-testid="button-voice-chat"
          >
            {recording ? <Square className="w-4 h-4 fill-current" /> : <Mic className="w-4 h-4" />}
          </button>
        )}
        {recording && <span className="self-center text-xs text-red-500">{duration}с</span>}
        <button
          type="submit"
          disabled={!input.trim()}
          className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center hover:bg-primary/90 transition disabled:opacity-50"
          data-testid="button-send-message"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
