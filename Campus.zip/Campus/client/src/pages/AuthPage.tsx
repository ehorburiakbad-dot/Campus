import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const { login, register, isLoggingIn, isRegistering, user } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user) setLocation("/");
  }, [user, setLocation]);

  if (user) return null;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-4xl flex flex-col md:flex-row items-center gap-8 md:gap-16">
        <div className="text-center md:text-left flex-1 space-y-4">
          <h1 className="text-5xl font-bold text-primary tracking-tight" data-testid="text-logo">Campus</h1>
          <p className="text-xl text-[#1c1e21] leading-7">
            Спілкуйтеся анонімно у своїй шкільній мережі.
          </p>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg border border-border w-full max-w-md">
          {isLogin ? (
            <LoginForm onSubmit={login} isLoading={isLoggingIn} onToggle={() => setIsLogin(false)} />
          ) : (
            <RegisterForm onSubmit={register} isLoading={isRegistering} onToggle={() => setIsLogin(true)} />
          )}
        </div>
      </div>
    </div>
  );
}

function LoginForm({ onSubmit, isLoading, onToggle }: any) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ username, password });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Ім'я користувача" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none" data-testid="input-login-username" />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Пароль" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary focus:outline-none" data-testid="input-login-password" />
      <button type="submit" disabled={isLoading} className="w-full bg-primary text-white font-bold text-lg py-3 rounded-lg hover:bg-primary/90 transition disabled:opacity-70" data-testid="button-login">
        {isLoading ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : "Вхід"}
      </button>
      <div className="border-b border-gray-200 my-2" />
      <div className="text-center">
        <button type="button" onClick={onToggle} className="bg-[#42b72a] text-white font-bold px-6 py-3 rounded-lg hover:bg-[#36a420] transition text-sm" data-testid="button-switch-register">
          Створити новий акаунт
        </button>
      </div>
    </form>
  );
}

function RegisterForm({ onSubmit, isLoading, onToggle }: any) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [principalSurname, setPrincipalSurname] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) { setError("Паролі не співпадають"); return; }
    setError("");
    onSubmit({ username, password, principalSurname });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <h2 className="text-2xl font-bold text-gray-800">Реєстрація</h2>
      <p className="text-gray-500 text-sm mb-2">Це швидко і легко.</p>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Ім'я користувача" className="w-full px-3 py-2.5 rounded border border-gray-300 text-sm" data-testid="input-register-username" required />
      <input value={principalSurname} onChange={e => setPrincipalSurname(e.target.value)} placeholder="Прізвище директора школи" className="w-full px-3 py-2.5 rounded border border-gray-300 text-sm" data-testid="input-register-surname" required />
      <div className="flex gap-2">
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Пароль" className="flex-1 px-3 py-2.5 rounded border border-gray-300 text-sm" data-testid="input-register-password" required />
        <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Повторіть" className="flex-1 px-3 py-2.5 rounded border border-gray-300 text-sm" data-testid="input-register-confirm" required />
      </div>
      {error && <p className="text-xs text-red-500">{error}</p>}
      <button type="submit" disabled={isLoading} className="w-full bg-[#00a400] text-white font-bold py-2.5 rounded hover:bg-[#008a00] transition text-sm disabled:opacity-70" data-testid="button-register">
        {isLoading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : "Зареєструватися"}
      </button>
      <div className="text-center mt-2">
        <button type="button" onClick={onToggle} className="text-primary hover:underline text-sm" data-testid="button-switch-login">Вже є акаунт?</button>
      </div>
    </form>
  );
}
