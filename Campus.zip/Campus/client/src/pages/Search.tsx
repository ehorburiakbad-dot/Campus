import { useState, useRef, useCallback } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useSearch } from "@/hooks/use-data";
import { Search as SearchIcon, User, FileText, Newspaper, Users, Loader2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";

export default function SearchPage() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const { data, isLoading } = useSearch(debouncedQuery);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleChange = useCallback((val: string) => {
    setQuery(val);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setDebouncedQuery(val), 300);
  }, []);

  const hasResults = data && (data.posts?.length || data.users?.length || data.groups?.length || data.newspapers?.length);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        <div className="max-w-xl mx-auto pt-6 px-4">
          <Card className="p-4 mb-4">
            <div className="relative">
              <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                value={query}
                onChange={e => handleChange(e.target.value)}
                placeholder="Пошук дописів, людей, груп, газет..."
                className="w-full pl-10 pr-4 py-3 rounded-lg bg-gray-50 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
                data-testid="input-search"
              />
            </div>
          </Card>

          {isLoading && debouncedQuery && (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          )}

          {!debouncedQuery && (
            <div className="text-center py-16 text-muted-foreground">
              <SearchIcon className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">Введіть запит для пошуку</p>
            </div>
          )}

          {debouncedQuery && !isLoading && !hasResults && (
            <div className="text-center py-16 text-muted-foreground">
              <p className="text-sm">Нічого не знайдено</p>
            </div>
          )}

          {data?.users?.length > 0 && (
            <Card className="p-4 mb-4" data-testid="search-results-users">
              <h3 className="text-sm font-semibold text-foreground/90 mb-2 flex items-center gap-2">
                <User className="w-4 h-4 text-primary" /> Користувачі
              </h3>
              <div className="space-y-2">
                {data.users.map((u: any) => (
                  <Link key={u.id} href={`/profile/${u.id}`}>
                    <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors" data-testid={`search-user-${u.id}`}>
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm overflow-hidden flex-shrink-0">
                        {u.avatarUrl ? <img src={u.avatarUrl} alt="" className="w-full h-full object-cover" /> : u.username.charAt(0).toUpperCase()}
                      </div>
                      <span className="text-sm font-medium">{u.username}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
          )}

          {data?.posts?.length > 0 && (
            <Card className="p-4 mb-4" data-testid="search-results-posts">
              <h3 className="text-sm font-semibold text-foreground/90 mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" /> Дописи
              </h3>
              <div className="space-y-2">
                {data.posts.map((p: any) => (
                  <div key={p.id} className="p-2 rounded-lg bg-gray-50" data-testid={`search-post-${p.id}`}>
                    <p className="text-xs text-muted-foreground">{p.authorName}</p>
                    <p className="text-sm truncate">{p.content}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {data?.groups?.length > 0 && (
            <Card className="p-4 mb-4" data-testid="search-results-groups">
              <h3 className="text-sm font-semibold text-foreground/90 mb-2 flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" /> Групи
              </h3>
              <div className="space-y-2">
                {data.groups.map((g: any) => (
                  <div key={g.id} className="p-2 rounded-lg bg-gray-50" data-testid={`search-group-${g.id}`}>
                    <p className="text-sm font-medium">{g.name}</p>
                    {g.description && <p className="text-xs text-muted-foreground truncate">{g.description}</p>}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {data?.newspapers?.length > 0 && (
            <Card className="p-4 mb-4" data-testid="search-results-newspapers">
              <h3 className="text-sm font-semibold text-foreground/90 mb-2 flex items-center gap-2">
                <Newspaper className="w-4 h-4 text-primary" /> Газети
              </h3>
              <div className="space-y-2">
                {data.newspapers.map((n: any) => (
                  <Link key={n.id} href="/newspapers">
                    <div className="p-2 rounded-lg bg-gray-50 cursor-pointer hover:bg-gray-100 transition-colors" data-testid={`search-newspaper-${n.id}`}>
                      <p className="text-sm font-medium">{n.name}</p>
                      {n.description && <p className="text-xs text-muted-foreground truncate">{n.description}</p>}
                    </div>
                  </Link>
                ))}
              </div>
            </Card>
          )}
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
