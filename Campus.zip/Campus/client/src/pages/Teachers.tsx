import { useState } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Star, Plus, Loader2, User, BookOpen, Trophy, TrendingDown, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import type { Teacher } from "@shared/schema";

export default function Teachers() {
  const [showAdd, setShowAdd] = useState(false);
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        <div className="max-w-xl mx-auto pt-6 px-4">
          <div className="flex items-center justify-between mb-4 gap-2">
            <h1 className="text-xl font-bold text-foreground" data-testid="text-teachers-title">Вчителі</h1>
            <Button onClick={() => setShowAdd(!showAdd)} size="sm" data-testid="button-add-teacher">
              <Plus className="w-4 h-4 mr-1" />
              Додати
            </Button>
          </div>

          <TeacherOfTheWeek />

          {showAdd && <AddTeacherForm onClose={() => setShowAdd(false)} />}
          {selectedTeacher && <RateDialog teacher={selectedTeacher} onClose={() => setSelectedTeacher(null)} />}
          <TeacherList onRate={setSelectedTeacher} />
        </div>
      </main>
      <BottomNav />
    </div>
  );
}

function TeacherOfTheWeek() {
  const { data, isLoading } = useQuery<{ best: any; worst: any }>({
    queryKey: ['/api/teachers/weekly'],
    queryFn: async () => {
      const res = await fetch('/api/teachers/weekly', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  if (isLoading || (!data?.best && !data?.worst)) return null;

  return (
    <div className="mb-4 space-y-3" data-testid="section-teacher-of-week">
      {data?.best && (
        <Card className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 dark:from-green-950/30 dark:to-emerald-950/30 dark:border-green-900/30" data-testid="card-best-teacher">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/40 flex items-center justify-center flex-shrink-0">
              {data.best.photoUrl ? (
                <img src={data.best.photoUrl} alt={data.best.name} className="w-12 h-12 rounded-full object-cover" />
              ) : (
                <Crown className="w-6 h-6 text-green-600 dark:text-green-400" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <Trophy className="w-4 h-4 text-green-600 dark:text-green-400" />
                <span className="text-xs font-bold text-green-700 dark:text-green-300 uppercase tracking-wider">Найкращий вчитель тижня</span>
              </div>
              <p className="font-bold text-foreground mt-0.5 truncate" data-testid="text-best-teacher-name">{data.best.name}</p>
              {data.best.subject && <p className="text-xs text-muted-foreground">{data.best.subject}</p>}
            </div>
            <div className="text-right flex-shrink-0">
              <div className="flex items-center gap-1">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="text-lg font-bold text-foreground" data-testid="text-best-teacher-rating">{data.best.weeklyAvg}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">{data.best.ratingCount} оцінок</p>
            </div>
          </div>
        </Card>
      )}

      {data?.worst && (
        <Card className="p-4 bg-gradient-to-r from-red-50 to-orange-50 border-red-200 dark:from-red-950/30 dark:to-orange-950/30 dark:border-red-900/30" data-testid="card-worst-teacher">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/40 flex items-center justify-center flex-shrink-0">
              {data.worst.photoUrl ? (
                <img src={data.worst.photoUrl} alt={data.worst.name} className="w-12 h-12 rounded-full object-cover" />
              ) : (
                <TrendingDown className="w-6 h-6 text-red-600 dark:text-red-400" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <TrendingDown className="w-4 h-4 text-red-600 dark:text-red-400" />
                <span className="text-xs font-bold text-red-700 dark:text-red-300 uppercase tracking-wider">Найгірший вчитель тижня</span>
              </div>
              <p className="font-bold text-foreground mt-0.5 truncate" data-testid="text-worst-teacher-name">{data.worst.name}</p>
              {data.worst.subject && <p className="text-xs text-muted-foreground">{data.worst.subject}</p>}
            </div>
            <div className="text-right flex-shrink-0">
              <div className="flex items-center gap-1">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="text-lg font-bold text-foreground" data-testid="text-worst-teacher-rating">{data.worst.weeklyAvg}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">{data.worst.ratingCount} оцінок</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

function TeacherList({ onRate }: { onRate: (t: Teacher) => void }) {
  const { data: teachers, isLoading } = useQuery<Teacher[]>({
    queryKey: ['/api/teachers'],
    queryFn: async () => {
      const res = await fetch('/api/teachers', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  if (!teachers?.length) return (
    <div className="text-center py-12 text-gray-400">
      <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-40" />
      <p className="text-sm">Вчителів поки немає</p>
    </div>
  );

  return (
    <div className="space-y-3">
      {teachers.map((t) => (
        <Card key={t.id} className="p-4" data-testid={`card-teacher-${t.id}`}>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
              {t.photoUrl ? (
                <img src={t.photoUrl} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
              ) : (
                <User className="w-6 h-6" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-foreground truncate" data-testid={`text-teacher-name-${t.id}`}>{t.name}</h3>
              {t.subject && <p className="text-sm text-gray-500 truncate" data-testid={`text-teacher-subject-${t.id}`}>{t.subject}</p>}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-medium text-foreground/90" data-testid={`text-teacher-rating-${t.id}`}>
                  {t.averageRating || 0}
                </span>
              </div>
              <Button size="sm" variant="outline" onClick={() => onRate(t)} data-testid={`button-rate-teacher-${t.id}`}>
                Оцінити
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

function RateDialog({ teacher, onClose }: { teacher: Teacher; onClose: () => void }) {
  const [scores, setScores] = useState([3, 3, 3, 3]);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const categories = ["Пояснення матеріалу", "Справедливість оцінювання", "Ставлення до учнів", "Цікавість уроків"];

  const { mutate: rate, isPending } = useMutation({
    mutationFn: async () => {
      const res = await fetch(`/api/teachers/${teacher.id}/rate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ category1: scores[0], category2: scores[1], category3: scores[2], category4: scores[3] }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teachers'] });
      toast({ title: "Оцінку збережено!" });
      onClose();
    },
    onError: () => toast({ variant: "destructive", title: "Помилка" }),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" data-testid="dialog-rate-teacher">
      <Card className="w-full max-w-md p-5">
        <h2 className="text-lg font-bold text-foreground mb-1">Оцінити: {teacher.name}</h2>
        <p className="text-sm text-gray-500 mb-4">Оцініть від 1 до 5 за кожною категорією</p>

        <div className="space-y-4">
          {categories.map((cat, i) => (
            <div key={cat}>
              <label className="text-sm font-medium text-foreground/90 mb-1 block">{cat}</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((v) => (
                  <button
                    key={v}
                    onClick={() => { const s = [...scores]; s[i] = v; setScores(s); }}
                    className="flex-1"
                    data-testid={`button-score-${i}-${v}`}
                  >
                    <Star className={`w-6 h-6 mx-auto transition-colors ${v <= scores[i] ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`} />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-2 mt-5">
          <Button variant="outline" className="flex-1" onClick={onClose} data-testid="button-cancel-rate">Скасувати</Button>
          <Button className="flex-1" onClick={() => rate()} disabled={isPending} data-testid="button-submit-rate">
            {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Оцінити"}
          </Button>
        </div>
      </Card>
    </div>
  );
}

function AddTeacherForm({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const [subject, setSubject] = useState("");
  const [secret, setSecret] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { mutate: add, isPending } = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/teachers', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, subject, secret }),
        credentials: "include",
      });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/teachers'] });
      toast({ title: "Вчителя додано!" });
      onClose();
    },
    onError: (err: any) => toast({ variant: "destructive", title: "Помилка", description: err.message }),
  });

  return (
    <Card className="p-4 mb-4" data-testid="form-add-teacher">
      <h3 className="font-semibold text-foreground mb-3">Додати вчителя</h3>
      <div className="space-y-3">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Прізвище та ім'я"
          className="w-full bg-gray-50 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
          data-testid="input-teacher-name"
        />
        <input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Предмет"
          className="w-full bg-gray-50 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
          data-testid="input-teacher-subject"
        />
        <input
          value={secret}
          onChange={(e) => setSecret(e.target.value)}
          placeholder="Код додавання"
          type="password"
          className="w-full bg-gray-50 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 border border-border"
          data-testid="input-teacher-secret"
        />
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose} data-testid="button-cancel-add">Скасувати</Button>
          <Button className="flex-1" onClick={() => add()} disabled={isPending || !name.trim()} data-testid="button-submit-teacher">
            {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Додати"}
          </Button>
        </div>
      </div>
    </Card>
  );
}
