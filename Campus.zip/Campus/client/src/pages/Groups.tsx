import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Plus, ArrowLeft, Send, Image, Eye, EyeOff, ImagePlus } from "lucide-react";
import { VerifiedBadge } from "@/components/VerifiedBadge";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";
import { Link } from "wouter";
import { Sidebar, BottomNav } from "@/components/Navigation";
import type { Group, Post } from "@shared/schema";

type GroupWithCount = Group & { memberCount: number };
type GroupDetail = Group & { members: number[] };
type PostWithAuthor = Post & { authorName: string; authorAvatar: string | null; authorIsAdmin: boolean; authorIsOfficial: boolean };

export default function Groups() {
  const { user } = useAuth();
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60">
        {selectedGroupId ? (
          <GroupView groupId={selectedGroupId} onBack={() => setSelectedGroupId(null)} />
        ) : (
          <GroupList onSelect={setSelectedGroupId} />
        )}
      </main>
      <BottomNav />
    </div>
  );
}

function GroupList({ onSelect }: { onSelect: (id: number) => void }) {
  const { user } = useAuth();
  const [createOpen, setCreateOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const { data: groups = [], isLoading } = useQuery<GroupWithCount[]>({
    queryKey: ["/api/groups"],
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('description', description);
      if (avatarFile) formData.append('avatar', avatarFile);
      const res = await fetch('/api/groups', { method: 'POST', body: formData, credentials: 'include' });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
      setName("");
      setDescription("");
      setAvatarFile(null);
      setAvatarPreview(null);
      setCreateOpen(false);
    },
  });

  const joinMutation = useMutation({
    mutationFn: async (groupId: number) => {
      await apiRequest("POST", `/api/groups/${groupId}/join`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups"] });
    },
  });

  return (
    <div className="max-w-2xl mx-auto p-4">
        <div className="flex items-center justify-between mb-4 gap-2">
          <h1 className="text-xl font-bold" data-testid="text-groups-title">Групи</h1>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-create-group">
                <Plus className="w-4 h-4 mr-1" />
                Створити
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Нова група</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="flex flex-col items-center gap-2">
                  <div 
                    className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary cursor-pointer overflow-hidden border-2 border-dashed border-primary/30"
                    onClick={() => document.getElementById('group-avatar-input')?.click()}
                  >
                    {avatarPreview ? (
                      <img src={avatarPreview} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <ImagePlus className="w-6 h-6" />
                    )}
                  </div>
                  <input
                    id="group-avatar-input"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setAvatarFile(file);
                        const reader = new FileReader();
                        reader.onload = () => setAvatarPreview(reader.result as string);
                        reader.readAsDataURL(file);
                      }
                    }}
                    data-testid="input-group-avatar"
                  />
                  <span className="text-xs text-muted-foreground">Аватар групи</span>
                </div>
                <Input
                  placeholder="Назва групи"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  data-testid="input-group-name"
                />
                <Textarea
                  placeholder="Опис (необов'язково)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="resize-none"
                  data-testid="input-group-description"
                />
                <Button
                  className="w-full"
                  onClick={() => createMutation.mutate()}
                  disabled={!name.trim() || createMutation.isPending}
                  data-testid="button-submit-group"
                >
                  Створити групу
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Card key={i} className="p-4 animate-pulse h-20" />
            ))}
          </div>
        ) : groups.length === 0 ? (
          <Card className="p-8 text-center">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">Груп поки немає. Створіть першу!</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {groups.map(group => (
              <Card
                key={group.id}
                className="p-4 cursor-pointer hover-elevate"
                onClick={() => onSelect(group.id)}
                data-testid={`card-group-${group.id}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0 overflow-hidden">
                      {group.avatarUrl ? (
                        <img src={group.avatarUrl} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <Users className="w-5 h-5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate" data-testid={`text-group-name-${group.id}`}>{group.name}</h3>
                      {group.description && (
                        <p className="text-sm text-muted-foreground truncate mt-0.5">{group.description}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {group.memberCount} учасників
                      </p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      joinMutation.mutate(group.id);
                    }}
                    data-testid={`button-join-group-${group.id}`}
                  >
                    Приєднатися
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
  );
}

function GroupView({ groupId, onBack }: { groupId: number; onBack: () => void }) {
  const { user } = useAuth();
  const [content, setContent] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);

  const { data: group } = useQuery<GroupDetail>({
    queryKey: ["/api/groups", groupId],
  });

  const { data: posts = [], isLoading: postsLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/groups", groupId, "posts"],
  });

  const isMember = group?.members?.includes(user?.id || 0);

  const joinMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/groups/${groupId}/join`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", groupId] });
    },
  });

  const leaveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/groups/${groupId}/leave`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", groupId] });
    },
  });

  const postMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/groups/${groupId}/posts`, { content, isAnonymous });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/groups", groupId, "posts"] });
      setContent("");
    },
  });

  return (
    <div className="max-w-2xl mx-auto p-4">
        <div className="flex items-center gap-3 mb-4">
          <Button size="icon" variant="ghost" onClick={onBack} data-testid="button-back-groups">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0 overflow-hidden">
            {group?.avatarUrl ? (
              <img src={group.avatarUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              <Users className="w-5 h-5" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold truncate" data-testid="text-group-view-name">{group?.name}</h1>
            <p className="text-xs text-muted-foreground">
              {group?.members?.length || 0} учасників
            </p>
          </div>
          {isMember ? (
            <Button
              size="sm"
              variant="outline"
              onClick={() => leaveMutation.mutate()}
              disabled={leaveMutation.isPending}
              data-testid="button-leave-group"
            >
              Вийти
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => joinMutation.mutate()}
              disabled={joinMutation.isPending}
              data-testid="button-join-group"
            >
              Приєднатися
            </Button>
          )}
        </div>

        {group?.description && (
          <Card className="p-3 mb-4">
            <p className="text-sm text-muted-foreground">{group.description}</p>
          </Card>
        )}

        {isMember && (
          <Card className="p-3 mb-4">
            <Textarea
              placeholder="Напишіть щось у групу..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="resize-none mb-2"
              data-testid="input-group-post"
            />
            <div className="flex items-center justify-between gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setIsAnonymous(!isAnonymous)}
                className={isAnonymous ? "text-primary" : "text-muted-foreground"}
                data-testid="button-toggle-anon"
              >
                {isAnonymous ? <EyeOff className="w-4 h-4 mr-1" /> : <Eye className="w-4 h-4 mr-1" />}
                {isAnonymous ? "Анонімно" : "Від імені"}
              </Button>
              <Button
                size="sm"
                onClick={() => postMutation.mutate()}
                disabled={!content.trim() || postMutation.isPending}
                data-testid="button-submit-group-post"
              >
                <Send className="w-4 h-4 mr-1" />
                Надіслати
              </Button>
            </div>
          </Card>
        )}

        {postsLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Card key={i} className="p-4 animate-pulse h-20" />
            ))}
          </div>
        ) : posts.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Поки немає публікацій у цій групі</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {posts.map(post => (
              <Card key={post.id} className="p-4" data-testid={`card-group-post-${post.id}`}>
                <div className="flex items-center gap-2 mb-2">
                  {post.isAnonymous ? (
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold overflow-hidden flex-shrink-0">
                      {(post.anonTag?.[0] || "?").toUpperCase()}
                    </div>
                  ) : (
                    <Link href={`/profile/${post.userId}`}>
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold overflow-hidden flex-shrink-0 cursor-pointer">
                        {post.authorAvatar ? (
                          <img src={post.authorAvatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          post.authorName[0].toUpperCase()
                        )}
                      </div>
                    </Link>
                  )}
                  <div>
                    <div className="flex items-center gap-1">
                      <p className="text-sm font-semibold" data-testid={`text-post-author-${post.id}`}>
                        {post.isAnonymous ? post.anonTag : post.authorName}
                      </p>
                      {!post.isAnonymous && <VerifiedBadge isAdmin={post.authorIsAdmin} isOfficial={post.authorIsOfficial} />}
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {post.createdAt && formatDistanceToNow(new Date(post.createdAt), { addSuffix: true, locale: uk })}
                    </p>
                  </div>
                </div>
                <p className="text-sm whitespace-pre-wrap">{post.content}</p>
                {post.imageUrl && (
                  <img src={post.imageUrl} alt="" className="mt-2 rounded-lg max-h-60 object-cover w-full" />
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
  );
}
