import { useState } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useSchedules, useClassNames, useCreateSchedule, useDeleteSchedule } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { Calendar, Plus, Trash2, Clock, MapPin, GraduationCap, Loader2, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const dayNames = ["Понеділок", "Вівторок", "Середа", "Четвер", "П'ятниця", "Субота"];
const lessonTimes = ["8:00-8:45", "9:00-9:45", "10:00-10:45", "11:00-11:45", "12:00-12:45", "13:00-13:45", "14:00-14:45", "15:00-15:45"];

export default function SchedulePage() {
  const { user } = useAuth();
  const { data: classNames, isLoading: classLoading } = useClassNames();
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [showAdd, setShowAdd] = useState(false);
  const { data: schedule, isLoading } = useSchedules(selectedClass || undefined);
  const { mutate: createSchedule, isPending } = useCreateSchedule();
  const { mutate: deleteSchedule } = useDeleteSchedule();

  const [form, setForm] = useState({ className: "", dayOfWeek: 0, lessonNumber: 1, subject: "", teacherName: "", room: "" });

  const handleAdd = () => {
    if (!form.className || !form.subject) return;
    createSchedule(form, {
      onSuccess: () => {
        setShowAdd(false);
        setSelectedClass(form.className);
        setForm({ className: "", dayOfWeek: 0, lessonNumber: 1, subject: "", teacherName: "", room: "" });
      },
    });
  };

  const groupedByDay = (schedule || []).reduce((acc: Record<number, any[]>, item: any) => {
    if (!acc[item.dayOfWeek]) acc[item.dayOfWeek] = [];
    acc[item.dayOfWeek].push(item);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        <div className="max-w-xl mx-auto pt-6 px-4">
          <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
            <h1 className="text-xl font-bold flex items-center gap-2" data-testid="text-schedule-title">
              <Calendar className="w-5 h-5 text-primary" /> Розклад
            </h1>
            <Button size="sm" onClick={() => setShowAdd(!showAdd)} data-testid="button-add-schedule">
              <Plus className="w-4 h-4 mr-1" /> Додати урок
            </Button>
          </div>

          {showAdd && (
            <Card className="p-4 mb-4" data-testid="card-add-schedule">
              <div className="space-y-3">
                <input
                  value={form.className}
                  onChange={e => setForm({ ...form, className: e.target.value })}
                  placeholder="Клас (напр. 10-А)"
                  className="w-full bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                  data-testid="input-schedule-class"
                />
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={form.dayOfWeek}
                    onChange={e => setForm({ ...form, dayOfWeek: Number(e.target.value) })}
                    className="bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border"
                    data-testid="select-schedule-day"
                  >
                    {dayNames.map((d, i) => <option key={i} value={i}>{d}</option>)}
                  </select>
                  <select
                    value={form.lessonNumber}
                    onChange={e => setForm({ ...form, lessonNumber: Number(e.target.value) })}
                    className="bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border"
                    data-testid="select-schedule-lesson"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(n => <option key={n} value={n}>{n} урок ({lessonTimes[n - 1]})</option>)}
                  </select>
                </div>
                <input
                  value={form.subject}
                  onChange={e => setForm({ ...form, subject: e.target.value })}
                  placeholder="Предмет"
                  className="w-full bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                  data-testid="input-schedule-subject"
                />
                <div className="grid grid-cols-2 gap-2">
                  <input
                    value={form.teacherName}
                    onChange={e => setForm({ ...form, teacherName: e.target.value })}
                    placeholder="Вчитель (необов.)"
                    className="bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                    data-testid="input-schedule-teacher"
                  />
                  <input
                    value={form.room}
                    onChange={e => setForm({ ...form, room: e.target.value })}
                    placeholder="Кабінет (необов.)"
                    className="bg-gray-50 rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
                    data-testid="input-schedule-room"
                  />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleAdd} disabled={isPending || !form.className || !form.subject} data-testid="button-save-schedule">
                    {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Зберегти"}
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowAdd(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          )}

          <div className="flex gap-2 mb-4 overflow-x-auto pb-1" data-testid="schedule-class-tabs">
            <button
              onClick={() => setSelectedClass("")}
              className={`text-xs font-medium px-3 py-1.5 rounded-full flex-shrink-0 transition-colors ${!selectedClass ? "bg-primary text-white" : "bg-white text-gray-600 border border-border"}`}
              data-testid="button-all-classes"
            >
              Усі класи
            </button>
            {(classNames || []).map((cn: string) => (
              <button
                key={cn}
                onClick={() => setSelectedClass(cn)}
                className={`text-xs font-medium px-3 py-1.5 rounded-full flex-shrink-0 transition-colors ${selectedClass === cn ? "bg-primary text-white" : "bg-white text-gray-600 border border-border"}`}
                data-testid={`button-class-${cn}`}
              >
                {cn}
              </button>
            ))}
          </div>

          {isLoading && (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          )}

          {!isLoading && (!schedule || schedule.length === 0) && (
            <Card className="text-center py-12">
              <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm text-muted-foreground">Розклад порожній</p>
              <p className="text-xs text-muted-foreground mt-1">Натисніть "Додати урок" щоб почати</p>
            </Card>
          )}

          {Object.entries(groupedByDay).sort(([a], [b]) => Number(a) - Number(b)).map(([day, lessons]: [string, any[]]) => (
            <Card key={day} className="p-4 mb-3" data-testid={`schedule-day-${day}`}>
              <h3 className="font-semibold text-sm text-primary mb-2">{dayNames[Number(day)]}</h3>
              <div className="space-y-2">
                {lessons.sort((a: any, b: any) => a.lessonNumber - b.lessonNumber).map((lesson: any) => (
                  <div key={lesson.id} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50" data-testid={`schedule-entry-${lesson.id}`}>
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs flex-shrink-0">
                      {lesson.lessonNumber}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{lesson.subject}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{lessonTimes[lesson.lessonNumber - 1]}</span>
                        {lesson.teacherName && <span className="flex items-center gap-1"><GraduationCap className="w-3 h-3" />{lesson.teacherName}</span>}
                        {lesson.room && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{lesson.room}</span>}
                        {selectedClass === "" && <span className="text-primary font-medium">{lesson.className}</span>}
                      </div>
                    </div>
                    <button
                      onClick={() => deleteSchedule(lesson.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
                      data-testid={`button-delete-schedule-${lesson.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </main>
      <BottomNav />
    </div>
  );
}
