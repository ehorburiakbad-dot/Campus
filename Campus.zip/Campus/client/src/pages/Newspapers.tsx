import { useState, useRef } from "react";
import { Sidebar, BottomNav } from "@/components/Navigation";
import { useNewspapers, useNewspaper, useSubscribe, useCreateNewspaper, useCreateArticle, usePolls, useCreatePoll, useVotePoll } from "@/hooks/use-data";
import { useAuth } from "@/hooks/use-auth";
import { Newspaper, Plus, ArrowLeft, BookOpen, Crown, Users, Zap, Key, Copy, Check, BarChart3, Loader2, X, ImagePlus } from "lucide-react";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { uk } from "date-fns/locale";

const typeConfig: Record<string, { label: string; icon: any; color: string }> = {
  official: { label: "Офіційна", icon: Crown, color: "text-yellow-600 bg-yellow-50" },
  user: { label: "Користувацька", icon: Users, color: "text-blue-600 bg-blue-50" },
  free: { label: "Вільна", icon: Zap, color: "text-green-600 bg-green-50" },
};

export default function Newspapers() {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Sidebar />
      <main className="md:ml-60 pb-20 md:pb-6">
        {selectedId ? (
          <NewspaperView id={selectedId} onBack={() => setSelectedId(null)} />
        ) : (
          <NewspaperList onSelect={setSelectedId} />
        )}
      </main>
      <BottomNav />
    </div>
  );
}

function NewspaperList({ onSelect }: { onSelect: (id: number) => void }) {
  const { data: papers, isLoading } = useNewspapers();
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  return (
    <div className="max-w-xl mx-auto pt-6 px-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold" data-testid="text-newspapers-title">Газети</h1>
        <CreateNewspaperDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} />
      </div>

      {isLoading ? (
        <div className="space-y-4">{[1, 2].map(i => <div key={i} className="h-32 bg-card rounded-xl animate-pulse" />)}</div>
      ) : !papers?.length ? (
        <div className="text-center py-16 bg-card rounded-xl border border-border">
          <Newspaper className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p className="text-muted-foreground">Немає газет</p>
        </div>
      ) : (
        <div className="space-y-4">
          {papers.map((paper: any) => {
            const cfg = typeConfig[paper.type] || typeConfig.user;
            const Icon = cfg.icon;
            return (
              <button
                key={paper.id}
                onClick={() => onSelect(paper.id)}
                className="w-full bg-card rounded-xl shadow-sm border border-border p-5 text-left hover:shadow-md transition-shadow"
                data-testid={`card-newspaper-${paper.id}`}
              >
                <div className="flex items-start gap-4">
                  <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0", cfg.color)}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-base">{paper.name}</h3>
                      <span className={cn("text-[10px] font-semibold px-2 py-0.5 rounded-full", cfg.color)}>{cfg.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">{paper.description || "Без опису"}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

function NewspaperView({ id, onBack }: { id: number; onBack: () => void }) {
  const { data: paper, isLoading } = useNewspaper(id);
  const { mutate: toggleSub } = useSubscribe();
  const [isArticleOpen, setIsArticleOpen] = useState(false);
  const [isPollOpen, setIsPollOpen] = useState(false);

  if (isLoading || !paper) {
    return <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  }

  const cfg = typeConfig[paper.type] || typeConfig.user;
  const Icon = cfg.icon;

  return (
    <div className="max-w-xl mx-auto pt-6 px-4">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary mb-4 transition-colors" data-testid="button-back-newspapers">
        <ArrowLeft className="w-4 h-4" /> Назад до газет
      </button>

      <Card className="p-6 mb-6">
        <div className="flex items-center gap-4 mb-4">
          <div className={cn("w-14 h-14 rounded-lg flex items-center justify-center", cfg.color)}>
            <Icon className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl font-bold" data-testid="text-newspaper-name">{paper.name}</h1>
            <p className="text-sm text-muted-foreground">{paper.subscriberCount} підписників</p>
          </div>
        </div>
        {paper.description && <p className="text-sm text-muted-foreground mb-4">{paper.description}</p>}

        {paper.isCreator && paper.writeCode && (
          <WriteCodeDisplay code={paper.writeCode} />
        )}

        <div className="flex gap-2 flex-wrap">
          <Button
            onClick={() => toggleSub({ id: paper.id, action: paper.isSubscribed ? 'unsubscribe' : 'subscribe' })}
            variant={paper.isSubscribed ? "outline" : "default"}
            size="sm"
            data-testid="button-subscribe"
          >
            {paper.isSubscribed ? "Відписатися" : "Підписатися"}
          </Button>

          <AddArticleDialog newspaperId={paper.id} open={isArticleOpen} onOpenChange={setIsArticleOpen} />

          <Button variant="outline" size="sm" onClick={() => setIsPollOpen(true)} data-testid="button-create-poll">
            <BarChart3 className="w-4 h-4 mr-1" /> Опитування
          </Button>
        </div>
      </Card>

      <PollsSection newspaperId={id} />

      {isPollOpen && <CreatePollForm newspaperId={id} onClose={() => setIsPollOpen(false)} />}

      <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
        <BookOpen className="w-5 h-5 text-primary" /> Статті
      </h2>

      {!paper.articles?.length ? (
        <Card className="text-center py-12">
          <p className="text-muted-foreground text-sm">Поки що немає статей</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {paper.articles.map((article: any) => (
            <Card key={article.id} className="p-5" data-testid={`card-article-${article.id}`}>
              <h3 className="font-bold text-base mb-2">{article.title}</h3>
              {article.imageUrl && (
                <img src={article.imageUrl} alt="" className="w-full max-h-64 object-cover rounded-lg mb-3" data-testid={`img-article-${article.id}`} />
              )}
              <p className="text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">{article.content}</p>
              <p className="text-xs text-muted-foreground mt-3">
                {article.createdAt && formatDistanceToNow(new Date(article.createdAt), { addSuffix: true, locale: uk })}
              </p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function PollsSection({ newspaperId }: { newspaperId: number }) {
  const { data: pollsList, isLoading } = usePolls(newspaperId);
  const { mutate: vote } = useVotePoll();

  if (isLoading) return null;
  if (!pollsList?.length) return null;

  return (
    <div className="mb-6">
      <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
        <BarChart3 className="w-5 h-5 text-primary" /> Опитування
      </h2>
      <div className="space-y-4">
        {pollsList.map((poll: any) => (
          <Card key={poll.id} className="p-4" data-testid={`card-poll-${poll.id}`}>
            <h3 className="font-semibold text-sm mb-3">{poll.question}</h3>
            <div className="space-y-2">
              {poll.options.map((opt: any) => {
                const pct = poll.totalVotes > 0 ? Math.round((opt.voteCount / poll.totalVotes) * 100) : 0;
                const isVoted = poll.userVote === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => vote({ pollId: poll.id, optionId: opt.id, newspaperId })}
                    className={cn(
                      "w-full text-left p-2.5 rounded-lg text-sm relative overflow-hidden transition-all border",
                      isVoted ? "border-primary bg-primary/5" : "border-gray-200 hover:border-gray-300"
                    )}
                    data-testid={`button-poll-option-${opt.id}`}
                  >
                    <div
                      className="absolute inset-0 bg-primary/10 transition-all"
                      style={{ width: `${pct}%` }}
                    />
                    <div className="relative flex items-center justify-between gap-2">
                      <span className={cn("truncate", isVoted && "font-semibold")}>{opt.text}</span>
                      <span className="text-xs text-muted-foreground flex-shrink-0">{pct}%</span>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className="text-xs text-muted-foreground mt-2">{poll.totalVotes} голосів</p>
          </Card>
        ))}
      </div>
    </div>
  );
}

function CreatePollForm({ newspaperId, onClose }: { newspaperId: number; onClose: () => void }) {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", ""]);
  const [writeCode, setWriteCode] = useState("");
  const { mutate: create, isPending } = useCreatePoll();

  const addOption = () => { if (options.length < 6) setOptions([...options, ""]); };
  const updateOption = (i: number, val: string) => { const o = [...options]; o[i] = val; setOptions(o); };
  const removeOption = (i: number) => { if (options.length > 2) setOptions(options.filter((_, j) => j !== i)); };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validOptions = options.filter(o => o.trim());
    if (validOptions.length < 2) return;
    create({ newspaperId, question, options: validOptions, writeCode }, { onSuccess: () => onClose() });
  };

  return (
    <Card className="p-4 mb-6" data-testid="form-create-poll">
      <h3 className="font-semibold text-sm mb-3 flex items-center justify-between">
        Нове опитування
        <button onClick={onClose} className="text-gray-400 hover:text-muted-foreground"><X className="w-4 h-4" /></button>
      </h3>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <input
            placeholder="Код газети"
            value={writeCode}
            onChange={e => setWriteCode(e.target.value)}
            className="w-full p-2.5 bg-gray-50 rounded-lg border text-sm font-mono"
            data-testid="input-poll-code"
            required
          />
        </div>
        <input
          placeholder="Питання"
          value={question}
          onChange={e => setQuestion(e.target.value)}
          className="w-full p-2.5 bg-gray-50 rounded-lg border text-sm"
          data-testid="input-poll-question"
          required
        />
        {options.map((opt, i) => (
          <div key={i} className="flex gap-2">
            <input
              placeholder={`Варіант ${i + 1}`}
              value={opt}
              onChange={e => updateOption(i, e.target.value)}
              className="flex-1 p-2.5 bg-gray-50 rounded-lg border text-sm"
              data-testid={`input-poll-option-${i}`}
            />
            {options.length > 2 && (
              <button type="button" onClick={() => removeOption(i)} className="text-gray-400 hover:text-red-500">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        ))}
        {options.length < 6 && (
          <button type="button" onClick={addOption} className="text-sm text-primary hover:underline" data-testid="button-add-poll-option">
            + Додати варіант
          </button>
        )}
        <Button type="submit" className="w-full" disabled={isPending || !question.trim() || options.filter(o => o.trim()).length < 2 || !writeCode.trim()} data-testid="button-submit-poll">
          {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Створити опитування"}
        </Button>
      </form>
    </Card>
  );
}

function CreateNewspaperDialog({ open, onOpenChange }: any) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("user");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [createdCode, setCreatedCode] = useState<string | null>(null);
  const { mutate: create, isPending } = useCreateNewspaper();
  const { user } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    create({ name, description, type, isAnonymous }, {
      onSuccess: (data: any) => {
        setCreatedCode(data.writeCode);
        setName(""); setDescription("");
      },
    });
  };

  const handleClose = (val: boolean) => {
    if (!val) setCreatedCode(null);
    onOpenChange(val);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogTrigger asChild>
        <button className="bg-primary text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium hover:bg-primary/90 transition" data-testid="button-create-newspaper">
          <Plus className="w-4 h-4" /> Створити
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        {createdCode ? (
          <>
            <DialogHeader><DialogTitle>Газету створено!</DialogTitle></DialogHeader>
            <div className="mt-4 space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-center">
                <Key className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                <p className="text-sm text-amber-800 font-medium mb-2">Ваш код для написання статей:</p>
                <code className="bg-card px-4 py-2 rounded border border-amber-200 font-mono text-lg font-bold tracking-widest" data-testid="text-created-write-code">{createdCode}</code>
                <p className="text-xs text-amber-600 mt-3">Збережіть цей код! Поділіться ним з тими, хто може публікувати статті у вашій газеті.</p>
              </div>
              <button onClick={() => handleClose(false)} className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-primary/90" data-testid="button-close-code-dialog">
                Зрозуміло
              </button>
            </div>
          </>
        ) : (
          <>
            <DialogHeader><DialogTitle>Нова газета</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-2">
              <input placeholder="Назва газети" value={name} onChange={e => setName(e.target.value)} className="w-full p-3 bg-gray-50 rounded-lg border" data-testid="input-newspaper-name" required />
              <textarea placeholder="Опис" value={description} onChange={e => setDescription(e.target.value)} className="w-full p-3 bg-gray-50 rounded-lg border min-h-[80px] resize-none" data-testid="input-newspaper-description" />
              <div className="flex gap-2">
                {user?.isOfficial && (
                  <button type="button" onClick={() => setType("official")} className={cn("text-xs px-3 py-1.5 rounded-full font-medium", type === "official" ? "bg-yellow-100 text-yellow-700" : "bg-gray-100 text-muted-foreground")}>
                    Офіційна
                  </button>
                )}
                <button type="button" onClick={() => setType("user")} className={cn("text-xs px-3 py-1.5 rounded-full font-medium", type === "user" ? "bg-blue-100 text-blue-700" : "bg-gray-100 text-muted-foreground")}>
                  Користувацька
                </button>
                <button type="button" onClick={() => setType("free")} className={cn("text-xs px-3 py-1.5 rounded-full font-medium", type === "free" ? "bg-green-100 text-green-700" : "bg-gray-100 text-muted-foreground")}>
                  Вільна
                </button>
              </div>
              <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
                <input type="checkbox" checked={isAnonymous} onChange={e => setIsAnonymous(e.target.checked)} className="rounded" />
                Анонімна газета
              </label>
              <button type="submit" disabled={isPending || !name.trim()} className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-primary/90 disabled:opacity-50" data-testid="button-submit-newspaper">
                {isPending ? "Створення..." : "Створити газету"}
              </button>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function WriteCodeDisplay({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
      <p className="text-xs text-amber-700 mb-1.5 flex items-center gap-1.5">
        <Key className="w-3.5 h-3.5" /> Код для написання статей (тільки ви бачите):
      </p>
      <div className="flex items-center gap-2">
        <code className="bg-card px-3 py-1.5 rounded border border-amber-200 font-mono text-sm font-bold tracking-wider" data-testid="text-write-code">{code}</code>
        <button onClick={handleCopy} className="text-amber-600 hover:text-amber-800 transition-colors" data-testid="button-copy-code">
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>
      <p className="text-[11px] text-amber-600 mt-1.5">Поділіться цим кодом з тими, хто може писати статті</p>
    </div>
  );
}

function AddArticleDialog({ newspaperId, open, onOpenChange }: any) {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [writeCode, setWriteCode] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const { mutate: create, isPending } = useCreateArticle();

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setImage(null);
    setImagePreview(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    create({ newspaperId, title, content, isAnonymous, writeCode, image }, {
      onSuccess: () => { onOpenChange(false); setTitle(""); setContent(""); setWriteCode(""); clearImage(); },
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <button className="bg-gray-100 text-foreground/90 px-4 py-2 rounded-lg flex items-center gap-2 font-medium hover:bg-gray-200 transition text-sm" data-testid="button-add-article">
          <Plus className="w-4 h-4" /> Написати статтю
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Нова стаття</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div>
            <label className="text-sm font-medium text-foreground/90 mb-1 block">Код доступу</label>
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                placeholder="Введіть код газети"
                value={writeCode}
                onChange={e => setWriteCode(e.target.value)}
                className="w-full pl-9 p-3 bg-gray-50 rounded-lg border font-mono tracking-wider"
                data-testid="input-article-code"
                required
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">Код можна отримати у творця газети</p>
          </div>
          <input placeholder="Заголовок" value={title} onChange={e => setTitle(e.target.value)} className="w-full p-3 bg-gray-50 rounded-lg border" data-testid="input-article-title" required />
          <textarea placeholder="Текст статті..." value={content} onChange={e => setContent(e.target.value)} className="w-full p-3 bg-gray-50 rounded-lg border min-h-[120px] resize-none" data-testid="input-article-content" required />

          <div>
            <input type="file" ref={fileRef} accept="image/*" onChange={handleImageSelect} className="hidden" data-testid="input-article-image" />
            {imagePreview ? (
              <div className="relative">
                <img src={imagePreview} alt="Preview" className="w-full max-h-48 object-cover rounded-lg" />
                <button type="button" onClick={clearImage} className="absolute top-2 right-2 bg-black/60 text-white rounded-full p-1">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button type="button" onClick={() => fileRef.current?.click()} className="w-full p-3 border border-dashed border-border rounded-lg flex items-center justify-center gap-2 text-muted-foreground hover:bg-accent/30 transition text-sm" data-testid="button-article-add-image">
                <ImagePlus className="w-5 h-5" />
                Додати фото
              </button>
            )}
          </div>

          <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
            <input type="checkbox" checked={isAnonymous} onChange={e => setIsAnonymous(e.target.checked)} className="rounded" />
            Опублікувати анонімно
          </label>
          <button type="submit" disabled={isPending || !title.trim() || !content.trim() || !writeCode.trim()} className="w-full bg-primary text-white py-3 rounded-lg font-bold hover:bg-primary/90 disabled:opacity-50" data-testid="button-submit-article">
            {isPending ? "Публікація..." : "Опублікувати"}
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
