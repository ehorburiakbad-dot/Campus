import { Link, useLocation } from "wouter";
import { Home, MessageSquare, Newspaper, LogOut, Shield, GraduationCap, Search, Bell, User, Users, Moon, Sun } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useNotifications, useMarkNotificationsRead, useBrowserNotifications } from "@/hooks/use-data";
import { useTheme } from "@/hooks/use-theme";

const navItems = [
  { title: "Стрічка", url: "/", icon: Home },
  { title: "Пошук", url: "/search", icon: Search },
  { title: "Вчителі", url: "/teachers", icon: GraduationCap },
  { title: "Чат", url: "/chat", icon: MessageSquare },
  { title: "Газети", url: "/newspapers", icon: Newspaper },
  { title: "Групи", url: "/groups", icon: Users },
];

const mobileNavItems = [
  { title: "Стрічка", url: "/", icon: Home },
  { title: "Газети", url: "/newspapers", icon: Newspaper },
  { title: "Чат", url: "/chat", icon: MessageSquare },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: notifData } = useNotifications();
  const { mutate: markRead } = useMarkNotificationsRead();
  const unread = notifData?.unreadCount || 0;
  useBrowserNotifications();
  const { theme, toggle } = useTheme();

  return (
    <aside className="hidden md:flex flex-col w-60 bg-card border-r border-border h-screen fixed left-0 top-0 z-10">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <Link href="/">
          <span className="text-2xl font-bold text-primary cursor-pointer" data-testid="link-logo">Campus</span>
        </Link>
        <button
          onClick={toggle}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          data-testid="button-theme-toggle"
        >
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <Link key={item.url} href={item.url}>
            <span className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
              location === item.url ? "bg-accent text-primary" : "text-muted-foreground hover:bg-accent/50"
            )} data-testid={`nav-${item.title.toLowerCase()}`}>
              <item.icon className="w-5 h-5" />
              {item.title}
            </span>
          </Link>
        ))}

        <Link href="/notifications">
          <span className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer relative",
            location === "/notifications" ? "bg-accent text-primary" : "text-muted-foreground hover:bg-accent/50"
          )} data-testid="nav-notifications" onClick={() => { if (unread > 0) markRead(); }}>
            <Bell className="w-5 h-5" />
            Сповіщення
            {unread > 0 && (
              <span className="ml-auto bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center" data-testid="badge-notifications">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </span>
        </Link>

        {user?.isAdmin && (
          <Link href="/admin">
            <span className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer",
              location === "/admin" ? "bg-destructive/10 text-destructive" : "text-destructive/60 hover:bg-destructive/10"
            )} data-testid="nav-admin">
              <Shield className="w-5 h-5" />
              Адмін
            </span>
          </Link>
        )}
      </nav>

      {user && (
        <div className="p-3 border-t border-border">
          <Link href={`/profile/${user.id}`}>
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-accent/50 transition-colors cursor-pointer" data-testid="nav-profile">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm overflow-hidden flex-shrink-0">
                {user.avatarUrl ? <img src={user.avatarUrl} alt="" className="w-full h-full object-cover" /> : user.username.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-medium truncate max-w-[100px]" data-testid="text-username">{user.username}</span>
            </div>
          </Link>
          <button onClick={() => logout()} className="flex items-center gap-3 px-3 py-2 w-full text-muted-foreground hover:text-destructive transition-colors text-sm" data-testid="button-logout">
            <LogOut className="w-4 h-4" />
            Вийти
          </button>
        </div>
      )}
    </aside>
  );
}

export function BottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();
  const { data: notifData } = useNotifications();
  const unread = notifData?.unreadCount || 0;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border px-1 py-2 z-50 flex items-center justify-around shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      {mobileNavItems.map((item) => (
        <Link key={item.url} href={item.url}>
          <span className={cn(
            "flex flex-col items-center gap-0.5 min-w-[56px] transition-colors cursor-pointer",
            location === item.url ? "text-primary" : "text-muted-foreground"
          )} data-testid={`bottomnav-${item.title.toLowerCase()}`}>
            <item.icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{item.title}</span>
          </span>
        </Link>
      ))}

      <Link href="/notifications">
        <span className={cn(
          "flex flex-col items-center gap-0.5 min-w-[56px] transition-colors cursor-pointer relative",
          location === "/notifications" ? "text-primary" : "text-muted-foreground"
        )} data-testid="bottomnav-notifications">
          <div className="relative">
            <Bell className="w-5 h-5" />
            {unread > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[8px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium">Сповіщення</span>
        </span>
      </Link>

      {user && (
        <Link href={`/profile/${user.id}`}>
          <span className={cn(
            "flex flex-col items-center gap-0.5 min-w-[56px] transition-colors cursor-pointer",
            location.startsWith("/profile") ? "text-primary" : "text-muted-foreground"
          )} data-testid="bottomnav-profile">
            <User className="w-5 h-5" />
            <span className="text-[10px] font-medium">Профіль</span>
          </span>
        </Link>
      )}
    </nav>
  );
}
