import { CheckCircle2 } from "lucide-react";

interface VerifiedBadgeProps {
  isAdmin?: boolean;
  isOfficial?: boolean;
  className?: string;
}

export function VerifiedBadge({ isAdmin, isOfficial, className = "" }: VerifiedBadgeProps) {
  if (!isAdmin && !isOfficial) return null;

  const color = isAdmin ? "text-green-500" : "text-blue-500";

  return (
    <CheckCircle2
      className={`w-4 h-4 ${color} flex-shrink-0 ${className}`}
      fill="currentColor"
      stroke="white"
      strokeWidth={2}
      data-testid={isAdmin ? "badge-admin-verified" : "badge-official-verified"}
    />
  );
}
