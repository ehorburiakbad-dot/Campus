import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";

export function usePosts() {
  return useQuery({
    queryKey: ['/api/posts'],
    queryFn: async () => {
      const res = await fetch('/api/posts', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { content: string; isAnonymous: boolean; image?: File; audio?: Blob }) => {
      const formData = new FormData();
      formData.append('content', data.content);
      formData.append('isAnonymous', String(data.isAnonymous));
      if (data.image) formData.append('image', data.image);
      if (data.audio) formData.append('audio', data.audio, 'voice.webm');
      const res = await fetch('/api/posts', { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({ title: "Опубліковано!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useComments(postId: number | null) {
  return useQuery({
    queryKey: ['/api/posts', postId, 'comments'],
    queryFn: async () => {
      if (!postId) return [];
      const res = await fetch(`/api/posts/${postId}/comments`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!postId,
  });
}

export function useCreateComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { postId: number; content: string; isAnonymous: boolean; parentId?: number; image?: File }) => {
      const formData = new FormData();
      formData.append("content", data.content);
      formData.append("isAnonymous", String(data.isAnonymous));
      if (data.parentId) formData.append("parentId", String(data.parentId));
      if (data.image) formData.append("image", data.image);
      const res = await fetch(`/api/posts/${data.postId}/comments`, { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts', vars.postId, 'comments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useLikeComment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { commentId: number; postId: number }) => {
      const res = await fetch(`/api/comments/${data.commentId}/like`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts', vars.postId, 'comments'] });
    },
  });
}

export function useStories() {
  return useQuery({
    queryKey: ['/api/stories'],
    queryFn: async () => {
      const res = await fetch('/api/stories', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useCreateStory() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { image: File; caption?: string; textOverlays?: string }) => {
      const formData = new FormData();
      formData.append('image', data.image);
      if (data.caption) formData.append('caption', data.caption);
      if (data.textOverlays) formData.append('textOverlays', data.textOverlays);
      const res = await fetch('/api/stories', { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/stories'] });
      toast({ title: "Історію додано!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useRecommendations() {
  return useQuery({
    queryKey: ['/api/recommendations'],
    queryFn: async () => {
      const res = await fetch('/api/recommendations', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function usePolls(newspaperId: number | null) {
  return useQuery({
    queryKey: ['/api/newspapers', newspaperId, 'polls'],
    queryFn: async () => {
      if (!newspaperId) return [];
      const res = await fetch(`/api/newspapers/${newspaperId}/polls`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!newspaperId,
  });
}

export function useCreatePoll() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { newspaperId: number; question: string; options: string[]; writeCode: string }) => {
      const res = await fetch(`/api/newspapers/${data.newspaperId}/polls`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers', vars.newspaperId, 'polls'] });
      toast({ title: "Опитування створено!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useVotePoll() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { pollId: number; optionId: number; newspaperId: number }) => {
      const res = await fetch(`/api/polls/${data.pollId}/vote`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ optionId: data.optionId }), credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers', vars.newspaperId, 'polls'] });
    },
  });
}

export function useVotePost() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/posts/${id}/vote`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/posts'] }),
  });
}

export function useReactPost() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { postId: number; type: string }) => {
      const res = await fetch(`/api/posts/${data.postId}/react`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type: data.type }), credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/posts'] }),
  });
}

export function useSharePost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (postId: number) => {
      const res = await fetch(`/api/posts/${postId}/share`, { method: "POST", credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({ title: "Допис поширено!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useUsers() {
  return useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const res = await fetch('/api/users', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useConversations() {
  return useQuery({
    queryKey: ['/api/conversations'],
    queryFn: async () => {
      const res = await fetch('/api/conversations', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useMessages(otherUserId: number | null) {
  return useQuery({
    queryKey: ['/api/messages', otherUserId],
    queryFn: async () => {
      if (!otherUserId) return [];
      const res = await fetch(`/api/messages?userId=${otherUserId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!otherUserId,
    refetchInterval: 3000,
  });
}

export function useSendMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { content: string; receiverId: number; audio?: Blob; replyToId?: number }) => {
      const formData = new FormData();
      formData.append('content', data.content);
      formData.append('receiverId', String(data.receiverId));
      if (data.audio) formData.append('audio', data.audio, 'voice.webm');
      if (data.replyToId) formData.append('replyToId', String(data.replyToId));
      const res = await fetch('/api/messages', { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: (_data, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/messages', vars.receiverId] });
      queryClient.invalidateQueries({ queryKey: ['/api/conversations'] });
    },
  });
}

export function useNewspapers() {
  return useQuery({
    queryKey: ['/api/newspapers'],
    queryFn: async () => {
      const res = await fetch('/api/newspapers', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useNewspaper(id: number | null) {
  return useQuery({
    queryKey: ['/api/newspapers', id],
    queryFn: async () => {
      if (!id) return null;
      const res = await fetch(`/api/newspapers/${id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!id,
  });
}

export function useSubscribe() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, action }: { id: number; action: 'subscribe' | 'unsubscribe' }) => {
      const res = await fetch(`/api/newspapers/${id}/${action}`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers', vars.id] });
      toast({ title: vars.action === 'subscribe' ? "Підписано!" : "Відписано" });
    },
  });
}

export function useCreateNewspaper() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { name: string; description: string; type: string; isAnonymous: boolean }) => {
      const res = await fetch('/api/newspapers', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers'] });
      toast({ title: "Газету створено!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useCreateArticle() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ newspaperId, image, ...data }: { newspaperId: number; title: string; content: string; isAnonymous: boolean; writeCode: string; image?: File | null }) => {
      const formData = new FormData();
      formData.append('title', data.title);
      formData.append('content', data.content);
      formData.append('isAnonymous', String(data.isAnonymous));
      formData.append('writeCode', data.writeCode);
      if (image) formData.append('image', image);
      const res = await fetch(`/api/newspapers/${newspaperId}/articles`, { method: "POST", body: formData, credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/newspapers', vars.newspaperId] });
      toast({ title: "Статтю додано!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

// === New Feature Hooks ===

export function useNotifications() {
  return useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const res = await fetch('/api/notifications', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    refetchInterval: 5000,
  });
}

export function useBrowserNotifications() {
  const { data } = useNotifications();
  const prevCountRef = useRef<number>(0);

  useEffect(() => {
    if (!data) return;
    const currentUnread = data.unreadCount || 0;
    if (currentUnread > prevCountRef.current && prevCountRef.current > 0 && document.hidden) {
      try {
        if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === "granted") {
          const latest = data.notifications?.[0];
          new Notification("Campus", {
            body: latest?.message || `${currentUnread} нових сповіщень`,
          });
        }
      } catch {}
    }
    prevCountRef.current = currentUnread;
  }, [data]);
}

export function useMarkNotificationsRead() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/notifications/read', { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/notifications'] }),
  });
}

export function useSearch(query: string) {
  return useQuery({
    queryKey: ['/api/search', query],
    queryFn: async () => {
      if (!query.trim()) return { posts: [], users: [], groups: [], newspapers: [] };
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: query.trim().length > 0,
  });
}

export function useProfile(userId: number | null) {
  return useQuery({
    queryKey: ['/api/profile', userId],
    queryFn: async () => {
      if (!userId) return null;
      const res = await fetch(`/api/profile/${userId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!userId,
  });
}

export function useUpdateProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { bio?: string; avatar?: File; header?: File; displayName?: string; statusText?: string; mood?: string; profileColor?: string; location?: string; website?: string }) => {
      const formData = new FormData();
      if (data.bio !== undefined) formData.append('bio', data.bio);
      if (data.avatar) formData.append('avatar', data.avatar);
      if (data.header) formData.append('header', data.header);
      const textFields = ['displayName', 'statusText', 'mood', 'profileColor', 'location', 'website'] as const;
      for (const f of textFields) { if (data[f] !== undefined) formData.append(f, data[f] || ''); }
      const res = await fetch('/api/profile', { method: "PATCH", body: formData, credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({ title: "Профіль оновлено!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useSchedules(className?: string) {
  return useQuery({
    queryKey: ['/api/schedules', className],
    queryFn: async () => {
      const url = className ? `/api/schedules?class=${encodeURIComponent(className)}` : '/api/schedules';
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useClassNames() {
  return useQuery({
    queryKey: ['/api/schedules/classes'],
    queryFn: async () => {
      const res = await fetch('/api/schedules/classes', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useCreateSchedule() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { className: string; dayOfWeek: number; lessonNumber: number; subject: string; teacherName?: string; room?: string }) => {
      const res = await fetch('/api/schedules', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedules'] });
      queryClient.invalidateQueries({ queryKey: ['/api/schedules/classes'] });
      toast({ title: "Урок додано!" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useDeleteSchedule() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/schedules/${id}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/schedules'] });
      queryClient.invalidateQueries({ queryKey: ['/api/schedules/classes'] });
    },
  });
}

export function useAchievements(userId?: number) {
  return useQuery({
    queryKey: ['/api/achievements', userId],
    queryFn: async () => {
      const url = userId ? `/api/achievements/${userId}` : '/api/achievements';
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useDeletePost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (postId: number) => {
      const res = await fetch(`/api/posts/${postId}`, { method: "DELETE", credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({ title: "Допис видалено" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function usePinPost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ postId, action }: { postId: number; action: 'pin' | 'unpin' }) => {
      const res = await fetch(`/api/posts/${postId}/${action}`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: (_d, vars) => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      toast({ title: vars.action === 'pin' ? "Допис закріплено" : "Допис відкріплено" });
    },
  });
}

export function useCreateReport() {
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (data: { targetType: string; targetId: number; reason: string }) => {
      const res = await fetch('/api/reports', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Error"); }
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Скаргу надіслано" });
    },
    onError: (err: any) => {
      toast({ variant: "destructive", title: "Помилка", description: err.message });
    },
  });
}

export function useAdminReports() {
  return useQuery({
    queryKey: ['/api/admin/reports'],
    queryFn: async () => {
      const res = await fetch('/api/admin/reports', { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });
}

export function useUpdateReportStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ reportId, status }: { reportId: number; status: string }) => {
      const res = await fetch(`/api/admin/reports/${reportId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }), credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/reports'] });
    },
  });
}

export function useSearchMessages(userId: number | null, query: string) {
  return useQuery({
    queryKey: ['/api/messages/search', userId, query],
    queryFn: async () => {
      if (!userId || !query.trim()) return [];
      const res = await fetch(`/api/messages/search?userId=${userId}&q=${encodeURIComponent(query)}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!userId && query.trim().length > 0,
  });
}

export function useVoteFeedPoll() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: { postId: number; optionId: number }) => {
      const res = await fetch(`/api/feed-polls/${data.postId}/vote`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ optionId: data.optionId }), credentials: "include" });
      if (!res.ok) throw new Error("Error");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
    },
  });
}
