import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { createContext, useContext, createElement } from "react";
import type { ReactNode } from "react";

type AuthContextType = {
  user: any;
  isLoading: boolean;
  login: (data: { username: string; password: string }) => void;
  isLoggingIn: boolean;
  register: (data: { username: string; password: string; principalSurname: string }) => void;
  isRegistering: boolean;
  loginAnonymous: () => void;
  isLoggingInAnonymous: boolean;
  upgradeAccount: (data: { username: string; password: string; principalSurname: string }) => void;
  isUpgrading: boolean;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const auth = useAuthInternal();
  return createElement(AuthContext.Provider, { value: auth }, children);
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

function useAuthInternal(): AuthContextType {
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: user, isLoading } = useQuery({
    queryKey: ['/api/user'],
    queryFn: async () => {
      const res = await fetch('/api/user', { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    staleTime: Infinity,
    retry: false,
  });

  const loginMut = useMutation({
    mutationFn: async (data: { username: string; password: string }) => {
      const res = await fetch('/api/auth/login', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) throw new Error("Невірний логін або пароль");
      return res.json();
    },
    onSuccess: (d) => { qc.setQueryData(['/api/user'], d); toast({ title: `Вітаємо, ${d.username}!` }); },
    onError: (e: any) => toast({ variant: "destructive", title: "Помилка", description: e.message }),
  });

  const regMut = useMutation({
    mutationFn: async (data: { username: string; password: string; principalSurname: string }) => {
      const res = await fetch('/api/auth/register', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Помилка"); }
      return res.json();
    },
    onSuccess: (d) => { qc.setQueryData(['/api/user'], d); toast({ title: "Реєстрація успішна!" }); },
    onError: (e: any) => toast({ variant: "destructive", title: "Помилка", description: e.message }),
  });

  const anonMut = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/auth/anonymous', { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Помилка");
      return res.json();
    },
    onSuccess: (d) => { qc.setQueryData(['/api/user'], d); },
    onError: (e: any) => toast({ variant: "destructive", title: "Помилка", description: e.message }),
  });

  const upgradeMut = useMutation({
    mutationFn: async (data: { username: string; password: string; principalSurname: string }) => {
      const res = await fetch('/api/auth/upgrade', { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), credentials: "include" });
      if (!res.ok) { const e = await res.json(); throw new Error(e.message || "Помилка"); }
      return res.json();
    },
    onSuccess: (d) => { qc.setQueryData(['/api/user'], d); toast({ title: "Акаунт збережено!" }); },
    onError: (e: any) => toast({ variant: "destructive", title: "Помилка", description: e.message }),
  });

  const logoutMut = useMutation({
    mutationFn: async () => { await fetch('/api/auth/logout', { method: "POST", credentials: "include" }); },
    onSuccess: () => { qc.setQueryData(['/api/user'], null); toast({ title: "Вихід" }); },
  });

  return {
    user, isLoading,
    login: loginMut.mutate, isLoggingIn: loginMut.isPending,
    register: regMut.mutate, isRegistering: regMut.isPending,
    loginAnonymous: anonMut.mutate, isLoggingInAnonymous: anonMut.isPending,
    upgradeAccount: upgradeMut.mutate, isUpgrading: upgradeMut.isPending,
    logout: logoutMut.mutate,
  };
}
