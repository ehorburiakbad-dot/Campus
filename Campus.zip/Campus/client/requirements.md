## Packages
framer-motion | For smooth animations and page transitions
lucide-react | Icon system (already in base, but emphasizing usage)
date-fns | Formatting dates in Ukrainian
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Inter", "sans-serif"], // Old FB used system/simple fonts like Lucida Grande/Tahoma, Inter is a modern equivalent
}
Colors should use HSL for consistency with the design system.
Primary color is roughly #4267B2 (214 46% 48%).
Background #f0f2f5 (210 20% 95%).
