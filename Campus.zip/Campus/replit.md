# replit.md

## Overview

Campus is a school-oriented social network platform designed for Ukrainian schools. It enables anonymous and official communication between students, featuring a post feed, teacher rating system, group chats, direct messaging, and a newspaper/gazette system. The UI is entirely in Ukrainian and designed mobile-first with a classic Facebook-inspired aesthetic (blue primary color, card-based layout).

The project targets a specific school initially (with principal surname verification during registration) and is designed to scale to other schools in the future.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
The project uses a three-folder monorepo pattern:
- `client/` — React frontend (Vite + TypeScript)
- `server/` — Express 5 backend (TypeScript, runs via tsx)
- `shared/` — Shared types, schemas, and route definitions used by both client and server

### Frontend
- **Framework**: React with TypeScript, bundled by Vite
- **Routing**: `wouter` (lightweight client-side router)
- **State/Data**: TanStack React Query for server state management
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with HSL CSS variables for theming. The design mimics classic Facebook (blue `#4267B2` primary, light gray `#f0f2f5` background)
- **Forms**: React Hook Form with Zod resolvers
- **Icons**: Lucide React
- **Date formatting**: date-fns with Ukrainian locale (`uk`)
- **Layout**: Desktop has a fixed left sidebar + main content area. Mobile uses a bottom navigation bar. Header is sticky at top.
- **Path aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

### Backend
- **Framework**: Express 5 on Node.js, wrapped in an HTTP server
- **Authentication**: Passport.js with `passport-local` strategy. Passwords are hashed with scrypt. Sessions managed with `express-session` + `memorystore` (in-memory session store)
- **API Pattern**: RESTful JSON API under `/api/` prefix. Route contracts defined in `shared/routes.ts` using Zod schemas
- **Database**: PostgreSQL via `pg` Pool, with Drizzle ORM for query building and schema management
- **Schema Management**: Drizzle Kit with `db:push` command (no migration files needed for dev). Schema defined in `shared/schema.ts`
- **Build**: Custom build script (`script/build.ts`) that uses Vite for client and esbuild for server, outputting to `dist/`

### Database Schema (PostgreSQL via Drizzle)
Key tables defined in `shared/schema.ts`:
- **users** — id, username, password (hashed), isAdmin, lastSeen, isOnline
- **teachers** — id, name, photoUrl, subject, averageRating
- **ratings** — id, teacherId, userId, 4 category scores (1-5), createdAt
- **newspapers** — id, name, type (official/user/underground), description, creatorId, isAnonymous
- **subscriptions** — userId, newspaperId
- **groups** — group creation and membership tracking
- **posts** — feed posts with upvote counts, optional groupId, optional imageUrl
- **comments** — comments on posts, anonymous support with anonTag
- **stories** — Instagram-style stories with 24h expiry, imageUrl, caption
- **polls** — newspaper polls with question text
- **pollOptions** — poll option choices
- **pollVotes** — user votes on polls (one per user per poll)
- **messages** — chat messages between users or in groups

Insert schemas are generated with `drizzle-zod` for validation.

### Key Features & Mechanics
1. **Auth**: Register requires entering the school principal's surname ("Breus"/"Бреус") as verification.
2. **Feed (Стрічка)**: Anonymous posts, upvoting, auto-cleanup after 7 days
3. **Teacher Ratings**: Rate teachers across 4 categories, password-protected teacher addition (`add222`)
4. **Groups**: Create/join groups, anonymous posts within groups, member counts
5. **Chat**: Real-time messaging (polling-based every 5s), general school chat (groupId=1)
6. **Newspapers**: Official (auto-subscribed), user-created gazette system (backend only, no frontend page yet)

### Navigation
- Desktop: Fixed left sidebar with items: Стрічка, Пошук, Вчителі, Чат, Газети, Розклад, Сповіщення (with unread badge), Адмін (admin only). Profile link + logout at bottom.
- Mobile: Bottom nav with: Стрічка, Пошук, Чат, Розклад, Сповіщення (with unread badge), Профіль

### Database Tables (new)
- **notifications** — userId, type (reaction/comment/mention/share/message), message, fromUserId, postId, isRead
- **reactions** — postId, userId, type (like/heart)
- **schedules** — className, dayOfWeek, lessonNumber, subject, teacherName, room, creatorId
- **achievements** — userId, type, title, description, icon, earnedAt
- **postShares** — postId, userId, sharedAt

### Recent Changes (Feb 2026)
- **Admin Panel** (Feb 9): Full admin panel at /admin with username "Пр" password "Пр". Features: stats dashboard, user/newspaper/post management.
- **Write Code System** (Feb 9): Newspapers have 6-char hex writeCode for article publishing.
- **Spam Protection**: 15-second post cooldown, temporary ban after 20 posts.
- **Image Attachments** (Feb 10): Posts support image upload via multer (5MB limit). Images served from /uploads.
- **Comments** (Feb 10): Threaded comments with anonymous support, likes, and reply chains.
- **Stories** (Feb 10): Instagram-style stories with 24h expiry.
- **Polls** (Feb 10): Newspaper polls requiring writeCode.
- **Recommendations** (Feb 10): Trending posts and popular newspapers.
- **User Profiles** (Feb 10): Profile page at /profile/:id with avatar upload, bio editing, post/achievement counts. Profile link in sidebar/bottom nav.
- **Notifications System** (Feb 10): Real-time notifications with 5s polling. Notifications for reactions, comments, mentions, shares, messages. Notification page at /notifications with unread badge in nav.
- **Search** (Feb 10): Full-text search across posts, users, groups, newspapers at /search. Debounced input with categorized results.
- **Class Schedules** (Feb 10): Schedule page at /schedule. CRUD for lesson entries with class/day/lesson filters. Class tab navigation.
- **Achievement Badges** (Feb 10): Auto-granted badges for milestones (first post, 10 posts, 50 posts, first comment, 20 comments, 50 messages, 100 messages). Displayed on profile pages.
- **Multi-type Reactions** (Feb 10): Replaced simple upvote with toggleable like/heart reactions. Reaction picker overlay on posts.
- **Voice Messages** (Feb 10): MediaRecorder-based voice recording in both posts and chat. Audio stored as webm in /uploads (10MB limit). Custom audio player with play/pause and progress bar.
- **@Mentions** (Feb 10): @username mentions in posts and comments with live autocomplete dropdown. Mentioned users get notifications.
- **Post Forwarding/Sharing** (Feb 10): Share button on posts creates a forwarded copy. Share count displayed. Original author attribution shown.
- **Dark Theme** (Feb 10): Full dark/light theme toggle using ThemeProvider with localStorage persistence. CSS variables for .dark class. Toggle in sidebar nav. All pages converted from hardcoded colors to semantic Tailwind classes (bg-background, bg-card, text-foreground, text-muted-foreground).
- **Groups** (Feb 10): Groups page at /groups. Create groups, join/leave, view group posts. Group posts are filtered from main feed. API: GET/POST /api/groups, GET /api/groups/:id, POST /api/groups/:id/join, POST /api/groups/:id/leave, GET/POST /api/groups/:id/posts.
- **Online Status** (Feb 10): Users have lastSeen and isOnline fields. Updated via requireAuth middleware (throttled 30s). Green dot indicator shown next to online users in chat contact list and conversations.
- **Browser Push Notifications** (Feb 10): Uses browser Notification API. Requests permission on load. Sends browser notification when new unread notifications arrive while tab is hidden. Integrated via useBrowserNotifications hook in Navigation component.
- **Advanced Profile Customization** (Feb 10): Extensive profile customization via edit dialog. Fields: displayName, headerUrl (cover image), statusText, mood (8 preset moods), profileColor (10 color themes), location, website. Profile page redesigned with cover header, color-coded avatar ring, mood badge, status quote, location/website links. Edit dialog at /profile/:id with live header preview, color picker circles, mood pill selector. PATCH /api/profile accepts multipart with avatar + header files + text fields.
- **Profile Wall** (Feb 10): Users can write on each other's profiles (like old VK/Facebook). Wall posts shown on profile page with author avatars, timestamps, delete capability. Notifications sent when someone writes on your wall. API: GET/POST /api/wall/:userId, DELETE /api/wall/:id.
- **Teacher of the Week** (Feb 10): Based on ratings from the past 7 days, shows "Найкращий вчитель тижня" (best) and "Найгірший вчитель тижня" (worst) cards at the top of the Teachers page. Displays weekly average rating and vote count. API: GET /api/teachers/weekly.

### Development Workflow
- `npm run dev` — Starts dev server with Vite HMR for frontend and tsx for backend
- `npm run build` — Builds both client (Vite) and server (esbuild) to `dist/`
- `npm run start` — Runs production build
- `npm run db:push` — Pushes Drizzle schema to PostgreSQL

## External Dependencies

### Database
- **PostgreSQL** — Primary data store, connected via `DATABASE_URL` environment variable
- **Drizzle ORM** — Type-safe query builder and schema definition
- **Drizzle Kit** — Schema migration/push tooling

### Authentication & Sessions
- **Passport.js** + **passport-local** — Username/password authentication
- **express-session** — Session management
- **memorystore** — In-memory session store (should be replaced with `connect-pg-simple` for production, which is already a dependency)

### Environment Variables Required
- `DATABASE_URL` — PostgreSQL connection string (required)
- `SESSION_SECRET` — Session encryption secret (falls back to `"campus_secret"`)

### Key NPM Packages
- **express v5** — HTTP server framework
- **vite** — Frontend dev server and bundler
- **@tanstack/react-query** — Async state management
- **zod** — Runtime validation for API inputs and form data
- **drizzle-zod** — Bridges Drizzle schemas to Zod validators
- **react-hook-form** — Form state management
- **wouter** — Client-side routing
- **date-fns** — Date formatting/manipulation
- **lucide-react** — Icon library
- **shadcn/ui components** — Full suite of Radix-based UI primitives (dialog, toast, select, tabs, etc.)
- **tailwindcss** — Utility-first CSS framework